# Rapport de reprise — Phase 1 (lots A/B/C) après revue indépendante

**20 septembre 2026 — reprise ciblée suite à RAPPORT-ANALYSE-LIVRAISON-PHASE1.md.**
Base : dépôt `partikulier3` @ `4b41bd65f2414ea9ce0fd847f144c46fccbab521` (tag
`v2.10.8-6.20.7`), arbre propre. Les trois diffs renvoyés par le commanditaire
(sha vérifiés contre son manifeste) sont la base exacte de reprise.

## Objet et périmètre

Reprise **ciblée**, conformément à la demande : corriger les trois faux
positifs démontrés (F1, F2, F3) et les points complémentaires, **sans refonte
produit** — aucun premium, aucun chiffrement, aucun paiement, aucune
modification de `ListingRepository.php`. Le lot A est **inchangé à l'octet
près** (diff du commanditaire). Les lots B et C sont révisés **uniquement**
sur leurs garde-fous (contrat SE-027 v2, validateurs d'oracle CI) ; les
correctifs applicatifs (class-security.php, class-listing-urls.php) et
l'ordre d'application A → B → C sont **conservés**.

## 1. Réponse aux trois faux positifs

### F1 — Le test sans Polylang acceptait des cibles de routage cassées

**Corrigé dans le contrat SE-027 v2, assertion E27-003.** En processus neuf,
après régénération de la table, chaque chemin est résolu par la première règle
qui matche et sa **cible est substituée** (`$matches[N]` → valeurs réelles →
`parse_str`), puis comparée à la query attendue **complète** (mêmes clés,
mêmes valeurs). Dix cas sont vérifiés : les cinq chemins préfixés
(`fr/annonces/`, `en/annonces/page/2/`, `ar/location/<ville>`, fiche avec
quartier, fiche sans quartier — chacun avec `post_type=properties`, `paged`,
`pk_city_slug`/`pk_listing_slug`, `lang` attendus) et les cinq chemins nus.
Toute clé parasite ou valeur erronée échoue.

**Contre-test rejoué (preuve `preuves/contretests/contretest-F1-cibles-mutees.json`)** :
mutation volontaire des cinq cibles vers
`post_type=post&mutation=properties&…` (la mutation exacte de la revue) —
le contrat répond **FAIL 5/6**, E27-003 ROUGE : « 5 cibles substituées
conformes sur 10 (attendu 10) ». Retour au code sain : **PASS 6/6**.
Transparence : un bug de verdict de classe « contrôle passant à tort »
(`in_array(false, …)` ne voyant jamais `false` car les échecs sont des
tableaux) a été découvert **dans notre propre durcissement** pendant ce
contre-test et corrigé (comptage strict `conformes === total_cas`) ; il est
consigné au worklog.

### F2 — Une fausse page 2 sans annonces était acceptée

**Corrigé dans E27-006.** Les requêtes `CURLOPT_NOBODY` (HEAD, anciennes
l.279/291) sont supprimées : uniquement des **GET réels avec corps**. Le
critère négatif « ne contient pas se027 » n'est plus une preuve. La
pagination est prouvée par des **assertions positives** : le contrat embarque
ses propres fixtures (25 annonces récentes + 1 ancienne datée d'un an),
garantissant au moins deux pages quel que soit le stock ; la page 1 contient
une récente du run, la dernière page contient l'ancienne du run, l'ancienne
est **absente** de la page 1, chaque page vérifiée porte `lang="fr`, la page
au-delà de la dernière répond 404, et la 301 legacy `/property/` est suivie
en GET vers une cible finale 200 distincte de l'origine (pas de boucle).

**Contre-test rejoué (preuve `contretest-F2-page-factice.json`)** : MU-plugin
faisant répondre toutes les URLs paginées par `HTTP 200
PAGE_FACTICE_SANS_AUCUNE_ANNONCE` (le scénario de la revue) — le contrat
répond **FAIL 4/6** : E27-006 ROUGE (ancienne du run ABSENTE de la page
factice) **et** E27-003 ROUGE (page paginée nue factice) — double détection.
Retour au code sain : **PASS 6/6** (trois exécutions indépendantes).

### F3 — L'oracle CI acceptait un seul faux rapport comme 382/382

**Corrigé dans les deux validateurs** (contribution B : 39 suites/376 ;
contribution C : 40 suites/382). Le nouveau validateur contrôle, pour chaque
fichier : JSON valide ; `status === "PASS"` ; `total/passed/failed` entiers ;
`passed + failed === total` ; `failed === 0` ; **`total` === le total épinglé
de la suite** (table en dur, somme vérifiée 370 + 6 + 6) ; **si `results` est
fourni** : `count(results) === total`, chaque résultat `{test_id non vide,
status PASS}`, unicité des `test_id` ; plus la **cardinalité et l'ensemble
exact** des 39/40 fichiers attendus et les totaux globaux. Note de périmètre :
10 suites historiques du dépôt (core, services, load, rest-lite-scope,
routes-collision, sync, payments, premium, leads) n'émettent pas de `results`
(format antérieur, hors périmètre des diffs Phase 1) — leurs totaux restent
épinglés nominalement, ce qui interdit tout gonflement.

**Contre-tests rejoués (preuve `contretest-oracle-durci.json`, 9 scénarios,
PHP extrait des heredocs des workflows livrés = code testé)** : jeu valide
complet (38 suites réelles + se041 + se027 réels) → **accepté** (376/376 et
382/382) ; `inventee.json` (le faux rapport exact de la revue) → **refusé**
(cardinalité 1 ≠ 40) ; suite manquante → refusé ; doublon → refusé ; JSON
invalide → refusé ; compteur incohérent (total 13 ≠ 8 épinglé) → refusé ;
FAIL caché sous PASS global → refusé. **Témoin** : le validateur faible de la
livraison v1 accepte toujours `inventee.json` (exit 0, « 382/382 ») — preuve
que le défaut F3 était réel.

## 2. Points complémentaires de la revue

- **Restauration Polylang (§5)** : le verdict de restauration est désormais
  établi **dans un processus neuf** (plus aucune lecture `get_option` du
  parent) : plugin actif, `POLYLANG_VERSION` définie, langues {ar,en,fr}
  rétablies, 0 double, table trilingue **identique à la référence du run**
  (md5 injecté), second flush identique (idempotence), et les **codes de
  sortie** des sous-processus (activate + contrôle) sont intégrés au verdict.
- **Fixtures avec/sans quartier (l.134 v1)** : la fiche « sans quartier » ne
  reçoit plus `_pk_url_district` ; les **deux vrais permaliens** (4 et 3
  segments) sont attaqués en GET : 200, la **bonne** fiche servie (marqueur
  du run présent, l'autre absente), `lang="fr`.
- **Dépendance au stock (5/6 sur installation pauvre)** : le contrat embarque
  sa pagination (cf. F2) — il ne dépend plus du stock du workflow.
- **Table préexistante vs régénérée** : E27-001 fait un **flush de mise en
  état** avant de capturer la table de référence ; une table périmée (rejeu
  après d'autres scénarios) est régénérée au warm-up, puis les trois flush
  suivants sont comparés à la table saine.
- **Route ville** : comportement réel testé et qualifié (avec Polylang :
  règle effective `(en|fr|ar)/location/…` ; sans Polylang : la règle du thème
  `^location/` sert la liste des annonces de la ville — GET 200 avec les
  annonces du run) ; la collision `es_location` reste **préexistante,
  rapportée, hors périmètre** — arbitrage demandé.
- **Propreté de l'archive** : les captures admin sont **expurgées à la
  source** (filtre systématique `pk_diag_jeton`/`_wpnonce`/`pk_nonce` →
  `[EXPURGE]`, cookies supprimés, garde automatique) ; contrôle final :
  **0 fichier avec jeton résiduel sur les 311 fichiers de preuves**.
- **Manifeste** : étendu à **tous** les fichiers du paquet (diffs, rapport,
  ordre, preuves, scripts rejouables, LISEZMOI, CDC de référence) — seuls le
  manifeste lui-même et le zip le sont par nature.
- **Effort v2.1** : l'estimation préalable de 6,5 h était auto-consignée
  avant exécution (journal/00-estimation-prealable.md de la livraison v1) ;
  son « acceptation » formelle n'était pas un livrable documenté — nous
  consignons désormais l'estimation de reprise **avant exécution** (7,25 h,
  fourchette 6,5-8,5, worklog Task 86) et le bilan ci-dessous.
- **« Recette complète C »** : formulation retirée ; la présente reprise
  démontre : contrat SE-027 v2 vert sur code corrigé (plusieurs exécutions),
  rouge sur les deux mutations de la revue, chaîne 382/382 sur installation
  fraîche avec oracle durci — la clôture CI de référence (PHP 8.3/MySQL 8)
  **reste à démontrer après application** (voir limites).

## 3. Résultats rejoués sur installations fraîches

| Chaîne | Code | Suites | Oracle | Verdict |
|---|---|---:|---:|---|
| Référence | base (4b41bd6) | 38 | 370/370 | PASS (`preuves/reference-run/`) |
| A | base + lot A | — | — | RA-1 : direct 200/0 → **404/0**, parcours signé complet fonctionnel avant/après (`preuves/RA-1/`) |
| A+B | base + A + B révisé | 39 | **376/376 durci** | PASS (`preuves/chaine-AB/`) |
| A+B+C | base + A + B + C révisés | 40 | **382/382 durci** | PASS (`preuves/chaine-ABC/`) |

Reproductions ciblées : RB-1 (avant : 80 méthodes XML-RPC, `Hello!` exécuté,
pingback faultCode 0, contrat sur code original **FAIL 1/6** ; après :
exactement 3 méthodes `system.*`, faults -32601, contrat **PASS 6/6**) ;
RC-1 (avant : 303 règles / 5 doubles ; fichiers C copiés : 303/5, migration
non déclenchée ; `maybe_flush()` : **298/0** ; trois flush stables ;
idempotence ; contrat v2 **PASS 6/6** ; démo négative sur code sans C :
**FAIL 3/6**). Point R1 reconfirmé sur le code A+B+C : `mark_sold`,
`mark_rented`, `archive` laissent l'annonce présente en collection REST ;
asymétrie `refuse` (présente + `listing_not_found` en lecture individuelle)
; `refuse_synced` absente ; `ListingRepository.php` **non modifié**.

Vérification de chaîne : clone frais @4b41bd6 → `git apply --check` A, puis
B révisé, puis C révisé : tous OK, application propre, **arbres strictement
identiques** au dépôt de travail à l'état A+B+C.

## 4. Contenu des diffs révisés

- `PHASE1-LOT-A-SE032.diff` — **inchangé** (copie exacte de l'artefact revu).
- `PHASE1-LOT-B-SE041-reprise.diff` — 4 fichiers : workflow (étape SE-041
  inchangée + **oracle 376 durci**), `docs/INSTALLATION.md`,
  `class-security.php`, `se041-xmlrpc-contract.php` (ces trois derniers
  inchangés du lot B original).
- `PHASE1-LOT-C-SE027-reprise.diff` — 3 fichiers : `class-listing-urls.php`
  (correctif applicatif **inchangé** : RULES_VERSION 5 + conditionnement
  `!POLYLANG_VERSION` des cinq règles préfixées), **contrat
  `se027-rewrite-prefix-contract.php` v2 durci** (mêmes six identifiants
  d'assertion, total 6 inchangé → oracle 382/40 inchangé), workflow (étape
  SE-027 inchangée + **oracle 382 durci**).

## 5. Limites honnêtes et recommandations

- **CI de référence (PHP 8.3 / MySQL 8) non exécutée** : aucun push n'a eu
  lieu ; la clôture formelle §10 du CDC reste conditionnée à la CI après
  application. Notre laboratoire : PHP 8.3.30 (statique), **SQLite** via
  sqlite-database-integration 3.0.2 (écart déclaré, reconduit de la v1) ;
  la revue utilisait MariaDB 11.8 — les comportements testés (rewrite,
  XML-RPC, diagnostic, REST) y sont identiques.
- **Validateurs 370 et 382 de référence** : l'oracle 370 du workflow de base
  (hors périmètre des diffs Phase 1) reste dans sa forme faible ; nous
  recommandons de le durcir selon le même modèle lors d'une contribution
  ultérieure (le validateur durci C teste néanmoins l'intégralité des 40
  suites, y compris les 38 de référence).
- **10 suites historiques sans `results`** : vérifiées par totaux épinglés et
  cohérence arithmétique ; l'exigence de détail demanderait de modifier ces
  contrats du dépôt (hors périmètre Phase 1).
- Aucun commit, push, tag, release, déploiement ou requête vers le domaine
  du client ; laboratoires et clones sont locaux et jetables.

## 6. Bilan d'effort

Estimation de reprise consignée **avant exécution** : ≈ 7,25 h (fourchette
6,5-8,5) ; réalisé (reconstruction du laboratoire incluse, les livrables et
scripts de la v1 ayant été perdus à la réinitialisation de session) :
enveloppe respectée, aucun supplément d'arbitrage à solliciter.

## 7. Prochaines actions proposées (commanditaire)

1. Revue des diffs révisés (B et C uniquement — A inchangé) et du présent
   rapport ; contre-vérification des preuves expurgées.
2. Application contrôlée lot par lot (A → B → C) puis **CI de référence
   GitHub (MySQL 8)** : 39 suites/376 puis 40 suites/382 attendus, validateur
   durci.
3. Arbitrage de la collision `location`/`es_location` (préexistante) et du
   correctif R1 (SE-044/E-4807) — hors périmètre Phase 1.
