<?php
if (!defined('WP_CLI')||!WP_CLI||wp_get_environment_type()!=='local')exit(1);
wp_set_current_user(1);
$state=$args[0]??'init';$id=(int)get_option('reprise_phase1_listing');
if($state==='init'){
 $id=wp_insert_post(['post_type'=>'properties','post_status'=>'publish','post_title'=>'REPRISE PHASE1 — fictif sans bien réel','post_name'=>'reprise-phase1-fictif','post_author'=>1,'meta_input'=>['_pk_status'=>'actif','_pk_url_city'=>'casablanca']]);
 update_option('reprise_phase1_listing',$id);pll_set_post_language($id,'fr');
}elseif($state==='refuse_synced'){
 wp_update_post(['ID'=>$id,'post_status'=>'publish']);
}elseif($state==='refuse'){
 update_post_meta($id,'_pk_status','refuse');
}else{
 $res=Partikulier_Dashboard::manage_listing($id,$state,1);
 if(is_wp_error($res))WP_CLI::error($res->get_error_message());
}
(new \Partikulier\Core\Integration\ListingSynchronizer())->flush();
$r=new \Partikulier\Core\ListingRepository();$row=$r->rowForExternalId('estatik:'.$id);$find=$row?$r->find((int)$row['id']):null;
echo wp_json_encode(['action'=>$state,'post_id'=>$id,'post_status'=>get_post_status($id),'pk_status'=>get_post_meta($id,'_pk_status',true),'url'=>get_permalink($id),'projection'=>$row,'individual'=>is_wp_error($find)?['error'=>$find->get_error_code()]:$find],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
