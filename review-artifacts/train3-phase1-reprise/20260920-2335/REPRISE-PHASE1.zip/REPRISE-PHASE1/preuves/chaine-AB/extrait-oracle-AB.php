<?php
$attendues = array(
          "alerts-domain-contract.json" => 15,
"artifact-hygiene-contract.json" => 3,
"automation-domain-contract.json" => 23,
"avif-security-contract.json" => 15,
"core-contract.json" => 8,
"front-assets.json" => 7,
"i18n-chrome-domain-contract.json" => 13,
"i18n-content-domain-contract.json" => 15,
"i18n-unified-mechanism-contract.json" => 15,
"lead-erase-security-contract.json" => 13,
"leads-contract.json" => 7,
"leads-domain-contract.json" => 16,
"load-contract.json" => 7,
"module-perimeter-contract.json" => 11,
"options-sanitizer-contract.json" => 8,
"owner-stats-domain-contract.json" => 16,
"payments-contract.json" => 10,
"premium-contract.json" => 8,
"rest-lite-scope.json" => 10,
"routes-collision.json" => 6,
"se022-http-battery.json" => 4,
"se022-idempotence-contract.json" => 9,
"se024-i18n-dedup-contract.json" => 7,
"se025-trilingual-routes-contract.json" => 12,
"se026-hmac-mode-contract.json" => 4,
"se034-form-idempotency-contract.json" => 6,
"se035-catalogs-contract.json" => 5,
"se036-places-referential-contract.json" => 5,
"se037-seo-multilingual-contract.json" => 5,
"se041-xmlrpc-contract.json" => 6,
"se043-geo-routing-battery.json" => 9,
"se048-premium-honesty-contract.json" => 6,
"se054-closure-contract.json" => 5,
"search-arrays-contract.json" => 9,
"services-contract.json" => 7,
"slug-redirects-domain-contract.json" => 9,
"sync-contract.json" => 14,
"translation-variants-domain-contract.json" => 16,
"vestige-extinction-contract.json" => 12,
);
$fichiers = glob("preuves-run/contrats/*.json");
$bases = array_map("basename", $fichiers);
if (count($bases) !== count($attendues)) {
fwrite(STDERR, "cardinalite inattendue : attendu " . count($attendues) . " suites, obtenu " . count($bases) . "\n");
exit(1);
}
$tot = 0; $pas = 0;
foreach ($fichiers as $f) {
$nom = basename($f);
if (!isset($attendues[$nom])) {
fwrite(STDERR, $nom . " : suite hors ensemble attendu\n");
exit(1);
}
$d = json_decode((string) file_get_contents($f), true);
if (!is_array($d)) { fwrite(STDERR, $nom . " : JSON invalide\n"); exit(1); }
foreach (array("status", "total", "passed", "failed") as $cle) {
if (!array_key_exists($cle, $d)) { fwrite(STDERR, $nom . " : cle manquante " . $cle . "\n"); exit(1); }
}
if (!in_array($d["status"], array("PASS", "FAIL"), true)) { fwrite(STDERR, $nom . " : status invalide\n"); exit(1); }
if (!is_int($d["total"]) || !is_int($d["passed"]) || !is_int($d["failed"]) || $d["total"] < 0 || $d["passed"] < 0 || $d["failed"] < 0) {
fwrite(STDERR, $nom . " : compteurs invalides\n"); exit(1);
}
if ($d["status"] !== "PASS" || $d["failed"] !== 0) { fwrite(STDERR, $nom . " : status != PASS ou failed != 0\n"); exit(1); }
if ($d["passed"] + $d["failed"] !== $d["total"] || $d["passed"] !== $d["total"]) {
fwrite(STDERR, $nom . " : compteurs incoherents (total=" . $d["total"] . ", passed=" . $d["passed"] . ", failed=" . $d["failed"] . ")\n"); exit(1);
}
if ($d["total"] !== $attendues[$nom]) {
fwrite(STDERR, $nom . " : total " . $d["total"] . " != total epingle " . $attendues[$nom] . "\n"); exit(1);
}
if (array_key_exists("results", $d)) {
if (!is_array($d["results"])) { fwrite(STDERR, $nom . " : results non tableau\n"); exit(1); }
if (count($d["results"]) !== $d["total"]) { fwrite(STDERR, $nom . " : count(results) != total\n"); exit(1); }
$ids = array();
foreach ($d["results"] as $r) {
if (!is_array($r) || !isset($r["test_id"], $r["status"]) || !is_string($r["test_id"]) || $r["test_id"] === "" || !in_array($r["status"], array("PASS", "FAIL"), true)) {
fwrite(STDERR, $nom . " : resultat malforme\n"); exit(1);
}
if ($r["status"] !== "PASS") { fwrite(STDERR, $nom . " : assertion " . $r["test_id"] . " != PASS sous statut global PASS\n"); exit(1); }
$ids[] = $r["test_id"];
}
if (count($ids) !== count(array_unique($ids))) { fwrite(STDERR, $nom . " : test_id dupliques\n"); exit(1); }
}
$tot += $d["total"]; $pas += $d["passed"];
}
if ($tot !== 376 || $pas !== 376) { fwrite(STDERR, "oracle inattendu (attendu 376/376 — 39 suites : 370 reference + 6 SE-041 lot B Phase 1)\n"); exit(1); }
echo "contrats dynamiques : $pas/$tot (" . count($bases) . " suites, schema, coherence, unicitte, totaux epingles et ensemble exact verifies)\n";
