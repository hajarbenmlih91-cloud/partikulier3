#!/bin/bash
# REPRISE F3 — contre-tests du validateur CI durci.
# Extrait le PHP EXACT des heredocs des workflows générés (workflow-B.yml,
# workflow-ABC.yml), puis le rejoue contre 7 jeux dont le faux rapport du
# commanditaire. Jeux : VALIDE (accepté, exit 0), INVENTE (scénario exact F3),
# MANQUANTE, DOUBLON, INVALIDE, COMPTEUR, FAIL-CACHE (tous refusés, exit != 0).
set -uo pipefail
RT=/home/z/my-project/phase1-reprise/runtime
PHP="$RT/php"
PREUVES=/home/z/my-project/phase1-reprise/preuves
WORK=/tmp/ct-oracle
rm -rf "$WORK"; mkdir -p "$WORK"

extraire_php() { # $1 = workflow.yml → $2 = extrait.php (PHP exact reçu par php en stdin)
  python3 - "$1" "$2" << 'PYEOF'
import sys
wf = open(sys.argv[1]).read().splitlines()
debut = next(i for i, l in enumerate(wf) if l.strip() == "php <<'ORACLE'")
fin = next(i for i in range(debut + 1, len(wf)) if wf[i].strip() == 'ORACLE')
# strip de l'indentation YAML (10 espaces) comme le ferait le runner
bloc = [l[10:] if l.startswith(' ' * 10) else l for l in wf[debut + 1:fin]]
open(sys.argv[2], 'w').write('\n'.join(bloc) + '\n')
PYEOF
}
extraire_php "$RT/workflow-B.yml" "$WORK/extrait-oracle-B.php"
extraire_php "$RT/workflow-ABC.yml" "$WORK/extrait-oracle-ABC.php"
"$PHP" -l "$WORK/extrait-oracle-B.php" > /dev/null && "$PHP" -l "$WORK/extrait-oracle-ABC.php" > /dev/null && echo "extraits PHP lint OK"

# ── Jeu VALIDE ABC : 38 suites réelles (reference-run) + se041 + se027 (runs réels) ──
jeu_valide() { # $1 = etat (B|ABC) → dossier preuves-run/contrats rempli
  local etat="$1"
  local dest="$WORK/$etat-valide"
  rm -rf "$dest"; mkdir -p "$dest/preuves-run/contrats"
  cp "$PREUVES"/reference-run/contrats/*.json "$dest/preuves-run/contrats/"
  cp /tmp/se041-abc.json "$dest/preuves-run/contrats/se041-xmlrpc-contract.json"
  if [ "$etat" = "ABC" ]; then cp /tmp/se027-abc.json "$dest/preuves-run/contrats/se027-rewrite-prefix-contract.json"; fi
}
jeu_valide B; jeu_valide ABC

# ── Jeux MUTÉS ABC (à partir du jeu valide ABC) ──
MUT="$WORK/ABC-mute"; rm -rf "$MUT"; cp -r "$WORK/ABC-valide" "$MUT"
# 1. INVENTE : le scénario EXACT du commanditaire — un seul JSON auto-contradictoire
rm -rf "$WORK/ABC-invente"; mkdir -p "$WORK/ABC-invente/preuves-run/contrats"
cat > "$WORK/ABC-invente/preuves-run/contrats/inventee.json" << 'EOF'
{"status":"PASS","total":382,"passed":382,"failed":999,"results":[{"status":"FAIL","test_id":"erreur"}]}
EOF
# 2. MANQUANTE : 39 fichiers sur 40 (se027 retiré)
rm -rf "$WORK/ABC-manquante"; cp -r "$WORK/ABC-valide" "$WORK/ABC-manquante"
rm "$WORK/ABC-manquante/preuves-run/contrats/se027-rewrite-prefix-contract.json"
# 3. DOUBLON : 41 fichiers (une suite en double, nom hors ensemble)
rm -rf "$WORK/ABC-doublon"; cp -r "$WORK/ABC-valide" "$WORK/ABC-doublon"
cp "$WORK/ABC-valide/preuves-run/contrats/core-contract.json" "$WORK/ABC-doublon/preuves-run/contrats/core-contract-copy.json"
# 4. INVALIDE : un JSON syntaxiquement cassé
rm -rf "$WORK/ABC-invalide"; cp -r "$WORK/ABC-valide" "$WORK/ABC-invalide"
printf '{"suite": "core-contract", "status": "PASS", "total": 12, "passed": 12, "failed": 0, "results": [{' > "$WORK/ABC-invalide/preuves-run/contrats/core-contract.json"
# 5. COMPTEUR : total déclaré ≠ count(results) (l'oracle faible l'acceptait)
rm -rf "$WORK/ABC-compteur"; cp -r "$WORK/ABC-valide" "$WORK/ABC-compteur"
python3 - << 'PYEOF'
import json
p = '/tmp/ct-oracle/ABC-compteur/preuves-run/contrats/premium-contract.json'
d = json.load(open(p))
d['total'] = d['total'] + 5   # compteurs déclarés faux, results intacts
d['passed'] = d['passed'] + 5
json.dump(d, open(p, 'w'))
PYEOF
# 6. FAIL-CACHE : statut global PASS mais une assertion FAIL dedans
rm -rf "$WORK/ABC-failcache"; cp -r "$WORK/ABC-valide" "$WORK/ABC-failcache"
python3 - << 'PYEOF'
import json
p = '/tmp/ct-oracle/ABC-failcache/preuves-run/contrats/alerts-domain-contract.json'
d = json.load(open(p))
d['results'][0]['status'] = 'FAIL'   # FAIL caché sous status global PASS (suite AVEC results)
json.dump(d, open(p, 'w'))
PYEOF

# ── Rejeu : le validateur extrait contre chaque jeu ──
resultat_json="$PREUVES/contretests/contretest-oracle-durci.json"
mkdir -p "$PREUVES/contretests"
: > "$resultat_json.tmp"
run_jeu() { # $1=dossier $2=extrait.php $3=attendu(0|non0) $4=scenario(json key)
  local dossier="$1" extrait="$2" attendu="$3"
  local scenario="${4:-$(basename "$dossier")}"
  local code stdout
  cd "$dossier"
  stdout=$("$PHP" "$extrait" 2>/tmp/ct-stderr.txt); code=$?
  local verdict
  if [ "$attendu" = "0" ]; then
    verdict=$([ "$code" -eq 0 ] && echo "CONFORME" || echo "ECHEC-INATTENDU")
  else
    verdict=$([ "$code" -ne 0 ] && echo "REFUSE" || echo "ACCEPTE-A-TORT")
  fi
  python3 - "$scenario" "$code" "$verdict" "$stdout" "$(cat /tmp/ct-stderr.txt)" "$resultat_json.tmp" "$dossier" << 'PYEOF'
import json, sys
scenario, code, verdict, stdout, stderr, tmp, dossier = sys.argv[1:8]
code = int(code)
print(f"{scenario:16s} exit={code:2d} -> {verdict:18s} stdout={stdout.strip()[:70]!r} stderr={stderr.strip()[:90]!r}")
entry = {
    "scenario": scenario,
    "validateur": "durci" if "faible" not in dossier and "temoin" not in dossier else "faible-v1",
    "exit": int(code),
    "verdict": verdict,
    "stdout": stdout.strip(),
    "stderr": stderr.strip()[:400],
    "jeu": dossier,
}
with open(tmp, 'a') as f:
    f.write(json.dumps(entry, ensure_ascii=False) + "\n")
PYEOF
}
echo "═══ Validateurs DURCIS (reprise) — ABC (382/382, 40 suites) ═══"
run_jeu "$WORK/ABC-valide"    "$WORK/extrait-oracle-ABC.php" 0
run_jeu "$WORK/ABC-invente"   "$WORK/extrait-oracle-ABC.php" non0
run_jeu "$WORK/ABC-manquante" "$WORK/extrait-oracle-ABC.php" non0
run_jeu "$WORK/ABC-doublon"   "$WORK/extrait-oracle-ABC.php" non0
run_jeu "$WORK/ABC-invalide"  "$WORK/extrait-oracle-ABC.php" non0
run_jeu "$WORK/ABC-compteur"  "$WORK/extrait-oracle-ABC.php" non0
run_jeu "$WORK/ABC-failcache" "$WORK/extrait-oracle-ABC.php" non0
echo "═══ Validateur DURCI — B (376/376, 39 suites) ═══"
run_jeu "$WORK/B-valide"      "$WORK/extrait-oracle-B.php" 0

echo "═══ TÉMOIN : validateur FAIBLE livré (v1) contre inventee.json — doit rester ACCEPTÉ-A-TORT (preuve que F3 était réel) ═══"
# Le validateur faible = celui des diffs originaux (ligne unique du workflow livré v1)
rm -rf "$WORK/ABC-temoin"; cp -r "$WORK/ABC-invente" "$WORK/ABC-temoin"
cat > "$WORK/extrait-oracle-faible.php" << 'EOF'
<?php $tot=0; $pas=0; foreach (glob("preuves-run/contrats/*.json") as $f) { $d=json_decode(file_get_contents($f), true); if (($d["status"] ?? "") !== "PASS") { fwrite(STDERR, basename($f).": status != PASS\n"); exit(1); } $tot += (int) $d["total"]; $pas += (int) $d["passed"]; } echo "contrats dynamiques : $pas/$tot\n"; if ($tot !== 382 || $pas !== 382) { fwrite(STDERR, "oracle inattendu\n"); exit(1); }
EOF
run_jeu "$WORK/ABC-temoin" "$WORK/extrait-oracle-faible.php" 0 faux-rapport-sur-validateur-faible
echo "(le témoin faible accepte le faux rapport — F3 confirmé côté v1)"

# Agrégation JSON finale
python3 - "$resultat_json" << 'PYEOF'
import json, sys
lignes = [json.loads(l) for l in open(sys.argv[1] + '.tmp')]
json.dump(lignes, open(sys.argv[1], 'w'), ensure_ascii=False, indent=2)
print('JSON agrégé écrit :', sys.argv[1], '-', len(lignes), 'scénarios')
PYEOF
