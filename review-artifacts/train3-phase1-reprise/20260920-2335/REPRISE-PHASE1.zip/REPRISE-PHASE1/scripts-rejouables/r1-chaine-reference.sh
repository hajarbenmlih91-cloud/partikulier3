#!/bin/bash
# REPRISE PHASE 1 — chaîne de référence (38 suites, oracle 370/370) sur un lab
# fraîchement installé à l'état base (4b41bd6). Reconstitution fidèle du
# workflow .github/workflows/contrats-recette.yml (steps 71→349).
# Usage: RUNTIME=... LAB=... DEPOT=... SORTIE=... bash r1-chaine-reference.sh
set -euo pipefail

RT="${RUNTIME:?}"; LAB="${LAB:?}"; DEPOT="${DEPOT:?}"
OUT="${SORTIE:?SORTIE (répertoire preuves de sortie) requis}"
PHP="$RT/php"; WPCLI="$RT/wp-cli.phar"; WPDIR="$LAB/wp"
COMMIT="$(cd "$DEPOT" && git rev-parse HEAD)"
[ "$COMMIT" = "4b41bd65f2414ea9ce0fd847f144c46fccbab521" ] || { echo "commit inattendu: $COMMIT"; exit 2; }

mkdir -p "$OUT/contrats"; : > "$OUT/journal.txt"

# Géométrie workspace du workflow : theme/ et plugin/ visibles depuis $LAB
# (symlinks vers le dépôt — restent synchronisés après application des diffs),
# serveur lancé depuis $LAB en chemins RELATIFS (php -S ... -t wp ...), sinon
# redirect_canonical fabrique des Location "…/lab-base/wp/…" (constat reprise).
ln -sfn "$DEPOT/theme" "$LAB/theme"
ln -sfn "$DEPOT/plugin" "$LAB/plugin"

# ── Fonction serveur : purge du port, démarrage, sonde, garde anti faux-vert ──
# mode "200" : exiger un vrai HTTP 200 (front). mode "connect" : la connexion
# suffit (se022 : requêtes REST insensibles au 301 canonique — workflow l.143-145).
demarrer_serveur() { # $1=port $2=chemin_sonde $3=label $4=mode(200|connect)
  local port="$1" sonde="$2" label="$3" mode="${4:-200}"
  pkill -f "127.0.0.1:$port" 2>/dev/null || true; sleep 0.3
  (cd "$LAB" && "$PHP" -S "127.0.0.1:$port" -t wp theme/partikulier/tests/router-ci.php > "$(realpath "$OUT")/serveur-$label.log" 2>&1 &)
  local sain=false code=""
  for i in $(seq 1 60); do
    code=$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$port$sonde" || true)
    if [ "$mode" = "connect" ] && [ -n "$code" ] && [ "$code" != "000" ]; then sain=true; break; fi
    if [ "$mode" = "200" ] && [ "$code" = "200" ]; then sain=true; break; fi
    sleep 0.5
  done
  if [ "$sain" != true ]; then
    echo "FAIL  sonde $label (pas de réponse $mode sur $sonde, code=$code)" | tee -a "$OUT/journal.txt"
    return 1
  fi
}
arreter_serveur() { pkill -f "127.0.0.1:$1" 2>/dev/null || true; sleep 0.3; }

export PK_WP_DIR="$WPDIR" PK_COMMIT="$COMMIT" PK_REPO_DIR="$DEPOT" PK_THEME_DIR="$DEPOT/theme/partikulier"

# ── 1. Les 32 suites dynamiques (workflow l.71-108) ──
cd "$WPDIR"
for suite in core-contract services-contract load-contract rest-lite-scope \
             routes-collision sync-contract payments-contract premium-contract \
             leads-contract leads-domain-contract lead-erase-security-contract \
             alerts-domain-contract automation-domain-contract \
             owner-stats-domain-contract \
             translation-variants-domain-contract i18n-chrome-domain-contract \
             i18n-content-domain-contract i18n-unified-mechanism-contract \
             module-perimeter-contract avif-security-contract \
             vestige-extinction-contract artifact-hygiene-contract \
             options-sanitizer-contract se022-idempotence-contract \
             se026-hmac-mode-contract \
             slug-redirects-domain-contract \
             se024-i18n-dedup-contract \
             se048-premium-honesty-contract \
             se035-catalogs-contract \
             se036-places-referential-contract \
             se037-seo-multilingual-contract \
             se054-closure-contract; do
  if "$PHP" "wp-content/plugins/partikulier-core/tests/$suite.php" \
       > "$OUT/contrats/$suite.json" 2> "$OUT/contrats/$suite.err"; then
    echo "PASS  $suite" | tee -a "$OUT/journal.txt"
  else
    echo "FAIL  $suite" | tee -a "$OUT/journal.txt"; exit 1
  fi
done
cd "$LAB"

# ── 2. front-assets HTTP (SE-018, workflow l.109-139) ──
demarrer_serveur 8099 / front-assets
PK_BASE=http://127.0.0.1:8099 \
PK_ESTATIK_FILE="$WPDIR/wp-content/plugins/estatik/estatik.php" \
  node "$DEPOT/theme/partikulier/tests/front-assets.mjs" > "$OUT/contrats/front-assets.json"
echo "PASS  front-assets" | tee -a "$OUT/journal.txt"
arreter_serveur 8099

# ── 3. SE-022 batterie HTTP (port 8101, sonde « connect » — workflow l.140-154) ──
demarrer_serveur 8101 / se022 connect
# sonde 200 sur / (pas de /fr/ avant Polylang)
PK_BASE=http://127.0.0.1:8101 "$PHP" "$DEPOT/plugin/partikulier-core/tests/se022-http-battery.php" > "$OUT/contrats/se022-http-battery.json"
echo "PASS  se022-http-battery" | tee -a "$OUT/journal.txt"
arreter_serveur 8101

# ── 4. SE-043 routage géo (workflow l.155-179) ──
demarrer_serveur 8099 / se043
PK_BASE=http://127.0.0.1:8099 "$PHP" "$DEPOT/plugin/partikulier-core/tests/se043-geo-routing-battery.php" > "$OUT/contrats/se043-geo-routing-battery.json"
echo "PASS  se043-geo-routing-battery" | tee -a "$OUT/journal.txt"
arreter_serveur 8099

# ── 5. SE-034 idempotence canal public (workflow l.180-203) ──
demarrer_serveur 8099 / se034
PK_BASE=http://127.0.0.1:8099 "$PHP" "$DEPOT/plugin/partikulier-core/tests/se034-form-idempotency-contract.php" > "$OUT/contrats/se034-form-idempotency-contract.json"
echo "PASS  se034-form-idempotency-contract" | tee -a "$OUT/journal.txt"
arreter_serveur 8099

# ── 6. search-arrays E-5105 (workflow l.204-236) ──
demarrer_serveur 8099 / search-arrays
PK_BASE=http://127.0.0.1:8099 "$PHP" "$DEPOT/theme/partikulier/tests/search-arrays-contract.php" > "$OUT/contrats/search-arrays-contract.json"
echo "PASS  search-arrays-contract" | tee -a "$OUT/journal.txt"
arreter_serveur 8099

# ── 7. Polylang fr/en/ar + réglages de référence (workflow l.237-313) ──
"$PHP" "$WPCLI" plugin activate polylang --path="$WPDIR" --quiet
cat > "$LAB/pll-langues.php" <<'PLL_LANGUES'
<?php
if (!defined("ABSPATH")) { exit("CLI only"); }
$model = isset($GLOBALS["polylang"]) && $GLOBALS["polylang"] ? $GLOBALS["polylang"]->model : null;
if (!$model) { WP_CLI::error("Polylang n'est pas actif"); }
$langues = array(
    array("name" => "Français", "slug" => "fr", "locale" => "fr_FR", "rtl" => 0, "flag" => "fr", "term_group" => 1),
    array("name" => "English", "slug" => "en", "locale" => "en_US", "rtl" => 0, "flag" => "us", "term_group" => 0),
    array("name" => "العربية", "slug" => "ar", "locale" => "ar", "rtl" => 1, "flag" => "ma", "term_group" => 2),
);
foreach ($langues as $l) {
    if (!$model->get_language($l["slug"])) {
        $res = $model->add_language($l);
        if (is_wp_error($res)) { WP_CLI::error("langue ".$l["slug"]." : ".$res->get_error_message()); }
    }
}
$erreurs = $GLOBALS["polylang"]->options->merge(array(
    "force_lang" => 1,
    "hide_default" => 0,
    "browser" => 0,
    "redirect_lang" => 0,
    "default_lang" => "fr",
    "taxonomies" => array("es_type", "es_status", "es_location", "es_category"),
    "post_types" => array("post", "page", "properties"),
));
if (is_wp_error($erreurs) && $erreurs->has_errors()) {
    WP_CLI::error("réglages polylang : " . $erreurs->get_error_message());
}
wp_cache_flush();
WP_CLI::success("langues fr (défaut) / en / ar (rtl=1) créées, réglages de référence posés");
PLL_LANGUES
"$PHP" "$WPCLI" eval-file "$LAB/pll-langues.php" --path="$WPDIR" --quiet

cat > "$LAB/pll-masse.php" <<'PLL_MASSE'
<?php
if (!defined("ABSPATH")) { exit("CLI only"); }
$model = isset($GLOBALS["polylang"]) && $GLOBALS["polylang"] ? $GLOBALS["polylang"]->model : null;
if (!$model) { WP_CLI::error("Polylang n'est pas actif"); }
$fr = $model->get_language("fr");
if (!$fr) { WP_CLI::error("langue fr introuvable"); }
$model->set_language_in_mass($fr);
flush_rewrite_rules();
$sans = 0;
foreach (get_posts(array("post_type" => "properties", "post_status" => "any", "numberposts" => 100, "fields" => "ids")) as $pid) {
    if (!pll_get_post_language($pid)) { $sans++; }
}
if ($sans > 0) { WP_CLI::error("$sans annonces properties restent sans langue"); }
WP_CLI::success("contenu existant assigné à fr, rewrites flushed");
PLL_MASSE
"$PHP" "$WPCLI" eval-file "$LAB/pll-masse.php" --path="$WPDIR" --quiet
"$PHP" "$WPCLI" rewrite flush --path="$WPDIR" --quiet

# ── 8. SE-025 trilingue (workflow l.314-340) ──
demarrer_serveur 8099 /fr/ se025
PK_BASE=http://127.0.0.1:8099 "$PHP" "$DEPOT/theme/partikulier/tests/se025-trilingual-routes-contract.php" > "$OUT/contrats/se025-trilingual-routes-contract.json"
echo "PASS  se025-trilingual-routes-contract" | tee -a "$OUT/journal.txt"
arreter_serveur 8099

# ── 9. Oracle 370/370 (adaptation locale du heredoc workflow l.348-350 :
#     quoted delimiter = pas d'interpolation shell → chemin résolu via env) ──
cd "$LAB"
ORACLE_DIR="$OUT/contrats" "$PHP" -r '
$dir = getenv("ORACLE_DIR");
$tot=0; $pas=0; $n=0;
foreach (glob($dir."/*.json") as $f) {
  $d=json_decode(file_get_contents($f), true);
  if (($d["status"] ?? "") !== "PASS") { fwrite(STDERR, basename($f).": status != PASS\n"); exit(1); }
  $tot += (int) $d["total"]; $pas += (int) $d["passed"]; $n++;
}
echo "contrats dynamiques : $pas/$tot (".$n." suites)\n";
if ($tot !== 370 || $pas !== 370 || $n !== 38) { fwrite(STDERR, "oracle inattendu (attendu 370/370 — 38 suites)\n"); exit(1); }'

echo "=== CHAINE DE REFERENCE COMPLETE : 38 suites / 370 assertions ==="
