#!/bin/bash
# REPRISE — R1 : reproduction du défaut de disponibilité sur le lab-ABC
# (actions métier réelles mark_sold/mark_rented/archive + asymétrie refuse),
# MÊME méthode que la sonde de la revue commanditaire (probe-r1.php).
# AUCUNE édition de ListingRepository.php (hors périmètre Phase 1).
set -euo pipefail
RT="${RUNTIME:?}"; LAB="${LAB:?}"; OUT="${SORTIE:?}"
PHP="$RT/php"; WPCLI="$RT/wp-cli.phar"; WPDIR="$LAB/wp"
BASE=http://127.0.0.1:8099
mkdir -p "$OUT/r1"

cat > "$OUT/r1/sonde-r1.php" << 'SONDE'
<?php
if (!defined('WP_CLI')||!WP_CLI||wp_get_environment_type()!=='local')exit(1);
wp_set_current_user(1);
$state=$args[0]??'init';$id=(int)get_option('reprise_phase1_listing');
if($state==='init'){
 $id=wp_insert_post(['post_type'=>'properties','post_status'=>'publish','post_title'=>'REPRISE PHASE1 — fictif sans bien réel','post_name'=>'reprise-phase1-fictif','post_author'=>1,'meta_input'=>['_pk_status'=>'actif','_pk_url_city'=>'casablanca']]);
 update_option('reprise_phase1_listing',$id);pll_set_post_language($id,'fr');
}elseif($state==='refuse_synced'){
 wp_update_post(['ID'=>$id,'post_status'=>'publish']);
}elseif($state==='refuse'){
 update_post_meta($id,'_pk_status','refuse');
}else{
 $res=Partikulier_Dashboard::manage_listing($id,$state,1);
 if(is_wp_error($res))WP_CLI::error($res->get_error_message());
}
(new \Partikulier\Core\Integration\ListingSynchronizer())->flush();
$r=new \Partikulier\Core\ListingRepository();$row=$r->rowForExternalId('estatik:'.$id);$find=$row?$r->find((int)$row['id']):null;
echo wp_json_encode(['action'=>$state,'post_id'=>$id,'post_status'=>get_post_status($id),'pk_status'=>get_post_meta($id,'_pk_status',true),'url'=>get_permalink($id),'projection'=>$row,'individual'=>is_wp_error($find)?['error'=>$find->get_error_code()]:$find],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
SONDE

sonde() { "$PHP" "$WPCLI" eval-file "$OUT/r1/sonde-r1.php" "$1" --path="$WPDIR" 2>/dev/null; }

# Serveur (collection REST via HTTP)
pkill -f "php -S 127.0.0.1:8099" 2>/dev/null || true; sleep 0.3
(cd "$LAB" && PHP_CLI_SERVER_WORKERS=8 "$PHP" -S 127.0.0.1:8099 -t wp theme/partikulier/tests/router-ci.php > "$OUT/r1/serveur.log" 2>&1 &)
sain=false
for i in $(seq 1 60); do code=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/fr/" || true); [ "$code" = "200" ] && { sain=true; break; }; sleep 0.5; done
[ "$sain" = true ] || { echo "FAIL sonde serveur"; exit 1; }

collection_contient() { # $1=external id → "oui"/"non"
  curl -s --max-time 60 "$BASE/wp-json/partikulier/v1/listings?per_page=100" \
    | python3 -c "
import json,sys
try:
    d=json.load(sys.stdin)
    items=d if isinstance(d,list) else d.get('items',d.get('data',[]))
    print('oui' if any(str(i.get('external_id',''))=='$1' for i in items) else 'non')
except Exception:
    print('erreur')
"
}

echo "=== init ===" | tee "$OUT/r1/journal-r1.txt"
sonde init > "$OUT/r1/init-etat.json"; cat "$OUT/r1/init-etat.json" | head -12
echo "init: dans collection = $(collection_contient "estatik:$(python3 -c "import json;print(json.load(open('$OUT/r1/init-etat.json'))['post_id'])")")" | tee -a "$OUT/r1/journal-r1.txt"

for action in mark_sold mark_rented archive refuse refuse_synced; do
  echo "=== $action ===" | tee -a "$OUT/r1/journal-r1.txt"
  sonde "$action" > "$OUT/r1/$action-etat.json"
  python3 - "$OUT/r1/$action-etat.json" << 'PYEOF'
import json, sys
d = json.load(open(sys.argv[1]))
print(f"  post_status={d['post_status']} pk_status={d['pk_status']} projection={'présente' if d['projection'] else 'absente'}")
PYEOF
  ID=$(python3 -c "import json;print(json.load(open('$OUT/r1/$action-etat.json'))['post_id'])")
  echo "  $action: dans collection = $(collection_contient "estatik:$ID")" | tee -a "$OUT/r1/journal-r1.txt"
  python3 - "$OUT/r1/$action-etat.json" << 'PYEOF'
import json, sys
d = json.load(open(sys.argv[1]))
ind = d.get('individual')
err = ind.get('error') if isinstance(ind, dict) else None
print(f"  lecture individuelle: {'erreur ' + err if err else 'OK'}")
PYEOF
done

# fiche publique
# RECTIFICATION EXPURGATION : la fiche publique était écrite sans aucun
# filtre — elle contenait des nonces (champs cachés es_*_nonce_* et données
# JS nonce/placesNonce/submitNonce). Désormais : capture brute TEMPORAIRE,
# passage par expurge-preuves.py (R1-R9), suppression de la brute avant la
# fin du run (jamais exportée), puis garde d'hygiène sur tout le dossier.
ID=$(python3 -c "import json;print(json.load(open('$OUT/r1/init-etat.json'))['post_id'])")
URL=$(python3 -c "import json;print(json.load(open('$OUT/r1/init-etat.json'))['url'])")
CHEMIN=$(python3 -c "import urllib.parse,sys;print(urllib.parse.urlsplit('$URL').path)")
SD="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
command -v python3 > /dev/null 2>&1 || { echo "python3 requis pour expurge-preuves.py"; exit 1; }
EXPURGE_PY="$SD/expurge-preuves.py"
[ -f "$EXPURGE_PY" ] || { echo "$EXPURGE_PY introuvable"; exit 1; }
curl -s --max-time 30 -o "$OUT/r1/fiche-publique.brut" -w "fiche publique: %{http_code}\n" "$BASE$CHEMIN" | tee -a "$OUT/r1/journal-r1.txt"
python3 "$EXPURGE_PY" --filtre < "$OUT/r1/fiche-publique.brut" > "$OUT/r1/fiche-publique.html"
rm -f "$OUT/r1/fiche-publique.brut" # capture brute temporaire : jamais exportée
# garde d'hygiène complète R1-R9 (échec ≠ 0 si secret résiduel)
python3 "$EXPURGE_PY" --scan "$OUT/r1"

# nettoyage de la fixture + extinction
"$PHP" -r 'require "'"$WPDIR"'/wp-load.php"; $id=(int)get_option("reprise_phase1_listing"); wp_delete_post($id,true); delete_option("reprise_phase1_listing"); echo "fixture nettoyee\n";' 2>/dev/null
pkill -f "php -S 127.0.0.1:8099" 2>/dev/null || true; sleep 0.5
for i in $(seq 1 20); do pgrep -f "php -S 127.0.0.1:8099" > /dev/null 2>&1 && { pkill -9 -f "php -S 127.0.0.1:8099" 2>/dev/null || true; sleep 0.5; } || break; done
echo "=== R1 TERMINÉ (défaut confirmé si mark_sold/mark_rented/archive présents en collection) ==="
cat "$OUT/r1/journal-r1.txt"
