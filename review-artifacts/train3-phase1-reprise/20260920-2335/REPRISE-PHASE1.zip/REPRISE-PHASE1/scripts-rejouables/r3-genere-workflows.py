#!/usr/bin/env python3
"""Génère les workflows révisés (reprise F3) :
- workflow-B.yml   : base + étape SE-041 + oracle DURCI 376/376 (39 suites)
- workflow-ABC.yml : base + étape SE-041 + étape SE-027 + oracle DURCI 382/382 (40 suites)
Le validateur durci vérifie : JSON valide, schéma (clés/types/status), cohérence
arithmétique (total===count(results), passed===nb PASS, failed===nb FAIL),
unicité des test_id, aucun FAIL caché sous status PASS, cardinalité et ENSEMBLE
EXACT des suites attendues, totaux globaux. Contre-tests exigés (reprise F3) :
suite manquante / JSON inventé / doublon / JSON invalide / compteur incohérent /
FAIL caché — tous refusés (exit != 0)."""
import sys, re

DEPOT = '/home/z/my-project/phase1-reprise/runtime/depot'
DIFF_B = '/home/z/my-project/upload/analyse-phase1-extrait/revue-livraison-phase1/PHASE1-LOT-B-SE041.diff'
DIFF_C = '/home/z/my-project/upload/analyse-phase1-extrait/revue-livraison-phase1/PHASE1-LOT-C-SE027.diff'
OUT = '/home/z/my-project/phase1-reprise/runtime'

TOTAUX_BASE = {
    "core-contract": 8, "services-contract": 7, "load-contract": 7,
    "rest-lite-scope": 10, "routes-collision": 6, "sync-contract": 14,
    "payments-contract": 10, "premium-contract": 8, "leads-contract": 7,
    "leads-domain-contract": 16, "lead-erase-security-contract": 13,
    "alerts-domain-contract": 15, "automation-domain-contract": 23,
    "owner-stats-domain-contract": 16,
    "translation-variants-domain-contract": 16, "i18n-chrome-domain-contract": 13,
    "i18n-content-domain-contract": 15, "i18n-unified-mechanism-contract": 15,
    "module-perimeter-contract": 11, "avif-security-contract": 15,
    "vestige-extinction-contract": 12, "artifact-hygiene-contract": 3,
    "options-sanitizer-contract": 8, "se022-idempotence-contract": 9,
    "se026-hmac-mode-contract": 4, "slug-redirects-domain-contract": 9,
    "se024-i18n-dedup-contract": 7, "se048-premium-honesty-contract": 6,
    "se035-catalogs-contract": 5, "se036-places-referential-contract": 5,
    "se037-seo-multilingual-contract": 5, "se054-closure-contract": 5,
    "front-assets": 7, "se022-http-battery": 4, "se043-geo-routing-battery": 9,
    "se034-form-idempotency-contract": 6, "search-arrays-contract": 9,
    "se025-trilingual-routes-contract": 12,
}
assert sum(TOTAUX_BASE.values()) == 370, sum(TOTAUX_BASE.values())
TOTAUX_B = dict(TOTAUX_BASE, **{"se041-xmlrpc-contract": 6})
assert sum(TOTAUX_B.values()) == 376
TOTAUX_ABC = dict(TOTAUX_B, **{"se027-rewrite-prefix-contract": 6})
assert sum(TOTAUX_ABC.values()) == 382
SUITES_B = sorted(TOTAUX_B)
SUITES_ABC = sorted(TOTAUX_ABC)

def bloc_oracle_durci(total, table, detail):
    suites = sorted(table)
    lignes_table = ',\n'.join(f'          "{s}.json" => {table[s]}' for s in suites)
    php = f'''      - name: Vérifier l'oracle {total}/{total} (durci — schéma, cohérence, unicité, totaux épinglés par suite ; reprise F3)
        run: |
          # Validateur durci (reprise du 20/09/2026, revue commanditaire F3) :
          # l'ancien validateur additionnait total/passed DECLARES et acceptait
          # un unique faux rapport auto-contradictoire (exit 0 "382/382").
          # Le nouveau contrôle, pour CHAQUE suite : JSON valide ; status ===
          # "PASS" ; total/passed/failed entiers ; passed + failed === total ;
          # failed === 0 ; total === LE total épingle de la suite (table ci-
          # dessous, somme = {total}) ; SI results est fourni : total ===
          # count(results), passed === nb de PASS REELS, aucun FAIL caché sous
          # status PASS, unicité des test_id (les 10 suites historiques sans
          # results — core, services, load, rest-lite, routes-collision, sync,
          # payments, premium, leads, search — sont hors périmètre des diffs
          # Phase 1 : leurs totaux restent épinglés ci-dessous). Cardinalité et
          # ensemble EXACT des {len(suites)} suites attendues ; aucun fichier
          # en trop ou manquant ; total global {total}/{total}.
          php <<'ORACLE'
          <?php
          $attendues = array(
          {lignes_table},
          );
          $fichiers = glob("preuves-run/contrats/*.json");
          $bases = array_map("basename", $fichiers);
          if (count($bases) !== count($attendues)) {{
          fwrite(STDERR, "cardinalite inattendue : attendu " . count($attendues) . " suites, obtenu " . count($bases) . "\\n");
          exit(1);
          }}
          $tot = 0; $pas = 0;
          foreach ($fichiers as $f) {{
          $nom = basename($f);
          if (!isset($attendues[$nom])) {{
          fwrite(STDERR, $nom . " : suite hors ensemble attendu\\n");
          exit(1);
          }}
          $d = json_decode((string) file_get_contents($f), true);
          if (!is_array($d)) {{ fwrite(STDERR, $nom . " : JSON invalide\\n"); exit(1); }}
          foreach (array("status", "total", "passed", "failed") as $cle) {{
          if (!array_key_exists($cle, $d)) {{ fwrite(STDERR, $nom . " : cle manquante " . $cle . "\\n"); exit(1); }}
          }}
          if (!in_array($d["status"], array("PASS", "FAIL"), true)) {{ fwrite(STDERR, $nom . " : status invalide\\n"); exit(1); }}
          if (!is_int($d["total"]) || !is_int($d["passed"]) || !is_int($d["failed"]) || $d["total"] < 0 || $d["passed"] < 0 || $d["failed"] < 0) {{
          fwrite(STDERR, $nom . " : compteurs invalides\\n"); exit(1);
          }}
          if ($d["status"] !== "PASS" || $d["failed"] !== 0) {{ fwrite(STDERR, $nom . " : status != PASS ou failed != 0\\n"); exit(1); }}
          if ($d["passed"] + $d["failed"] !== $d["total"] || $d["passed"] !== $d["total"]) {{
          fwrite(STDERR, $nom . " : compteurs incoherents (total=" . $d["total"] . ", passed=" . $d["passed"] . ", failed=" . $d["failed"] . ")\\n"); exit(1);
          }}
          if ($d["total"] !== $attendues[$nom]) {{
          fwrite(STDERR, $nom . " : total " . $d["total"] . " != total epingle " . $attendues[$nom] . "\\n"); exit(1);
          }}
          if (array_key_exists("results", $d)) {{
          if (!is_array($d["results"])) {{ fwrite(STDERR, $nom . " : results non tableau\\n"); exit(1); }}
          if (count($d["results"]) !== $d["total"]) {{ fwrite(STDERR, $nom . " : count(results) != total\\n"); exit(1); }}
          $ids = array();
          foreach ($d["results"] as $r) {{
          if (!is_array($r) || !isset($r["test_id"], $r["status"]) || !is_string($r["test_id"]) || $r["test_id"] === "" || !in_array($r["status"], array("PASS", "FAIL"), true)) {{
          fwrite(STDERR, $nom . " : resultat malforme\\n"); exit(1);
          }}
          if ($r["status"] !== "PASS") {{ fwrite(STDERR, $nom . " : assertion " . $r["test_id"] . " != PASS sous statut global PASS\\n"); exit(1); }}
          $ids[] = $r["test_id"];
          }}
          if (count($ids) !== count(array_unique($ids))) {{ fwrite(STDERR, $nom . " : test_id dupliques\\n"); exit(1); }}
          }}
          $tot += $d["total"]; $pas += $d["passed"];
          }}
          if ($tot !== {total} || $pas !== {total}) {{ fwrite(STDERR, "oracle inattendu (attendu {total}/{total} — {len(suites)} suites : {detail})\\n"); exit(1); }}
          echo "contrats dynamiques : $pas/$tot (" . count($bases) . " suites, schema, coherence, unicitte, totaux epingles et ensemble exact verifies)\\n";
          ORACLE
'''
    return php

def extraire_hunk_ajout(chemin_diff, fichier):
    """Extrait les lignes '+' d'un hunk d'un fichier précis d'un diff unifié."""
    lignes = open(chemin_diff).read().split('\n')
    dans_fichier, plus = False, []
    for l in lignes:
        if l.startswith('diff --git'):
            dans_fichier = l.endswith(f' b/{fichier}')
            continue
        if not dans_fichier:
            continue
        if l.startswith('@@') or l.startswith('index '):
            continue
        if l.startswith('+') and not l.startswith('+++'):
            plus.append(l[1:])
    return '\n'.join(plus)

DETAIL_B = "370 reference + 6 SE-041 lot B Phase 1"
DETAIL_ABC = "370 reference + 6 SE-041 lot B + 6 SE-027 lot C Phase 1"

# 1. Workflow de base
import subprocess
base = subprocess.run(['git', '-C', DEPOT, 'show', '4b41bd65f2414ea9ce0fd847f144c46fccbab521:.github/workflows/contrats-recette.yml'],
                      capture_output=True, text=True, check=True).stdout

# 2. Étapes extraites des diffs originaux (lignes ajoutées, indentation YAML conservée)
etape_se041 = extraire_hunk_ajout(DIFF_B, '.github/workflows/contrats-recette.yml')
# Le hunk B ajoute l'étape SE-041 ET remplace le nom de l'étape oracle : ne garder que le bloc étape
debut_etape = etape_se041.index('      - name: Contrat SE-041 HTTP réel')
fin_etape = etape_se041.index('kill "$SRV" 2>/dev/null || true', debut_etape) + len('kill "$SRV" 2>/dev/null || true')
etape_se041 = etape_se041[debut_etape:fin_etape]

etape_se027 = extraire_hunk_ajout(DIFF_C, '.github/workflows/contrats-recette.yml')
debut_etape = etape_se027.index('      - name: Contrat SE-027 HTTP réel')
fin_etape = etape_se027.index('kill "$SRV" 2>/dev/null || true', debut_etape) + len('kill "$SRV" 2>/dev/null || true')
etape_se027 = etape_se027[debut_etape:fin_etape]

# 3. Repérer l'étape oracle 370 dans le workflow de base
m = re.search(r'      - name: Vérifier l\'oracle 370/370.*?ORACLE\n', base, re.DOTALL)
assert m, "étape oracle 370 introuvable dans le workflow de base"
oracle370 = m.group(0)

# 4. workflow-B : insérer étape SE-041 avant l'oracle, remplacer l'oracle par le durci 376
w_b = base.replace(oracle370, etape_se041 + '\n' + bloc_oracle_durci(376, TOTAUX_B, DETAIL_B), 1)
assert 'Contrat SE-041 HTTP réel' in w_b and 'oracle 376/376' in w_b and 'oracle 370/370' not in w_b

# 5. workflow-ABC : B + étape SE-027 + oracle durci 382 à la place du 376
m2 = re.search(r"      - name: Vérifier l'oracle 376/376 \(durci.*?ORACLE\n", w_b, re.DOTALL)
assert m2, "oracle durci 376 introuvable dans workflow-B"
w_abc = w_b.replace(m2.group(0), etape_se027 + '\n' + bloc_oracle_durci(382, TOTAUX_ABC, DETAIL_ABC), 1)
assert 'Contrat SE-027 HTTP réel' in w_abc and 'oracle 382/382' in w_abc and 'oracle 376/376' not in w_abc

open(f'{OUT}/workflow-B.yml', 'w').write(w_b)
open(f'{OUT}/workflow-ABC.yml', 'w').write(w_abc)
print(f"workflow-B.yml   : {len(w_b.splitlines())} lignes (oracle durci 376/376, {len(SUITES_B)} suites)")
print(f"workflow-ABC.yml : {len(w_abc.splitlines())} lignes (oracle durci 382/382, {len(SUITES_ABC)} suites)")
