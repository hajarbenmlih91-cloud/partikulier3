#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
expurge-preuves.py — Expurgation et balayage des secrets dans les preuves Phase 1.

Remplace les VALEURS sensibles par [EXPURGE] en conservant les noms de champs,
la syntaxe et le reste du contenu. Couvre (dépasse pk_diag_jeton) :

  R1  JSON/JavaScript : "cle_nonce":"VAL", 'cle':'VAL', cle_nonce: "VAL"
      (clé citée ou nue, guillemets doubles ou simples)
  R2  attributs HTML : <input name/id/data-*="...nonce..." ... value="VAL">
      (ordre des attributs indifférent, guillemets doubles/simples/nus)
  R3  paramètres d'URL : ?cle=VAL, &cle=VAL, &#038;cle=VAL, &amp;cle=VAL
      et formes percent-encodées (%26cle%3DVAL, cle%3DVAL)
  R4  affectation générique nue : cle_nonce=VAL / cle_nonce:VAL (nonce WP 10-14)
  R5  jeton diagnostic : pk_diag_jeton / pk_diag-jeton / pkDiagJeton,
      sous toute forme (URL, JSON, texte)
  R6  cookies de session : wordpress_<h16-64>, wordpress_logged_in_<h16-64>,
      wordpress_sec_<h16-64>, wordpress_test_cookie, wp-settings-N,
      wp-settings-time-N, wp-api-*, wp-cli-*, PHPSESSID
  R7  jetons de session sérialisés : s:64:"<64 car.>" (session_tokens)
  R8  en-têtes Authorization: Bearer/Basic
  R9  compatibilité ancien filtre : wp_customize=...
  R10 affectation à valeur guillemetée : identifiant = "VAL" / 'VAL'
      (clé nue, séparateur =, familles nonce/token/secret/csrf/jeton ;
      ferme l'angle mort v2 : affectations JS du cœur WordPress telles que
      compressionNonce, introuvables par R1 qui exige ':' et par R4 qui
      exige une valeur non guillemetée)

Historique : v3 ajoute R10 (constat de l'audit du commanditaire) et élargit
R6 (noms de cookies) et R7 (valeurs sérialisées) aux chaînes alphanumériques
neutres, afin que les corpus de test à valeurs manifestement fictives
restent couverts par les mêmes règles.

PRINCIPE : aucune valeur sensible n'est affichée ni journalisée. Les rapports
de balayage ne contiennent que la règle, la clé, la longueur et une empreinte
salée (sha256 tronqué) de la valeur — jamais la valeur elle-même.

Modes :
  --filtre              stdin → stdout expurgé (usage : curl … | expurge-preuves.py)
  --fichier FICHIER     expurge FICHIER en place (résumé masqué sur stderr)
  --scan RACINE [--json CHEMIN]
                        balaye l'arborescence, sortie masquée, code de sortie 1
                        si au moins un secret résiduel (garde d'hygiène CI)
  --dry-run RACINE      liste les fichiers qui SERAIENT modifiés (rien n'écrit)

Idempotent : les valeurs déjà [EXPURGE] ne sont jamais retouchées ; réexécuter
le filtre ne modifie plus rien.
"""
import sys, os, re, json, hashlib
from urllib.parse import unquote

SALT = b"expurge-preuves-v1::"
MASK = "[EXPURGE]"

def _fp(v):
    """empreinte salée de la valeur — jamais la valeur elle-même"""
    return hashlib.sha256(SALT + v.encode("utf-8", "surrogateescape")).hexdigest()[:12]

def _saine(v):
    return v and "EXPURGE" not in v.upper()

# ------------------------------------------------------------------ règles
# Chaque règle renvoie : liste de (debut, fin, cle, valeur) où texte[debut:fin]
# est exactement la VALEUR à remplacer par [EXPURGE].

def r1_json_js(t):
    out = []
    for pat in (r'("(?:[^"\\]|\\.)*[Nn]once(?:[^"\\]|\\.)*"\s*:\s*")([^"\s]{8,64})(")',
                r"('(?:[^'\\]|\\.)*[Nn]once(?:[^'\\]|\\.)*'\s*:\s*')([^'\s]{8,64})(')",
                r'\b([A-Za-z0-9_-]*[Nn]once[A-Za-z0-9_-]*\s*:\s*["\'])([A-Za-z0-9_-]{8,64})(["\'])'):
        for m in re.finditer(pat, t):
            v = m.group(2)
            if _saine(v):
                out.append((m.start(2), m.end(2), m.group(1).strip('"\'')[:48], v))
    return out

_ATTR_CLE = re.compile(r'(name|id|data-[A-Za-z0-9_-]+)\s*=\s*(["\'])(.*?)\2', re.I)
_ATTR_VAL = re.compile(r'\b(?:value|content)\s*=\s*(["\']?)([A-Za-z0-9_-]{8,64})\1|(?<![\w-])(?:value|content)\s*=\s*([A-Za-z0-9_-]{8,64})(?=[\s/>])', re.I)

def r2_attribut_html(t):
    out = []
    def tag(mtag):
        tag_txt = mtag.group(0)
        # (a) un attribut name/id/data-* dont la VALEUR contient « nonce »
        #     (ex. name="pk_nonce") → les attributs value/content du même tag
        cles = [k.group(3) for k in _ATTR_CLE.finditer(tag_txt)
                if re.search(r'nonce', k.group(3), re.I)]
        if cles:
            for mv in _ATTR_VAL.finditer(tag_txt):
                v = mv.group(2) or mv.group(3)
                if v and _saine(v):
                    abs_start = mtag.start() + mv.start(2 if mv.group(2) else 3)
                    abs_end = mtag.start() + mv.end(2 if mv.group(2) else 3)
                    out.append((abs_start, abs_end, cles[0][:48], v))
        # (b) un attribut dont le NOM se termine par « nonce »
        #     (ex. data-quick-edit-nonce="SECRET") → sa propre valeur
        for k in _ATTR_CLE.finditer(tag_txt):
            nom_attr, v = k.group(1), k.group(3)
            if re.search(r'nonce$', nom_attr, re.I) and _saine(v):
                out.append((mtag.start() + k.start(3), mtag.start() + k.end(3), nom_attr[:48], v))
    re.sub(r'<[a-zA-Z][^>]*>', tag, t)
    return out

def r3_param_url(t):
    out = []
    for m in re.finditer(r'([?&;])([A-Za-z0-9_%\[\].-]{0,48}[Nn]once[A-Za-z0-9_%\[\].-]{0,48})=([A-Za-z0-9_.~-]{8,64})', t):
        v = m.group(3)
        if _saine(v):
            out.append((m.start(3), m.end(3), m.group(2)[:48], v))
    # formes percent-encodées : la clé (lisible ou encodée) doit contenir un
    # marqueur de secret (« nonce » ou « pk_diag_jeton ») après décodage.
    # NB : pk_diag seul est un paramètre d'action (valeur 1), pas un secret.
    for m in re.finditer(r'((?:%[0-9A-Fa-f]{2}|[A-Za-z0-9_.~-]){1,72}%3[Dd])((?:%[0-9A-Fa-f]{2}|[A-Za-z0-9_.~-]){8,192})', t):
        cle_decodee = unquote(m.group(1)).lower()
        if 'nonce' in cle_decodee or 'pk_diag_jeton' in cle_decodee or 'pkdiagjeton' in cle_decodee:
            v = m.group(2)
            if _saine(v):
                out.append((m.start(2), m.end(2), unquote(m.group(1)).split('=')[0][:48], v))
    return out

def r4_affectation(t):
    out = []
    for m in re.finditer(r'\b([A-Za-z0-9_-]*[Nn]once[A-Za-z0-9_-]*)\s*[:=]{1,2}>?\s*([A-Za-z0-9]{10,14})(?![A-Za-z0-9_=])', t):
        v = m.group(2)
        if _saine(v):
            out.append((m.start(2), m.end(2), m.group(1)[:48], v))
    return out

def r5_jeton_diag(t):
    out = []
    for m in re.finditer(r'(pk_diag_jeton|pk_diag-jeton|pkDiagJeton)(["\']?\s*[:=]{1,2}>?\s*["\']?)([A-Za-z0-9]{8,64})', t):
        v = m.group(3)
        if _saine(v):
            out.append((m.start(3), m.end(3), m.group(1), v))
    return out

def r6_cookie(t):
    out = []
    for m in re.finditer(r'\b(wordpress(?:_logged_in|_sec)?_[A-Za-z0-9]{16,64}|wordpress_test_cookie|wp-settings-[0-9]+|wp-settings-time-[0-9]+|wp-api-[A-Za-z0-9_-]+|wp-cli-[A-Za-z0-9_-]+|PHPSESSID)\s*[=:]\s*["\']?([A-Za-z0-9%+/=._!~*-]{8,512})', t):
        v = m.group(2)
        if _saine(v):
            out.append((m.start(2), m.end(2), m.group(1)[:48], v))
    return out

def r7_session_ser(t):
    out = []
    for m in re.finditer(r's:64:"([A-Za-z0-9_-]{64})"', t):
        v = m.group(1)
        if _saine(v):
            out.append((m.start(1), m.end(1), "session_tokens", v))
    return out

def r8_authorization(t):
    out = []
    for m in re.finditer(r'(Authorization\s*:\s*(?:Bearer|Basic)\s+)([A-Za-z0-9+/=._-]{8,512})', t, re.I):
        v = m.group(2)
        if _saine(v):
            out.append((m.start(2), m.end(2), "Authorization", v))
    return out

def r9_compat(t):
    out = []
    for m in re.finditer(r'(wp_customize=)([a-z0-9_-]+)', t):
        v = m.group(2)
        if _saine(v):
            out.append((m.start(2), m.end(2), "wp_customize", v))
    return out

def r10_affectation_quotee(t):
    out = []
    for m in re.finditer(r'\b([A-Za-z0-9_-]*(?:nonce|token|secret|csrf|jeton)[A-Za-z0-9_-]*)\s*(?<![!=<>])=(?!=)\s*(["\'])([A-Za-z0-9_-]{8,64})\2', t, re.I):
        v = m.group(3)
        if _saine(v):
            out.append((m.start(3), m.end(3), m.group(1)[:48], v))
    return out

REGLES = [(r1_json_js, "R1-json-js"), (r2_attribut_html, "R2-attribut-html"),
          (r3_param_url, "R3-param-url"), (r4_affectation, "R4-affectation"),
          (r5_jeton_diag, "R5-jeton-diag"), (r6_cookie, "R6-cookie"),
          (r7_session_ser, "R7-session-ser"), (r8_authorization, "R8-authorization"),
          (r9_compat, "R9-compat"), (r10_affectation_quotee, "R10-affectation-quotee")]

def _fusion(spans):
    """déduponnalise les intervalles qui se chevauchent (premier arrivé gardé)"""
    pris, out = [], []
    for s, e, cle, v, *reste in sorted(spans, key=lambda x: (x[0], -(x[1] - x[0]))):
        if any(not (e <= ps or s >= pe) for ps, pe in pris):
            continue
        pris.append((s, e))
        out.append((s, e, cle, v, *reste))
    return out

def appliquer(texte):
    """→ (texte_expurgé, [ (règle, clé, longueur, empreinte) ]) sans chevauchement"""
    spans = []
    for fn, nom in REGLES:
        for (s, e, cle, v) in fn(texte):
            spans.append((s, e, cle, v, nom))
    spans = _fusion(spans)
    spans.sort(key=lambda x: x[0])
    morceaux, prec, journal = [], 0, []
    for s, e, cle, v, nom in spans:
        morceaux.append(texte[prec:s]); morceaux.append(MASK)
        prec = e
        journal.append((nom, cle, len(v), _fp(v)))
    morceaux.append(texte[prec:])
    return "".join(morceaux), journal

def balayer(racine, chemin_json=None):
    constats, fichiers = [], 0
    for dirpath, _dirs, files in os.walk(racine):
        for fn in sorted(files):
            p = os.path.join(dirpath, fn)
            rel = os.path.relpath(p, racine)
            try:
                texte = open(p, "rb").read().decode("utf-8", "surrogateescape")
            except OSError:
                continue
            fichiers += 1
            num = 0
            for ligne in texte.split("\n"):
                num += 1
                cumul = []
                for fn_regle, nom in REGLES:
                    for (s, e, cle, v) in fn_regle(ligne):
                        cumul.append((s, e, cle, v, nom))
                # fusion PAR LIGNE : les décalages sont locaux à la ligne,
                # fusionner toutes les lignes ensemble faisait disparaître
                # des constats (bug v2 du mode --scan, corrigé en v3 ;
                # le mode --fichier/expurgation n'était pas concerné)
                for s, e, cle, v, nom in _fusion(cumul):
                    constats.append(dict(fichier=rel, ligne=num, regle=nom, cle=cle,
                                         longueur=len(v), empreinte=_fp(v)))
    if chemin_json:
        with open(chemin_json, "w", encoding="utf-8") as fh:
            json.dump({"racine": racine, "fichiers_balayes": fichiers,
                       "nb_constats": len(constats), "constats": constats},
                      fh, ensure_ascii=False, indent=1)
    return fichiers, constats

# ------------------------------------------------------------------ modes
def main():
    a = sys.argv[1:]
    if not a:
        print(__doc__); sys.exit(2)
    if a[0] == "--filtre" and len(a) == 1:
        data = sys.stdin.buffer.read()
        texte, _ = appliquer(data.decode("utf-8", "surrogateescape"))
        sys.stdout.buffer.write(texte.encode("utf-8", "surrogateescape"))
        sys.exit(0)
    if a[0] == "--fichier" and len(a) == 2:
        p = a[1]
        texte = open(p, "rb").read().decode("utf-8", "surrogateescape")
        nouveau, journal = appliquer(texte)
        if nouveau != texte:
            open(p, "wb").write(nouveau.encode("utf-8", "surrogateescape"))
        par_regle = {}
        for nom, _c, _l, _f in journal:
            par_regle[nom] = par_regle.get(nom, 0) + 1
        print(f"expurge {p}: {len(journal)} valeur(s) → [EXPURGE] "
              f"({', '.join(f'{k}={v}' for k, v in sorted(par_regle.items())) or 'rien'})",
              file=sys.stderr)
        sys.exit(0)
    if a[0] == "--dry-run" and len(a) == 2:
        racine = a[1]
        modifs = []
        for dirpath, _dirs, files in os.walk(racine):
            for fn in sorted(files):
                p = os.path.join(dirpath, fn)
                try:
                    texte = open(p, "rb").read().decode("utf-8", "surrogateescape")
                except OSError:
                    continue
                nouveau, _ = appliquer(texte)
                if nouveau != texte:
                    modifs.append(os.path.relpath(p, racine))
        print(f"fichiers qui seraient modifies : {len(modifs)}")
        for m in modifs:
            print(f"  {m}")
        sys.exit(0)
    if a[0] == "--scan" and len(a) in (2, 4):
        racine = a[1]
        chemin_json = a[3] if len(a) == 4 and a[2] == "--json" else None
        fichiers, constats = balayer(racine, chemin_json)
        nb_f = len({c["fichier"] for c in constats})
        print(f"balayage: {fichiers} fichiers, {len(constats)} secret(s) residuel(s) dans {nb_f} fichier(s)")
        for c in constats:
            print(f"  {c['fichier']}:{c['ligne']} {c['regle']} cle={c['cle']!r} longueur={c['longueur']} emp={c['empreinte']}")
        if constats:
            print("ECHEC HYGIENE : valeur(s) sensible(s) detectee(s) — aucune valeur affichee")
            sys.exit(1)
        print(f"hygiene OK : aucune valeur sensible dans le perimetre des regles R1-R10 ({fichiers} fichiers)")
        sys.exit(0)
    print(__doc__); sys.exit(2)

if __name__ == "__main__":
    main()
