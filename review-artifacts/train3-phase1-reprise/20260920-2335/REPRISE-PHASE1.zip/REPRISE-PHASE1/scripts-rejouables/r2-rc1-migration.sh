#!/bin/bash
# REPRISE — RC-1 : migration SE-027 sur lab à l'état A+B' puis application C'.
# Phases : (1) contexte Polylang post-SE-025 ; (2) dump AVANT (code 4/stockée 4,
# 303 règles/5 doubles) ; (3) démo négative contrat v2 sur code SANS C ;
# (4) application C' (fichiers copiés : code 5/stockée 4) ; (5) maybe_flush →
# migration (5/5, 298/0) + 3 flush stables + idempotence ; (6) contrat v2 6/6.
# Usage: RUNTIME=... LAB=... DEPOTLAB=<clone a A+B'> SORTIE=... bash r2-rc1-migration.sh
set -euo pipefail
RT="${RUNTIME:?}"; LAB="${LAB:?}"; DEPOTLAB="${DEPOTLAB:?}"; OUT="${SORTIE:?}"
PHP="$RT/php"; WPCLI="$RT/wp-cli.phar"; WPDIR="$LAB/wp"
mkdir -p "$OUT"

dump_table() { # $1=etiquette → $OUT/rewrite-<etiquette>.json
  "$PHP" -r '
require "'"$WPDIR"'/wp-load.php";
$table = get_option("rewrite_rules", []);
$langues = function_exists("pll_languages_list") ? (array) pll_languages_list(["fields" => "slug"]) : [];
$doubles = [];
foreach ($table as $regex => $t) {
    if (preg_match("~^\^?\((?:\?:)?([^()]+)\)/\((?:\?:)?([^()]+)\)/~", (string) $regex, $m)) {
        $g = function ($gr) use ($langues) { $p = explode("|", $gr); return $p !== [] && count(array_unique($p)) === count($p) && array_diff($p, $langues) === []; };
        if ($g($m[1]) && $g($m[2])) { $doubles[$regex] = $t; }
    }
}
file_put_contents("'"$OUT"'/rewrite-" . $argv[1] . ".json", json_encode([
    "version_code" => (new ReflectionClassConstant("Partikulier_Listing_Urls", "RULES_VERSION"))->getValue(),
    "version_stockee" => get_option("pk_url_rules_version"),
    "regles" => count($table),
    "doubles" => array_keys($doubles),
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
echo "dump $argv[1] : " . count($table) . " regles, " . count($doubles) . " doubles\n";
' "$1" 2>/dev/null
}

# ── 1. Contexte Polylang (comme après SE-025 dans la chaîne) ──
"$PHP" "$WPCLI" plugin activate polylang --path="$WPDIR" --quiet
cat > "$LAB/pll-langues.php" <<'PLL_LANGUES'
<?php
$model = isset($GLOBALS["polylang"]) && $GLOBALS["polylang"] ? $GLOBALS["polylang"]->model : null;
if (!$model) { WP_CLI::error("Polylang n'est pas actif"); }
$langues = array(
    array("name" => "Français", "slug" => "fr", "locale" => "fr_FR", "rtl" => 0, "flag" => "fr", "term_group" => 1),
    array("name" => "English", "slug" => "en", "locale" => "en_US", "rtl" => 0, "flag" => "us", "term_group" => 0),
    array("name" => "العربية", "slug" => "ar", "locale" => "ar", "rtl" => 1, "flag" => "ma", "term_group" => 2),
);
foreach ($langues as $l) { if (!$model->get_language($l["slug"])) { $r = $model->add_language($l); if (is_wp_error($r)) { WP_CLI::error("add_language"); } } }
$e = $GLOBALS["polylang"]->options->merge(array(
    "force_lang" => 1, "hide_default" => 0, "browser" => 0, "redirect_lang" => 0, "default_lang" => "fr",
    "taxonomies" => array("es_type", "es_status", "es_location", "es_category"),
    "post_types" => array("post", "page", "properties"),
));
if (is_wp_error($e) && $e->has_errors()) { WP_CLI::error("merge"); }
wp_cache_flush();
WP_CLI::success("langues posées");
PLL_LANGUES
"$PHP" "$WPCLI" eval-file "$LAB/pll-langues.php" --path="$WPDIR" --quiet
cat > "$LAB/pll-masse.php" <<'PLL_MASSE'
<?php
$model = isset($GLOBALS["polylang"]) && $GLOBALS["polylang"] ? $GLOBALS["polylang"]->model : null;
$fr = $model->get_language("fr");
$model->set_language_in_mass($fr);
flush_rewrite_rules();
WP_CLI::success("masse fr + flush");
PLL_MASSE
"$PHP" "$WPCLI" eval-file "$LAB/pll-masse.php" --path="$WPDIR" --quiet
"$PHP" "$WPCLI" rewrite flush --path="$WPDIR" --quiet
echo "contexte polylang pret"

# ── 2. Dump AVANT (thème A+B' : défaut vivant) ──
dump_table avant

# ── 3. Démo négative : contrat v2 sur code SANS C (FAIL attendu) ──
pkill -f "php -S 127.0.0.1:8099" 2>/dev/null || true; sleep 0.3
(cd "$LAB" && PHP_CLI_SERVER_WORKERS=8 "$PHP" -S 127.0.0.1:8099 -t wp theme/partikulier/tests/router-ci.php > "$OUT/serveur.log" 2>&1 &)
sain=false
for i in $(seq 1 60); do code=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8099/fr/ || true); [ "$code" = "200" ] && { sain=true; break; }; sleep 0.5; done
[ "$sain" = true ] || { echo "FAIL sonde"; exit 1; }
CONTRAT_V2="$(git -C "$RT/depot" rev-parse --show-toplevel 2>/dev/null || echo "$RT/depot")/theme/partikulier/tests/se027-rewrite-prefix-contract.php"
PK_BASE=http://127.0.0.1:8099 PK_WP_DIR="$WPDIR" PK_COMMIT=4b41bd65f2414ea9ce0fd847f144c46fccbab521 \
PK_WP_CLI="$PHP $WPCLI" "$PHP" "$CONTRAT_V2" > "$OUT/contre-preuve-code-sans-C.json" 2>/dev/null || true
python3 -c "
import json
d=json.load(open('$OUT/contre-preuve-code-sans-C.json'))
print('demo negative (code A+B sans C):', d['status'], d['passed'], '/', d['total'])
for r in d['results']: print(' ', r['status'], r['test_id'])
"

# ── 4. Application C' (fichiers copiés, migration PAS encore déclenchée) ──
cd "$DEPOTLAB"
git apply "$RT/PHASE1-LOT-C-SE027-reprise.diff"
rsync -a --delete --exclude='.git' --exclude='.github' theme/partikulier/ "$WPDIR/wp-content/themes/partikulier/"
echo "C' appliqué (fichiers copiés)"
dump_table apres-copie-avant-migration

# ── 5. Migration : maybe_flush → 5/5, puis 3 flush + idempotence ──
"$PHP" -r '
require "'"$WPDIR"'/wp-load.php";
Partikulier_Listing_Urls::maybe_flush();
' 2>/dev/null
dump_table apres-migration
for i in 1 2 3; do
  "$PHP" -r 'require "'"$WPDIR"'/wp-load.php"; Partikulier_Listing_Urls::flush();' 2>/dev/null
  dump_table "flush-$i"
done
"$PHP" -r '
require "'"$WPDIR"'/wp-load.php";
$avant = get_option("rewrite_rules");
Partikulier_Listing_Urls::maybe_flush();
$apres = get_option("rewrite_rules");
echo ($avant === $apres ? "idempotence: OUI" : "idempotence: NON") . "\n";
' 2>/dev/null | tee "$OUT/idempotence.txt"

# ── 6. Contrat v2 sur code corrigé (PASS 6/6 attendu) ──
PK_BASE=http://127.0.0.1:8099 PK_WP_DIR="$WPDIR" PK_COMMIT=4b41bd65f2414ea9ce0fd847f144c46fccbab521 \
PK_WP_CLI="$PHP $WPCLI" "$PHP" "$WPDIR/wp-content/themes/partikulier/tests/se027-rewrite-prefix-contract.php" > "$OUT/contrat-se027-v2.json" 2>/dev/null || true
python3 -c "
import json
d=json.load(open('$OUT/contrat-se027-v2.json'))
print('contrat se027 v2 (apres migration):', d['status'], d['passed'], '/', d['total'])
for r in d['results']:
    if r['status'] != 'PASS': print(' FAIL', r['test_id'], r['detail'][:200])
"

# extinction propre
pkill -f "php -S 127.0.0.1:8099" 2>/dev/null || true; sleep 0.5
for i in $(seq 1 20); do pgrep -f "php -S 127.0.0.1:8099" > /dev/null 2>&1 && { pkill -9 -f "php -S 127.0.0.1:8099" 2>/dev/null || true; sleep 0.5; } || break; done
echo "=== RC-1 TERMINÉ ==="
