#!/bin/bash
# REPRISE — chaîne complète sur installation FRAÎCHE à l'état AB ou ABC
# (39 suites/376 ou 40 suites/382, oracle DURCI extrait du workflow de l'état).
# Usage: RUNTIME=... DEPOTETAT=<clone git a l'etat AB|ABC> ETAT=AB|ABC \
#        LAB=... SORTIE=... bash r5-chaine-etat.sh
set -euo pipefail
RT="${RUNTIME:?}"; LAB="${LAB:?}"; DEPOT="${DEPOTETAT:?}"; ETAT="${ETAT:?}"
OUT="${SORTIE:?}"
PHP="$RT/php"; WPCLI="$RT/wp-cli.phar"; WPDIR="$LAB/wp"
COMMIT="$(git -C "$DEPOT" rev-parse HEAD)"
mkdir -p "$OUT/contrats"; : > "$OUT/journal.txt"

demarrer_serveur() { # $1=port $2=chemin_sonde $3=label $4=mode(200|connect) $5=workers
  local port="$1" sonde="$2" label="$3" mode="${4:-200}" workers="${5:-4}"
  pkill -f "php -S 127.0.0.1:$port" 2>/dev/null || true; sleep 0.3
  (cd "$LAB" && PHP_CLI_SERVER_WORKERS=$workers "$PHP" -S "127.0.0.1:$port" -t wp theme/partikulier/tests/router-ci.php > "$(realpath "$OUT")/serveur-$label.log" 2>&1 &)
  local sain=false code=""
  for i in $(seq 1 60); do
    code=$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$port$sonde" || true)
    if [ "$mode" = "connect" ] && [ -n "$code" ] && [ "$code" != "000" ]; then sain=true; break; fi
    if [ "$mode" = "200" ] && [ "$code" = "200" ]; then sain=true; break; fi
    sleep 0.5
  done
  if [ "$sain" != true ]; then echo "FAIL sonde $label (code=$code)" | tee -a "$OUT/journal.txt"; return 1; fi
}
arreter_serveur() {
  pkill -f "php -S 127.0.0.1:$1" 2>/dev/null || true; sleep 0.5
  for i in $(seq 1 20); do
    if pgrep -f "php -S 127.0.0.1:$1" > /dev/null 2>&1; then pkill -9 -f "php -S 127.0.0.1:$1" 2>/dev/null || true; sleep 0.5; else break; fi
  done
}

export PK_WP_DIR="$WPDIR" PK_COMMIT="$COMMIT" PK_REPO_DIR="$DEPOT" PK_THEME_DIR="$DEPOT/theme/partikulier"

# ── 1. Les 32 suites dynamiques ──
cd "$WPDIR"
for suite in core-contract services-contract load-contract rest-lite-scope \
             routes-collision sync-contract payments-contract premium-contract \
             leads-contract leads-domain-contract lead-erase-security-contract \
             alerts-domain-contract automation-domain-contract \
             owner-stats-domain-contract \
             translation-variants-domain-contract i18n-chrome-domain-contract \
             i18n-content-domain-contract i18n-unified-mechanism-contract \
             module-perimeter-contract avif-security-contract \
             vestige-extinction-contract artifact-hygiene-contract \
             options-sanitizer-contract se022-idempotence-contract \
             se026-hmac-mode-contract slug-redirects-domain-contract \
             se024-i18n-dedup-contract se048-premium-honesty-contract \
             se035-catalogs-contract se036-places-referential-contract \
             se037-seo-multilingual-contract se054-closure-contract; do
  if "$PHP" "wp-content/plugins/partikulier-core/tests/$suite.php" \
       > "$OUT/contrats/$suite.json" 2> "$OUT/contrats/$suite.err"; then
    echo "PASS  $suite" | tee -a "$OUT/journal.txt"
  else
    echo "FAIL  $suite" | tee -a "$OUT/journal.txt"; exit 1
  fi
done
cd "$LAB"

# ── 2. front-assets ──
demarrer_serveur 8099 / front-assets 200 4
PK_BASE=http://127.0.0.1:8099 PK_ESTATIK_FILE="$WPDIR/wp-content/plugins/estatik/estatik.php" \
  node "$DEPOT/theme/partikulier/tests/front-assets.mjs" > "$OUT/contrats/front-assets.json"
echo "PASS  front-assets" | tee -a "$OUT/journal.txt"; arreter_serveur 8099

# ── 3. SE-022 (port 8101, sonde connect) ──
demarrer_serveur 8101 / se022 connect 4
PK_BASE=http://127.0.0.1:8101 "$PHP" "$DEPOT/plugin/partikulier-core/tests/se022-http-battery.php" > "$OUT/contrats/se022-http-battery.json"
echo "PASS  se022-http-battery" | tee -a "$OUT/journal.txt"; arreter_serveur 8101

# ── 4. SE-043 ──
demarrer_serveur 8099 / se043 200 4
PK_BASE=http://127.0.0.1:8099 "$PHP" "$DEPOT/plugin/partikulier-core/tests/se043-geo-routing-battery.php" > "$OUT/contrats/se043-geo-routing-battery.json"
echo "PASS  se043-geo-routing-battery" | tee -a "$OUT/journal.txt"; arreter_serveur 8099

# ── 5. SE-034 ──
demarrer_serveur 8099 / se034 200 4
PK_BASE=http://127.0.0.1:8099 "$PHP" "$DEPOT/plugin/partikulier-core/tests/se034-form-idempotency-contract.php" > "$OUT/contrats/se034-form-idempotency-contract.json"
echo "PASS  se034-form-idempotency-contract" | tee -a "$OUT/journal.txt"; arreter_serveur 8099

# ── 6. search-arrays ──
demarrer_serveur 8099 / search-arrays 200 4
PK_BASE=http://127.0.0.1:8099 "$PHP" "$DEPOT/theme/partikulier/tests/search-arrays-contract.php" > "$OUT/contrats/search-arrays-contract.json"
echo "PASS  search-arrays-contract" | tee -a "$OUT/journal.txt"; arreter_serveur 8099

# ── 7. Polylang fr/en/ar + réglages de référence ──
"$PHP" "$WPCLI" plugin activate polylang --path="$WPDIR" --quiet
cat > "$LAB/pll-langues.php" <<'PLL_LANGUES'
<?php
if (!defined("ABSPATH")) { exit("CLI only"); }
$model = isset($GLOBALS["polylang"]) && $GLOBALS["polylang"] ? $GLOBALS["polylang"]->model : null;
if (!$model) { WP_CLI::error("Polylang n'est pas actif"); }
$langues = array(
    array("name" => "Français", "slug" => "fr", "locale" => "fr_FR", "rtl" => 0, "flag" => "fr", "term_group" => 1),
    array("name" => "English", "slug" => "en", "locale" => "en_US", "rtl" => 0, "flag" => "us", "term_group" => 0),
    array("name" => "العربية", "slug" => "ar", "locale" => "ar", "rtl" => 1, "flag" => "ma", "term_group" => 2),
);
foreach ($langues as $l) {
    if (!$model->get_language($l["slug"])) {
        $res = $model->add_language($l);
        if (is_wp_error($res)) { WP_CLI::error("langue ".$l["slug"]." : ".$res->get_error_message()); }
    }
}
$erreurs = $GLOBALS["polylang"]->options->merge(array(
    "force_lang" => 1, "hide_default" => 0, "browser" => 0, "redirect_lang" => 0,
    "default_lang" => "fr",
    "taxonomies" => array("es_type", "es_status", "es_location", "es_category"),
    "post_types" => array("post", "page", "properties"),
));
if (is_wp_error($erreurs) && $erreurs->has_errors()) { WP_CLI::error("réglages polylang : " . $erreurs->get_error_message()); }
wp_cache_flush();
WP_CLI::success("langues fr (défaut) / en / ar (rtl=1) créées, réglages de référence posés");
PLL_LANGUES
"$PHP" "$WPCLI" eval-file "$LAB/pll-langues.php" --path="$WPDIR" --quiet
cat > "$LAB/pll-masse.php" <<'PLL_MASSE'
<?php
if (!defined("ABSPATH")) { exit("CLI only"); }
$model = isset($GLOBALS["polylang"]) && $GLOBALS["polylang"] ? $GLOBALS["polylang"]->model : null;
if (!$model) { WP_CLI::error("Polylang n'est pas actif"); }
$fr = $model->get_language("fr");
if (!$fr) { WP_CLI::error("langue fr introuvable"); }
$model->set_language_in_mass($fr);
flush_rewrite_rules();
$sans = 0;
foreach (get_posts(array("post_type" => "properties", "post_status" => "any", "numberposts" => 100, "fields" => "ids")) as $pid) {
    if (!pll_get_post_language($pid)) { $sans++; }
}
if ($sans > 0) { WP_CLI::error("$sans annonces properties restent sans langue"); }
WP_CLI::success("contenu existant assigné à fr, rewrites flushed");
PLL_MASSE
"$PHP" "$WPCLI" eval-file "$LAB/pll-masse.php" --path="$WPDIR" --quiet
"$PHP" "$WPCLI" rewrite flush --path="$WPDIR" --quiet

# ── 8. SE-025 ──
demarrer_serveur 8099 /fr/ se025 200 4
PK_BASE=http://127.0.0.1:8099 "$PHP" "$DEPOT/theme/partikulier/tests/se025-trilingual-routes-contract.php" > "$OUT/contrats/se025-trilingual-routes-contract.json"
echo "PASS  se025-trilingual-routes-contract" | tee -a "$OUT/journal.txt"; arreter_serveur 8099

# ── 9. SE-041 (étape du workflow, présent en AB et ABC) ──
demarrer_serveur 8099 /fr/ se041 200 8
PK_BASE=http://127.0.0.1:8099 PK_WP_DIR="$WPDIR" PK_COMMIT="$COMMIT" \
  "$PHP" "$DEPOT/theme/partikulier/tests/se041-xmlrpc-contract.php" > "$OUT/contrats/se041-xmlrpc-contract.json"
echo "PASS  se041-xmlrpc-contract" | tee -a "$OUT/journal.txt"; arreter_serveur 8099

# ── 10. SE-027 (étape du workflow, ABC uniquement) ──
if [ "$ETAT" = "ABC" ]; then
  demarrer_serveur 8099 /fr/ se027 200 8
  PK_BASE=http://127.0.0.1:8099 PK_WP_DIR="$WPDIR" PK_COMMIT="$COMMIT" \
  PK_WP_CLI="$PHP $WPCLI" \
    "$PHP" "$DEPOT/theme/partikulier/tests/se027-rewrite-prefix-contract.php" > "$OUT/contrats/se027-rewrite-prefix-contract.json"
  echo "PASS  se027-rewrite-prefix-contract" | tee -a "$OUT/journal.txt"; arreter_serveur 8099
fi

# ── 11. Oracle DURCI — extrait du workflow de l'état (code livré = code testé).
# Le validateur utilise le chemin RELATIF preuves-run/contrats/*.json (comme en
# CI, CWD = workspace) : on reproduit la structure de rejeu dans $OUT. ──
python3 - "$DEPOT/.github/workflows/contrats-recette.yml" "$OUT/extrait-oracle-$ETAT.php" << 'PYEOF'
import sys
wf = open(sys.argv[1]).read().splitlines()
debut = next(i for i, l in enumerate(wf) if l.strip() == "php <<'ORACLE'")
fin = next(i for i in range(debut + 1, len(wf)) if wf[i].strip() == 'ORACLE')
bloc = [l[10:] if l.startswith(' ' * 10) else l for l in wf[debut + 1:fin]]
open(sys.argv[2], 'w').write('\n'.join(bloc) + '\n')
PYEOF
mkdir -p "$OUT/preuves-run"
ln -sfn ../contrats "$OUT/preuves-run/contrats"
cd "$OUT"
ORACLE_DIR="$OUT/contrats" "$PHP" "$OUT/extrait-oracle-$ETAT.php"
echo "=== CHAINE $ETAT COMPLETE : oracle durci ACCEPTÉ ==="
