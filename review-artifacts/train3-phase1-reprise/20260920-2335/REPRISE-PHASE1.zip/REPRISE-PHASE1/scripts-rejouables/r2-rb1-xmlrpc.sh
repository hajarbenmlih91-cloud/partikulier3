#!/bin/bash
# REPRISE — RB-1 : reproduction SE-041 avant/après (XML-RPC) sur un lab.
# Usage: RUNTIME=... LAB=... ETAT=avant|apres SORTIE=... bash r2-rb1-xmlrpc.sh
set -euo pipefail
RT="${RUNTIME:?}"; LAB="${LAB:?}"; OUT="${SORTIE:?}"; ETAT="${ETAT:?}"
PHP="$RT/php"
BASE=http://127.0.0.1:8099
mkdir -p "$OUT"

pkill -f "php -S 127.0.0.1:8099" 2>/dev/null || true; sleep 0.3
(cd "$LAB" && PHP_CLI_SERVER_WORKERS=4 "$PHP" -S 127.0.0.1:8099 -t wp theme/partikulier/tests/router-ci.php > "$OUT/serveur.log" 2>&1 &)
sain=false
for i in $(seq 1 60); do
  code=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/" || true)
  [ "$code" = "200" ] && { sain=true; break; }; sleep 0.5
done
[ "$sain" = true ] || { echo "FAIL sonde serveur"; exit 1; }

xmlrpc() { # $1=methode $2=parametres XML internes → corps réponse
  curl -s --max-time 30 -X POST -H 'Content-Type: text/xml' \
    --data "<?xml version='1.0'?><methodCall><methodName>$1</methodName><params>$2</params></methodCall>" \
    "$BASE/xmlrpc.php"
}

# 1. system.listMethods → dump + comptage (méthodes = lignes <value><string>)
xmlrpc system.listMethods '' > "$OUT/listmethods.xml"
NB=$(grep -c '<value><string>' "$OUT/listmethods.xml" || true)
echo "$NB" > "$OUT/listmethods.nb"

# 2. demo.sayHello
xmlrpc demo.sayHello '' > "$OUT/hello.xml"

# 3. pingback.ping (cible fictive locale — le faultCode attendu suffit)
xmlrpc pingback.ping '<param><value><string>http://127.0.0.1:8099/x</string></value></param><param><value><string>http://127.0.0.1:8099/y</string></value></param>' > "$OUT/pingback.xml"

# 4. synthèse (XML indenté : aplatir avant grep)
{
  echo "ETAT: $ETAT — $(date -u +%FT%TZ)"
  echo "system.listMethods: $NB methodes"
  echo "demo.sayHello: $(tr '\n' ' ' < "$OUT/hello.xml" | grep -oE 'Hello!|faultCode</name> *<value> *<int>[-0-9]+' | head -2 | tr '\n' ' ')"
  echo "pingback.ping: $(tr '\n' ' ' < "$OUT/pingback.xml" | grep -oE 'faultCode</name> *<value> *<int>[-0-9]+' | head -1)"
} > "$OUT/mesure.txt"

# extinction propre (workers orphelins)
pkill -f "php -S 127.0.0.1:8099" 2>/dev/null || true; sleep 0.5
for i in $(seq 1 20); do
  if pgrep -f "php -S 127.0.0.1:8099" > /dev/null 2>&1; then
    pkill -9 -f "php -S 127.0.0.1:8099" 2>/dev/null || true; sleep 0.5
  else break; fi
done
cat "$OUT/mesure.txt"
