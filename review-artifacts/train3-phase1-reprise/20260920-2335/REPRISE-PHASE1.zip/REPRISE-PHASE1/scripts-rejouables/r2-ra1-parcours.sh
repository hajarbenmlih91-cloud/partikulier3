#!/bin/bash
# REPRISE — RA-1 : reproduction SE-032 avant/après + parcours signé complet,
# avec EXPURGATION DES JETONS À LA SOURCE (reprise §5 : les captures admin de
# la livraison v1 contenaient 7 nonces pk_diag_jeton non expurgés).
# Usage: RUNTIME=... LAB=... DEPOTLAB=... SORTIE=... ETAT=avant|apres bash r2-ra1-parcours.sh
set -euo pipefail
RT="${RUNTIME:?}"; LAB="${LAB:?}"; DEPOTLAB="${DEPOTLAB:?}"; OUT="${SORTIE:?}"; ETAT="${ETAT:?}"
PHP="$RT/php"
WPDIR="$LAB/wp"
BASE=http://127.0.0.1:8099
JAR="$OUT/cookies.txt"

mkdir -p "$OUT"

# ── Expurgation à la source : tout fichier écrit passe par ce filtre ──
# RECTIFICATION EXPURGATION : l'ancien filtre sed ne couvrait que les formes
# URL de 4 paramètres (pk_diag_jeton/_wpnonce/pk_nonce/wp_customize) avec
# valeurs hexadécimales minuscules — il laissait passer les champs cachés
# HTML (name="...nonce..." value="..."), les données JavaScript/JSON, les
# autres noms de clés nonce, les valeurs mixtes, les cookies de session et
# les jetons sérialisés. Désormais tout passe par expurge-preuves.py qui
# couvre R1-R9 (JSON/JS, attributs HTML, URL encodées ou non, affectations
# nues, jeton diagnostic, cookies, session_tokens, Authorization).
SD="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
command -v python3 > /dev/null 2>&1 || { echo "python3 requis pour expurge-preuves.py"; exit 1; }
EXPURGE_PY="$SD/expurge-preuves.py"
[ -f "$EXPURGE_PY" ] || { echo "$EXPURGE_PY introuvable"; exit 1; }
expurge() { # stdin → stdout, valeurs sensibles remplacées par [EXPURGE]
  python3 "$EXPURGE_PY" --filtre
}
ecrire() { # $1=fichier ; stdin = contenu brut → expurgé sur disque
  local f="$OUT/$1"
  mkdir -p "$(dirname "$f")"
  expurge > "$f"
}

# ── Serveur (géométrie workflow + WORKERS : le diagnostic signé fait des
#    sous-requêtes HTTP vers son propre site — mono-thread = deadlock,
#    la revue commanditaire utilise 4 workers, on en met 8) ──
pkill -f "127.0.0.1:8099" 2>/dev/null || true; sleep 0.3
(cd "$LAB" && PHP_CLI_SERVER_WORKERS=8 "$PHP" -S 127.0.0.1:8099 -t wp theme/partikulier/tests/router-ci.php > "$OUT/serveur.log" 2>&1 &)
sain=false
for i in $(seq 1 60); do
  code=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/" || true)
  [ "$code" = "200" ] && { sain=true; break; }; sleep 0.5
done
[ "$sain" = true ] || { echo "FAIL sonde serveur"; exit 1; }

# ── 1. Accès direct au fichier diagnostic (E-3201) ──
curl -s --max-time 30 -o "$OUT/direct.body" -w '%{http_code} %{size_download}' "$BASE/wp-content/themes/partikulier/pk-diagnostic.php" > "$OUT/direct-mesure.txt"
echo "" >> "$OUT/direct-mesure.txt"

# ── 2. Parcours signé (même parcours que la revue commanditaire) ──
# NB hygiene : le bocal à cookies ($JAR) et les captures brutes
# (rapport-signe.brut) sont des artefacts temporaires — supprimés avant la
# fin du run (jamais exportés dans les preuves).
rm -f "$JAR"
# login
curl -s --max-time 30 -c "$JAR" "$BASE/wp-login.php" | ecrire login.html
curl -s --max-time 30 -b "$JAR" -c "$JAR" -o /dev/null -w '%{http_code}' \
  -d 'log=admin&pwd=admin&redirect_to='"$BASE"'/wp-admin/&testcookie=1' \
  "$BASE/wp-login.php" > "$OUT/login-statut.txt"
# écran admin
curl -s --max-time 60 -b "$JAR" "$BASE/wp-admin/admin.php?page=pk-diagnostic" | ecrire admin-ecran.html
# extraction du lien signé (corps en mémoire, le jeton sert à la requête,
# jamais écrit). NB : WordPress encode & en &#038; dans les href (esc_url) —
# le motif accepte &amp; ET &#038; ; le lien retenu est le rapport COMPLET
# (fermeture " juste après le jeton : exclut les variantes json/lite/quick).
LIEN=$(curl -s --max-time 60 -b "$JAR" "$BASE/wp-admin/admin.php?page=pk-diagnostic" \
  | grep -oE 'href="[^"]*pk_diag=1(&(amp;|#038;))pk_diag_jeton=[a-f0-9]+"' | head -1 \
  | sed -E 's/^href="//; s/"$//; s/&(amp;|#038;)/\&/g')
JETON=""
if [ -n "$LIEN" ]; then
  JETON=$(printf '%s' "$LIEN" | grep -oE 'pk_diag_jeton=[a-f0-9]+' | cut -d= -f2)
fi
echo "lien signe trouve: $([ -n "$LIEN" ] && echo oui || echo NON)" > "$OUT/lien-signe.txt"

# rapport signé complet (texte, sans quick/json/lite) — max-time généreux :
# le diagnostic interroge de nombreuses pages du site en sous-requêtes
if [ -n "$JETON" ]; then
  curl -s --max-time 240 -b "$JAR" -o "$OUT/rapport-signe.brut" -w '%{http_code} %{size_download} %{content_type}' \
    "$BASE/?pk_diag=1&pk_diag_jeton=$JETON" > "$OUT/rapport-signe-mesure.txt"
  echo "" >> "$OUT/rapport-signe-mesure.txt"
  # le rapport est-il SANS jeton à l'intérieur ? expurgé par sécurité
  expurge < "$OUT/rapport-signe.brut" > "$OUT/rapport-signe.txt"
  head -c 400 "$OUT/rapport-signe.txt" > "$OUT/rapport-signe-extrait.txt"
  rm -f "$OUT/rapport-signe.brut" # capture brute temporaire : jamais exportée
  # rejet : sans jeton
  curl -s --max-time 30 -b "$JAR" -o - -w '\nHTTP %{http_code}' "$BASE/?pk_diag=1" | ecrire jeton-absent.txt
else
  echo "AUCUN lien signe (etat $ETAT)" > "$OUT/rapport-signe.txt"
fi

# anonyme (sans cookies) : la racine reste une page ordinaire
curl -s --max-time 30 -o - "$BASE/" | ecrire anonyme.html

# ── 3. Synthèse mesure.txt ──
{
  echo "ETAT: $ETAT — $(date -u +%FT%TZ)"
  echo "commit lab: $(git -C "$DEPOTLAB" rev-parse HEAD 2>/dev/null || echo n/a)"
  echo "acces direct pk-diagnostic.php: $(cat "$OUT/direct-mesure.txt")"
  echo "login statut: $(cat "$OUT/login-statut.txt") (302 attendu)"
  echo "lien signe: $(cat "$OUT/lien-signe.txt")"
  echo "rapport signe: $(cat "$OUT/rapport-signe-mesure.txt" 2>/dev/null || echo n/a)"
  # RECTIFICATION EXPURGATION : la garde d'hygiène grep ne couvrait que 3
  # formes URL — elle validait à tort « 0 jeton résiduel » alors que des
  # nonces administrateur subsistaient en champs cachés et en JS. Désormais
  # balayage complet R1-R9 (aucune valeur affichée, échec ≠ 0 si résidu).
  if garde=$(python3 "$EXPURGE_PY" --scan "$OUT" 2>&1); then
    echo "garde hygiene: OK — $garde"
  else
    echo "garde hygiene: ECHEC — $garde"
    exit 1
  fi
} > "$OUT/mesure.txt"

pkill -f "php -S 127.0.0.1:8099" 2>/dev/null || true; sleep 0.5
# Les workers orphelins ne meurent pas toujours avec le master : boucle
# d'extinction vérifiée (sinon la commande hôte attend les processus restants).
for i in $(seq 1 20); do
  if pgrep -f "php -S 127.0.0.1:8099" > /dev/null 2>&1; then
    pkill -9 -f "php -S 127.0.0.1:8099" 2>/dev/null || true; sleep 0.5
  else break; fi
done
rm -f "$JAR"
cat "$OUT/mesure.txt"
