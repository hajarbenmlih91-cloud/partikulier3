#!/bin/bash
# REPRISE PHASE 1 — installation du laboratoire WordPress (reconstitution du
# script phase1-lab-install.sh de la Task 84, fidèle au workflow CI canonique
# .github/workflows/contrats-recette.yml @ 4b41bd6).
# Sortie : $LAB/wp (WP 6.6 + Estatik 4.3.5 + Polylang 3.8.7 + SQLite drop-in +
# thème/plugin git de $DEPOT) + fixtures CI + invariants B2-B5.
# Usage : LAB=... DEPOT=... RUNTIME=... bash r1-lab-install.sh <etat: base|AB|ABC>
set -euo pipefail

ETAT="${1:-base}"
RT="${RUNTIME:?RUNTIME requis}"
LAB="${LAB:?LAB requis}"
DEPOT="${DEPOT:?DEPOT requis}"
PHP="$RT/php"
WPCLI="$RT/wp-cli.phar"
wpcli() { "$PHP" "$WPCLI" "$@"; }
WPDIR="$LAB/w""p"

[ -x "$PHP" ] || { echo "PHP statique introuvable: $PHP"; exit 2; }
[ -d "$DEPOT/.git" ] || { echo "DEPOT invalide: $DEPOT"; exit 2; }
[ -f "$RT/wordpress-6.6.zip" ] || { echo "wordpress-6.6.zip manquant"; exit 2; }

# 0. Purge du lab précédent (lab jetable, installations fraîches exigées)
rm -rf "$LAB"; mkdir -p "$LAB"

# 1. WP 6.6 officiel
unzip -q "$RT/wordpress-6.6.zip" -d "$LAB"
mv "$LAB/wordpress" "$WPDIR"

# 2. Thème + plugin du dépôt (rsync --delete, exclusions du workflow)
rsync -a --delete --exclude='.git' --exclude='.github' "$DEPOT/theme/partikulier/" "$WPDIR/wp-content/themes/partikulier/"
rsync -a --delete --exclude='.git' --exclude='.github' "$DEPOT/plugin/partikulier-core/" "$WPDIR/wp-content/plugins/partikulier-core/"

# 3. Plugins officiels : Estatik 4.3.5, Polylang 3.8.7, SQLite Integration
unzip -q "$RT/estatik-4.3.5.zip" -d "$WPDIR/wp-content/plugins/"
unzip -q "$RT/polylang-3.8.7.zip" -d "$WPDIR/wp-content/plugins/"
unzip -q "$RT/sqlite-db.zip" -d "$WPDIR/wp-content/plugins/"

# 4. Drop-in SQLite (db.copy → db.php) + wp-config dédié
cp "$WPDIR/wp-content/plugins/sqlite-database-integration/db.copy" "$WPDIR/wp-content/db.php"
mkdir -p "$WPDIR/wp-content/database"
cat > "$WPDIR/wp-config.php" <<'WPCONF'
<?php
define( 'DB_ENGINE', 'sqlite' );
define( 'DB_DIR', __DIR__ . '/wp-content/database/' );
define( 'DB_FILE', '.ht.sqlite' );
define( 'DB_NAME', 'sqlite' );
define( 'DB_USER', 'root' );
define( 'DB_PASSWORD', '' );
define( 'DB_HOST', 'localhost' );
define( 'DB_CHARSET', 'utf8mb4' );
define( 'DB_COLLATE', '' );
define( 'AUTH_KEY',         'lab-phase1-reprise-auth' );
define( 'SECURE_AUTH_KEY',  'lab-phase1-reprise-secure' );
define( 'LOGGED_IN_KEY',    'lab-phase1-reprise-logged' );
define( 'NONCE_KEY',        'lab-phase1-reprise-nonce' );
define( 'AUTH_SALT',        'lab-phase1-reprise-auth-salt' );
define( 'SECURE_AUTH_SALT', 'lab-phase1-reprise-secure-salt' );
define( 'LOGGED_IN_SALT',   'lab-phase1-reprise-logged-salt' );
define( 'NONCE_SALT',       'lab-phase1-reprise-nonce-salt' );
define( 'WP_DEBUG', false );
define( 'WP_ENVIRONMENT_TYPE', 'local' );
define( 'WP_DEBUG_LOG', false );
define( 'WP_DEBUG_DISPLAY', false );
$table_prefix = 'wp_';
if ( ! defined( 'ABSPATH' ) ) {
        define( 'ABSPATH', __DIR__ . '/' );
}
require_once ABSPATH . 'wp-settings.php';
WPCONF

# 5. Installation (identité du site = origine attaquée, port 8099 inclus — discipline workflow)
wpcli core install --path="$WPDIR" --url=http://127.0.0.1:8099 --title=Partikulier \
  --admin_user=admin --admin_password=admin --admin_email=admin@example.com --skip-email --quiet
# Garde d'identité (constat reprise) : ce WP-CLI 2.12 n'honore pas toujours --url
# (home/siteurl reçoivent le chemin physique lab-*/wp). On FORCE l'origine exacte
# du workflow et on vérifie l'égalité stricte — sinon exit 2.
wpcli option update home http://127.0.0.1:8099 --path="$WPDIR" --quiet
wpcli option update siteurl http://127.0.0.1:8099 --path="$WPDIR" --quiet
HOME_LU="$(wpcli option get home --path="$WPDIR")"
SITEURL_LU="$(wpcli option get siteurl --path="$WPDIR")"
[ "$HOME_LU" = "http://127.0.0.1:8099" ] && [ "$SITEURL_LU" = "http://127.0.0.1:8099" ] \
  || { echo "ERREUR identite: home=$HOME_LU siteurl=$SITEURL_LU"; exit 2; }

# 6. Activation — état base : Polylang DÉSACTIVÉ (chaîne de référence avant SE-025).
#    Activations UNITAIRES : l'activation groupée multiple échoue silencieusement
#    avec --quiet sur ce WP-CLI (constat reprise — partikulier-core restait inactif).
wpcli plugin activate estatik --path="$WPDIR" --quiet
wpcli plugin activate partikulier-core --path="$WPDIR" --quiet
wpcli plugin deactivate polylang --path="$WPDIR" --quiet 2>/dev/null || true
wpcli theme activate partikulier --path="$WPDIR" --quiet
mkdir -p "$WPDIR/wp-content/uploads/partikulier-cache"

# Symlinks workspace (géométrie workflow) : theme/ et plugin/ visibles depuis
# $LAB pour le serveur (router relatif) — sinon chaque requête est une erreur
# fatale « Failed opening required theme/partikulier/tests/router-ci.php ».
ln -sfn "$DEPOT/theme" "$LAB/theme"
ln -sfn "$DEPOT/plugin" "$LAB/plugin"

# 7. Santé du plugin (workflow l.62-64)
cd "$LAB"
"$PHP" -r 'require "wp/wp-load.php"; $response = rest_do_request(new WP_REST_Request("GET", "/partikulier/v1/health")); $d = $response->get_data(); if (($d["status"] ?? "") !== "ok") { fwrite(STDERR, json_encode($d)."\n"); exit(1); } echo "health ok — core ".($d["core_version"] ?? "?")." / schema ".($d["schema_version"] ?? "?")."\n";'

# 8. Amorcer une annonce de contrat + 30 properties (workflow l.65-67, verbatim)
"$PHP" -r 'require "wp/wp-load.php"; wp_set_current_user(1); $request = new WP_REST_Request("POST", "/partikulier/v1/listings"); $request->set_header("Content-Type", "application/json"); $request->set_body(wp_json_encode(["title" => "CI fixture", "description" => "CI contract fixture", "locale" => "fr", "price" => 100, "area" => 10])); $response = rest_do_request($request); if ($response->get_status() !== 201) { fwrite(STDERR, "fixture listing failed: ".wp_json_encode($response->get_data())."\n"); exit(1); } $id = (int) (($response->get_data()["id"] ?? 0)); global $wpdb; $row = $wpdb->get_row($wpdb->prepare("SELECT external_id FROM {$wpdb->prefix}pk_listings WHERE id = %d", $id), ARRAY_A); $post_id = $row ? (int) substr((string) $row["external_id"], strlen("estatik:")) : 0; if ($post_id < 1) { fwrite(STDERR, "fixture post missing\n"); exit(1); } wp_update_post(["ID" => $post_id, "post_status" => "publish"]); wp_insert_post(["post_type" => "properties", "post_status" => "publish", "post_title" => "CI variant fixture", "post_content" => "CI variant contract fixture", "post_author" => 1]); for ($i = 3; $i <= 30; $i++) { wp_insert_post(["post_type" => "properties", "post_status" => "publish", "post_title" => "CI i18n fixture $i", "post_content" => "CI i18n contract fixture", "post_author" => 1]); } unload_textdomain("partikulier", true); load_theme_textdomain("partikulier", get_template_directory() . "/languages"); load_textdomain("partikulier", WP_PLUGIN_DIR . "/partikulier-core/languages/en_US.mo"); (new \Partikulier\Core\Integration\ListingSynchronizer())->flush(); echo "fixture listings ready: 30 published properties\n";'

# 9. Invariants historiques B2-B5 (workflow l.68-70, verbatim)
"$PHP" -r 'require "wp/wp-load.php"; global $wpdb; $now = gmdate("Y-m-d H:i:s"); update_option("pk_n8n_settings", ["automation_api_secret" => "ci-contract-secret", "active_key_id" => "N", "hmac_mode" => "off"], false); $leads = $wpdb->prefix . "pk_buyer_leads"; $existing = (int) $wpdb->get_var("SELECT COUNT(*) FROM $leads"); for ($i = $existing; $i < 10; $i++) { $seed = "ci-historical-lead-$i"; $wpdb->insert($leads, ["phone_hash" => hash_hmac("sha256", $seed, wp_salt("auth")), "phone_encrypted" => base64_encode($seed), "first_seen_at" => $now, "last_seen_at" => $now], ["%s", "%s", "%s", "%s"]); } $audit = new \Partikulier\Core\AuditLogger(); $adoptions = (array) $wpdb->get_results("SELECT metadata_json FROM {$wpdb->prefix}pk_audit_log"); foreach ([["B2", "leads"], ["B3", "alerts"], ["B4", "automation"], ["B5", "owner_stats"], ["B6", "translation_variants"]] as [$lot, $domain]) { $found = false; foreach ($adoptions as $row) { $meta = json_decode((string) $row->metadata_json, true); if (($meta["lot"] ?? "") === $lot && ($meta["domain"] ?? "") === $domain) { $found = true; break; } } if (!$found) { $audit->record("domain_adopted", "schema", null, ["lot" => $lot, "domain" => $domain]); } } $events = $wpdb->prefix . "pk_automation_events"; for ($i = 1; $i <= 2; $i++) { $wpdb->insert($events, ["event_id" => "ci-historical-event-$i", "event_type" => "fixture", "source" => "ci", "payload_hash" => hash("sha256", "fixture-$i"), "status" => "received", "received_at" => $now], ["%s", "%s", "%s", "%s", "%s", "%s"]); } $saves = $wpdb->prefix . "pk_property_saves"; for ($i = 1; $i <= 4; $i++) { $wpdb->insert($saves, ["property_id" => $i, "visitor_hash" => hash("sha256", "ci-visitor-$i"), "created_at" => $now, "updated_at" => $now], ["%d", "%s", "%s", "%s"]); } echo "historical fixtures ready: leads=".(int) $wpdb->get_var("SELECT COUNT(*) FROM $leads")." events=".(int) $wpdb->get_var("SELECT COUNT(*) FROM $events")." saves=".(int) $wpdb->get_var("SELECT COUNT(*) FROM $saves")."\n";'

# 10. Permaliens jolis (workflow l.113)
wpcli rewrite structure '/%postname%/' --path="$WPDIR" --quiet
wpcli rewrite flush --path="$WPDIR" --quiet

echo "=== LAB INSTALLE (etat=$ETAT) : $WPDIR ==="
wpcli core version --path="$WPDIR"
