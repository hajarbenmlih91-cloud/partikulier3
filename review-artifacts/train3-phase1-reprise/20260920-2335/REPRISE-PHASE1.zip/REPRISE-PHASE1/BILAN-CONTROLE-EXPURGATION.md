# BILAN DU CONTRÔLE D'EXPURGATION — v3 (REPRISE PHASE 1)

Ce document accompagne `REPRISE-PHASE1-EXPURGEE-V3.zip`. Il ne reproduit
**aucune valeur sensible**. Détail complet des méthodes et constats :
`RECTIFICATION-EXPURGATION.md` (sections 11 à 16) à la racine de l'archive.

## Réponse au second refus (constat sur tests-expurgation/fixtures/)

Le constat était exact : les corpus d'entrée des tests contenaient des
valeurs **réalistes** — blobs hex 30/32/64, en-tête JWT, base64, nonces de
10 caractères, `PHPSESSID` 32 hex — inventées mais indiscernables d'un
vrai secret isolées de leur commentaire, et susceptibles de déclencher un
scanner. La v3 change la politique, **pour les 8 corpus** (pas seulement
les 3 fichiers cités) :

1. **Toute valeur en position de secret est un marqueur lisible** :
   `FICTIF-NONCE-1001`, `FICTIF-COOKIE-0001`, `FICTIFJETON0001`,
   `FICTIF-BEARER-0002`, `FICTIF-SESSID-0006`, etc.
2. **Plus aucune chaîne à forme de secret dans `fixtures/`** — vérifié par
   une batterie grep indépendante (8 motifs : hex ≥ 16, préfixe JWT,
   base64 long, `Bearer`/`Basic` longs, `PHPSESSID` hex,
   `wordpress_<32hex>`, `s:64:` hex, alnum ≥ 40) : **0 correspondance**.
3. **La couverture des tests est intacte** : la détection se fait par nom
   de clé et structure (champ caché, paramètre d'URL, affectation JS,
   cookie, en-tête), jamais par forme de valeur. Preuve : le contrôle
   négatif T4 — le balayage de `fixtures/` **doit échouer** et échoue
   (**42 constats fictifs** détectés). Les `attendus/` montrent chacune de
   ces valeurs remplacées par `[EXPURGE]`. Les pièges à faux positifs
   (`value="1"`, `value="buyer"`, redirections, `wp_nonce_field()`,
   prose, empreintes publiques fictives) restent intégralement non
   expurgés.

Choix assumé : remplacer les valeurs d'entrée par `[EXPURGE]` (lecture
littérale de la demande) aurait détruit le corpus d'entrée — le test T4
n'aurait plus rien détecté et la suite se serait auto-invalidée. Les
marqueurs `FICTIF-*` satisfont l'exigence réelle (zéro forme de secret non
marquée) en conservant le pouvoir probant du testeur.

## Complément d'audit : fuite résiduelle corrigée (règle R10)

L'audit indépendant du commanditaire a trouvé une vraie fuite que la v2 et
l'inspection n'avaient pas détectée : `var compressionNonce = "…"` (cœur
WordPress) dans `preuves/RA-1/avant/admin-ecran.html` (ligne 206) et
`preuves/RA-1/apres/admin-ecran.html` (ligne 394). Angle mort structurel :
R1 exigeait un séparateur `:`, R4 une valeur non guillemetée — la forme
« clé nue + `=` + valeur guillemetée » échappait aux deux, et aucun corpus
de test ne la couvrait.

Correction v3 : **règle R10** (clés des familles nonce/token/secret/csrf/
jeton + `=` + valeur guillemetée 8–64, comparaisons `==`/`!=` exclues),
R6/R7 élargies aux chaînes neutres, **nouvelle fixture dédiée**
(`js-affectation-egale.txt`, avec pièges `==`/`!=`/prose/référence de
variable), et **rebalayage complet de l'arbre** avec l'outil corrigé (346
fichiers, pas seulement les fichiers connus) : exactement **2 constats
dans `preuves/`** (les deux `compressionNonce`), rien nulle part ailleurs.
Les 2 valeurs sont `[EXPURGE]` ; vérifié ligne à ligne contre l'archive
v2 : chaque ligne modifiée est exactement la ligne d'origine passée par le
rédacteur (1 ligne par fichier).

Transparence : un bug d'affichage du mode `--scan` (fusion d'intervalles à
décalages locaux, sous-comptage des constats) a été corrigé ; le mode
expurgation n'était pas concerné, et le re-balayage corrigé n'a révélé
**aucun** résidu supplémentaire dans `preuves/`.

## Réconciliation des comptages

`47` (bilan v2) = valeurs masquées par la passe v2 (34 distinctes, 9
fichiers). `72` = marqueurs `[EXPURGE]` totaux après v2 = 25 (posés par
l'ancien filtre sed v1, déjà présents dans la première archive refusée) +
47 (passe v2). `74` = total v3 (+2 R10). Deux méthodes de comptage, deux
nombres justes — les deux sont désormais documentés.

## Tests et vérifications

- `tests-expurgation/executer-tests.sh` : **19 OK / 0 FAIL** (T1 conformité
  8/8, T2 idempotence 8/8, T3 attendus 0 secret, T4 contrôle négatif 42
  constats, T5 preuves réelles 0 secret — 311 fichiers, R1–R10) ;
- balayage R1–R10 sur extraction fraîche du ZIP : `preuves/` 0 constat,
  `scripts-rejouables/` 0, `tests-expurgation/attendus/` 0,
  `reference/` 0, documents racine 0 ; `fixtures/` : 42 constats fictifs
  attendus (contrôle négatif) ;
- second balayage indépendant (implémentation distincte, 3 décodages par
  ligne) : 0 constat sur `preuves/` et `scripts-rejouables/` ;
- manifeste interne régénéré puis vérifié **après extraction** (chaque
  empreinte recalculée) ; `unzip -t` sans erreur ; aucun chemin absolu,
  aucun `../`, aucun lien symbolique, aucun `.git` ;
- diffs applicatifs inchangés octet pour octet (empreintes ci-dessous) ;
- tests rejoués depuis l'extraction.

## Empreintes

```text
Archive refusée nº 1 (v1)       : c9b191c0b04947e040e946e4a135f5181438696b44cde6dd10a6d22328cfc401
Archive refusée nº 2 (v2)       : 9ad0c5bb50b2aff1f15cd6809ba62c81e7f83cf6f5e883ce6e81737a2ddfeac2
Nouvelle archive (v3)           : cf. REPRISE-PHASE1-EXPURGEE-V3.zip.sha256
Fichiers (manifeste v3)         : 348 entrées + le manifeste lui-même

PHASE1-LOT-A-SE032.diff         1d9f76eded81b7c1acd54972b6e125b1ff8b93adcc66cd0fbe62ef06e1d88ee7  inchangé
PHASE1-LOT-B-SE041-reprise.diff 5a59cefabe65b81a947d2c752eeba8c91e66527b273951aad7180dce7b4f2761  inchangé
PHASE1-LOT-C-SE027-reprise.diff 4851fd0121ebb786c1a2d9ff85078746f0314369f2292e37caacc15ee272d0c7  inchangé
```

## Restrictions de publication (inchangées)

Aucun commit, push, création de branche ou déploiement n'a été effectué.
L'archive doit être **inspectée avant tout dépôt sur GitHub** : refuser la
publication si une valeur sensible non marquée FICTIF est détectée, si un
chemin absolu ou `../` apparaît, ou si l'empreinte du ZIP ne correspond
pas à celle du `.sha256`. Aucun script de l'archive ne doit être exécuté
pendant l'inspection.
