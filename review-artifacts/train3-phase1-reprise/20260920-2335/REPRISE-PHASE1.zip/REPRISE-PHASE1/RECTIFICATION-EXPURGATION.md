# RECTIFICATION DE L'EXPURGATION — REPRISE PHASE 1

**Objet** : correction ciblée de l'expurgation et du conditionnement de
`REPRISE-PHASE1.zip`, après le refus de publication par Manus (nonce
administrateur non expurgé détecté). **Aucun correctif applicatif, contrat,
workflow ou résultat de test historique n'est modifié** — pas de nouvelle
campagne fonctionnelle, pas de commit, pas de push, pas de déploiement.

---

## 1. Contexte du refus

L'archive refusée a pour empreintes :

```text
SHA-256 (ZIP refusé)   : c9b191c0b04947e040e946e4a135f5181438696b44cde6dd10a6d22328cfc401
Fichiers               : 328 (manifeste interne 327/327 vérifié OK)
Constat de Manus       : nonce administrateur non expurgé dans
                         preuves/RA-1/avant/admin-ecran.html
                         preuves/RA-1/apres/admin-ecran.html
```

Manus a eu raison de bloquer : le constat était exact et l'incident ne se
limitait pas à ces deux fichiers.

## 2. Ce que le contrôle précédent a manqué

L'expurgation « à la source » reposait sur un filtre `sed` de **4 motifs**
couvrant uniquement des **formes URL** (`pk_diag_jeton=`, `_wpnonce=`,
`pk_nonce=`, `wp_customize=`) avec des valeurs **hexadécimales minuscules**,
et la garde d'hygiène finale (`grep` des 3 mêmes motifs) héritait de la même
fenêtre. Ce dispositif laissait donc passer :

- les **champs cachés HTML** — `name="...nonce..." value="..."` : aucun `=`
  après le nom de clé, donc aucun des motifs ne s'appliquait ;
- les **données JavaScript/JSON** — `"nonce":"..."`, `"placesNonce":"..."`,
  `nonce: "..."` dans `URLSearchParams` ;
- les **autres noms de clés** que les 3 retenus (nonces d'écran admin,
  nonces frontal du plugin, heartbeat, etc.) ;
- les valeurs **mixtes majuscules/minuscules** (les nonces WordPress sont
  alphanumériques sur 10 caractères, pas hexadécimaux minuscules) ;
- les **cookies de session** et **jetons de session sérialisés** (jamais
  rencontrés dans l'archive, mais non couverts par principe).

Par ailleurs, `r2-r1-dispo.sh` écrivait `preuves/R1/fiche-publique.html`
**sans aucun filtre** (écriture `curl -o` directe) : la fiche publique
contenait des nonces frontaux en champs cachés et en données JS.

**La mention « 0 jeton résiduel » était donc une conclusion tirée d'un
contrôle trop étroit, pas un fait.** Elle est rectifiée au § 5.

## 3. Périmètre du nouveau contrôle

Le balayage est désormais **structurel** (script `scripts-rejouables/
expurge-preuves.py`, règles R1–R9), appliqué à **tous les fichiers de
l'archive**, textes comme binaires :

| Règle | Formes couvertes |
|-------|------------------|
| R1 | JSON/JS : `"cle_nonce":"VAL"`, `'cle':'VAL'`, `cle_nonce: "VAL"` (clé citée ou nue) |
| R2 | attributs HTML : `name/id/data-*="…nonce…"` + `value/content` du même tag (ordre indifférent, guillemets doubles/simples/nus), et attribut dont le nom se termine par `nonce` |
| R3 | paramètres d'URL `?cle=VAL`, `&cle=VAL`, `&#038;cle=VAL`, `&amp;cle=VAL`, **et formes percent-encodées** (`…%26_wpnonce%3DVAL`, `cle%3DVAL`) |
| R4 | affectation nue `cle_nonce=VAL` / `cle_nonce:VAL` (fenêtre 10–14 = longueur réelle des nonces WordPress) |
| R5 | jeton diagnostic `pk_diag_jeton` sous toute forme (URL, JSON, texte) |
| R6 | cookies de session : `wordpress_<h32>`, `wordpress_logged_in_<h32>`, `wordpress_sec_<h32>`, `wordpress_test_cookie`, `wp-settings-N`, `wp-settings-time-N`, `wp-api-*`, `wp-cli-*`, `PHPSESSID` |
| R7 | jetons de session sérialisés `s:64:"<64 hex>"` (`session_tokens`) |
| R8 | en-têtes `Authorization: Bearer/Basic` |
| R9 | compatibilité ancien filtre (`wp_customize=`) |

Un **second balayage indépendant** (implémentation distincte, trois variantes
de décodage par ligne : brut, dé-échappement HTML `&#038;/&amp;/&#039;`,
décodage percent) a été exécuté en contre-vérification. **Aucune valeur
sensible n'est affichée ni journalisée** : les constats ne sortent qu'en
longueurs et empreintes salées (sha256 tronqué).

## 4. Constats et correction

**Constats sur l'archive refusée** : 47 occurrences de nonces WordPress
(34 valeurs distinctes, toutes de 10 caractères) dans **9 fichiers** — les
deux fichiers signalés par Manus, les autres captures du même parcours
(écran admin, page anonyme, page de connexion, rejet sans jeton, avant et
après) et la fiche publique du point R1 :

```text
preuves/RA-1/avant/admin-ecran.html    9 valeurs   (JS d'écran admin + champ caché pk_nonce)
preuves/RA-1/apres/admin-ecran.html    9 valeurs   (idem, état après correctif A)
preuves/RA-1/avant/anonyme.html        6 valeurs   (champs cachés es_*_nonce_* + JS frontal)
preuves/RA-1/apres/anonyme.html        6 valeurs   (idem)
preuves/RA-1/avant/jeton-absent.txt    4 valeurs   (JS frontal de la page de rejet)
preuves/RA-1/apres/jeton-absent.txt    4 valeurs   (idem)
preuves/RA-1/avant/login.html          1 valeur    (JS de la page de connexion)
preuves/RA-1/apres/login.html          1 valeur    (idem)
preuves/R1/fiche-publique.html         7 valeurs   (champs cachés + JS + URLSearchParams)
```

Noms de clés concernés (noms conservés dans les preuves, seules les valeurs
sont retirées) : `dismiss_notice_nonce`, `save_field_nonce`,
`get_terms_creator_nonce`, `quick_edit_nonce`, `quick_edit_bulk_nonce`,
`nonce_locations`, `attachment_save_caption_nonce`, `nonce` (heartbeat,
profil, frontal, compteur de vues), `pk_nonce`, `placesNonce`,
`submitNonce`, `manageNonce`, `es_auth_nonce_*`, `es_retrieve_pwd_nonce_*`,
`es_register_nonce_*`.

**Négatifs vérifiés** : aucun cookie de session, aucun jeton de session
sérialisé, aucun en-tête `Authorization`, aucune forme URL résiduelle. Les
chaînes longues restantes ont été qualifiées une à une : empreintes git
publiques (40 hex), `payload_hash` de charges utiles de test (64 hex),
sommes de contrôle de corpus figés (32 hex) — données dérivées, pas des
identifiants.

**Correction** : les 47 valeurs sont remplacées par `[EXPURGE]`, noms de
champs et contenu utile conservés. Vérification ligne à ligne : chaque
ligne modifiée est **exactement** la ligne d'origine passée par le
rédacteur (aucune autre différence). Après correction, les deux balayages
indépendants concluent à **0 secret résiduel** sur les preuves (311
fichiers), et la ré-expurgation du même arbre ne modifie plus rien
(idempotence).

Laboratoires : les captures provenaient de laboratoires locaux déjà
détruits à l'issue de la reprise — les valeurs n'étaient plus exploitables,
mais l'exigence d'hygiène et la cohérence avec les déclarations s'imposent.

## 5. Rectification des mentions « zéro jeton résiduel »

Deux mentions de l'archive refusée sont **caduques** et se lisent désormais
ainsi :

- `RAPPORT-PHASE1-REPRISE.md` (§ Propreté de l'archive, ligne 115) :
  « 0 fichier avec jeton résiduel sur les 311 fichiers de preuves » —
  ce chiffre était celui d'un `grep` limité à 3 formes URL ; il y avait en
  réalité 47 nonces résiduels dans 9 fichiers. Le rapport n'est pas
  réédité (les différences de cette correction sont limitées aux preuves
  expurgées, au script d'expurgation et à ses tests, à la présente note et
  aux manifestes recalculés) : **la présente note le rectifie**.
- `LISEZMOI.txt` (ligne 21) : « EXPURGE A LA SOURCE (0 jeton residuel) » —
  même rectification.

**Nouvelle formulation, périmètre explicite** : après correction, les deux
balayages indépendants (R1–R9 sur fichiers textes et binaires ; variantes
brut/HTML/percent) ne détectent **aucune valeur sensible résiduelle dans le
périmètre des formes couvertes** (nonces sous toutes leurs formes rencontrées,
jeton diagnostic, cookies de session WordPress, jetons sérialisés, en-têtes
d'autorisation). **Ce n'est pas une affirmation d'absence universelle de
secrets** : c'est une absence constatée dans le périmètre défini des règles
ci-dessus, contrôle reproductible par `expurge-preuves.py --scan`.

## 6. Correctifs des scripts de capture

- **`scripts-rejouables/r2-ra1-parcours.sh`** : le filtre `sed` est
  remplacé par `expurge-preuves.py --filtre` (R1–R9) ; la garde d'hygiène
  finale devient un balayage complet (`--scan`) qui **fait échouer le run**
  en cas de résidu ; le bocal à cookies et la capture brute du rapport
  signé restent des fichiers temporaires supprimés avant la fin du run
  (jamais exportés).
- **`scripts-rejouables/r2-r1-dispo.sh`** : `fiche-publique.html` passe par
  une capture brute **temporaire** (`fiche-publique.brut`), filtrée par
  `expurge-preuves.py`, la brute étant **supprimée avant la fin du run** ;
  garde d'hygiène `--scan` ajoutée en fin de script.
- **`scripts-rejouables/expurge-preuves.py`** (nouveau) : rédacteur et
  balayeur R1–R9, idempotent, sans fuite de valeurs dans ses sorties.

## 7. Tests (corpus fictif représentatif)

`tests-expurgation/executer-tests.sh` — **17 OK / 0 FAIL** (détail dans
`tests-expurgation/resultat-tests.json`) :

- **T1** conformité : 7/7 fixtures expurgées conformes aux sorties attendues
  (champs cachés doubles/simples quotes et ordre inversé, données JSON/JS
  citées et nues, URLs avec `&#038;`/`&amp;` et percent-encoding, cookies,
  session sérialisée, Authorization, attribut `data-*-nonce`) ;
- **T2** idempotence : 7/7 (ré-expurger ne change rien) ;
- **T3** balayage des sorties attendues : 0 secret (code 0) ;
- **T4** contrôle négatif : le balayage des fixtures **doit échouer** (code 1)
  — le détecteur détecte réellement (20 constats fictifs) ;
- **T5** preuves réelles de l'archive : 0 secret résiduel (311 fichiers) ;
- pièges à faux positifs : `value="1"`, `value="buyer"`, redirections
  `/fr/annonce/...`, code `wp_nonce_field()`/`check_admin_referer()`,
  prose contenant « nonce », empreintes git/checksums/payload_hash —
  **rien n'est expurgé à tort**.

Limite documentée : une valeur **nue** de 15+ caractères après `nonce=`
hors de tout contexte HTML/JSON/URL n'entre pas dans la fenêtre R4
(10–14, longueur réelle des nonces WordPress) ; aucune occurrence de ce
type n'existe dans l'archive.

## 8. Inventaire exact des différences avec l'archive refusée

**Fichiers modifiés (11)** — valeurs expurgées uniquement pour les preuves :

```text
preuves/RA-1/avant/admin-ecran.html          47 valeurs au total,
preuves/RA-1/apres/admin-ecran.html          réparties sur les
preuves/RA-1/avant/anonyme.html              9 fichiers ci-contre,
preuves/RA-1/apres/anonyme.html              remplacées par [EXPURGE]
preuves/RA-1/avant/jeton-absent.txt          (noms de champs conservés,
preuves/RA-1/apres/jeton-absent.txt          reste du contenu inchangé)
preuves/RA-1/avant/login.html
preuves/RA-1/apres/login.html
preuves/R1/fiche-publique.html
scripts-rejouables/r2-ra1-parcours.sh        filtre élargi + garde --scan
scripts-rejouables/r2-r1-dispo.sh            capture filtrée + brute temporaire
```

**Fichiers ajoutés (18)** :

```text
RECTIFICATION-EXPURGATION.md                 la présente note
scripts-rejouables/expurge-preuves.py        rédacteur/balayeur R1-R9
tests-expurgation/executer-tests.sh          lanceur des tests
tests-expurgation/resultat-tests.json        preuve d'exécution (17 OK / 0 FAIL)
tests-expurgation/fixtures/*                 7 corpus fictifs d'entrée
tests-expurgation/attendus/*                 7 sorties attendues
```

**Recalculés (1)** : `SHA256SUMS-REPRISE.txt` (manifeste interne étendu aux
fichiers ajoutés). **Tous les autres fichiers sont inchangés octet pour
octet** — en particulier les correctifs applicatifs :

```text
PHASE1-LOT-A-SE032.diff           1d9f76eded81b7c1acd54972b6e125b1ff8b93adcc66cd0fbe62ef06e1d88ee7  (inchangé)
PHASE1-LOT-B-SE041-reprise.diff   5a59cefabe65b81a947d2c752eeba8c91e66527b273951aad7180dce7b4f2761  (inchangé)
PHASE1-LOT-C-SE027-reprise.diff   4851fd0121ebb786c1a2d9ff85078746f0314369f2292e37caacc15ee272d0c7  (inchangé)
```

…ainsi que le rapport, l'ordre d'application, le LISEZMOI, le CDC de
référence, tous les contrats, journaux et résultats de tests historiques.

## 9. Vérifications de conditionnement

- manifeste interne régénéré puis **vérifié après extraction du nouveau
  ZIP** (chaque empreinte recalculée depuis l'extraction) ;
- `unzip -t` sans erreur ;
- les deux balayages indépendants exécutés **sur l'extraction du nouveau
  ZIP** : 0 secret résiduel dans le périmètre R1–R9 / P1–P8 ;
- aucune valeur sensible reproduite dans la présente note, dans le bilan de
  contrôle ni dans les journaux.

## 10. Statut

Aucun commit, aucun push, aucune branche, aucun déploiement ; le dépôt
distant et `main` restent inchangés. L'application contrôlée A → B → C puis
la CI GitHub de référence (376/376 sur 39 suites, puis 382/382 sur 40
suites) restent les étapes de clôture, sur décision du commanditaire.

---

# RECTIFICATION v3 — second refus de publication

**Objet** : l'archive v2 (`REPRISE-PHASE1-EXPURGEE.zip`, empreinte
`9ad0c5bb…dfeac2`) a été refusée par Manus pour un motif distinct du
premier : des valeurs de forme token/session non remplacées par `[EXPURGE]`
dans `tests-expurgation/fixtures/` (3 fichiers cités :
`urls-entities.html`→`urls-entites.html`, `session-et-authorization.txt`,
`cookies-journal.log`). Parallèlement, l'audit indépendant du commanditaire
a identifié **une vraie fuite résiduelle** que ni la v2 ni l'inspection de
Manus n'avaient détectée. La v3 traite les deux.

## 11. La fuite résiduelle : affectation JS à clé nue (règle R10)

L'audit du commanditaire a trouvé, dans deux fichiers pourtant traités en
v2, une déclaration JavaScript du cœur WordPress :

```text
preuves/RA-1/avant/admin-ecran.html   ligne 206   var compressionNonce = "…" ;
preuves/RA-1/apres/admin-ecran.html   ligne 394   var compressionNonce = "…" ;
```

**Pourquoi la v2 ne la voyait pas** — angle mort structurel, pas une
négligence d'exécution : la règle R1 exige un séparateur `:` (clé citée ou
nue) et la règle R4 exige une valeur **non guillemetée** dans sa fenêtre
10–14. La forme `identifiant = "valeur"` (clé nue, `=`, valeur guillemetée)
n'entre dans aucune des deux. Le trou de test expliquait le trou de
correction : aucun corpus de `tests-expurgation/` ne contenait ce motif.

**Correction v3** :

- nouvelle règle **R10** : `\b(clé des familles nonce/token/secret/csrf/
  jeton)\s*=\s*"valeur 8–64"` (guillemets doubles ou simples, comparaisons
  `==`/`!=`/`<=`/`>=` exclues par construction) ;
- **R6 élargie** : noms de cookies `wordpress_<16–64 car.>` (les noms réels
  en 32 hex restent couverts, les noms fictifs neutres des corpus aussi) ;
- **R7 élargie** : `s:64:"<64 car.>"` (les vrais jetons 64 hex restent
  couverts, les marqueurs fictifs de 64 caractères aussi) ;
- **correction d'un bug du mode `--scan`** (présent depuis la v2) : les
  intervalles détectés étaient fusionnés avec des décalages locaux de
  ligne, si bien que des constats situés sur des lignes différentes à la
  même colonne pouvaient s'éliminer mutuellement (sous-comptage : 24
  constats affichés au lieu de 40 sur l'arbre complet). Le mode
  `--fichier`/expurgation **n'était pas concerné** (offsets globaux
  corrects). Après correction, le balayage affiche le numéro de ligne de
  chaque constat ;
- **rebalayage complet** de l'arbre avec l'outil corrigé (les 346 fichiers,
  pas seulement les fichiers connus) : exactement **2 constats dans
  `preuves/`** — les deux `compressionNonce` ci-dessus — et rien d'autre
  nulle part (preuves, scripts, référence, documents). La correction du bug
  de fusion n'a donc révélé **aucun** résidu supplémentaire : l'expurgation
  v2 était complète dans son périmètre, seul l'angle mort R10 restait ;
- les 2 valeurs sont remplacées par `[EXPURGE]` (1 ligne modifiée par
  fichier, vérifié ligne à ligne contre l'extraction de l'archive v2 :
  chaque ligne modifiée est exactement la ligne d'origine passée par le
  rédacteur).

## 12. Neutralisation du corpus de test (motif du second refus)

Le constat de Manus était exact : les fixtures contenaient des valeurs
**réalistes** (blobs hex 30/32/64, en-tête JWT `eyJ…`, base64, nonces
alphanumériques de 10 caractères, `PHPSESSID` 32 hex) — inventées, mais
indiscernables d'un vrai secret une fois isolées de leur commentaire
d'en-tête, et susceptibles de déclencher les scanners de secrets.

**La détection se faisant par nom de clé et structure — jamais par forme de
valeur** — remplacer ces valeurs par des marqueurs manifestement inertes ne
réduit aucune couverture de test. La v3 applique donc la politique
suivante, pour **tous** les corpus d'entrée (pas seulement les 3 fichiers
cités) :

- toute valeur en position de secret est un marqueur lisible `FICTIF-*`
  (ex. `FICTIF-NONCE-1001`, `FICTIF-COOKIE-0001`, `FICTIFJETON0001`,
  `FICTIF-BEARER-0002`) ;
- plus **aucune** chaîne à forme de secret dans `fixtures/` : zéro suite
  hex ≥ 16, zéro préfixe JWT, zéro base64 long, zéro nonce réaliste
  (batterie grep indépendante, 8 motifs, 0 correspondance) ;
- les `attendus/` correspondants montrent chacune de ces valeurs remplacée
  par `[EXPURGE]` ;
- le contrôle négatif T4 fonctionne toujours : le balayage de `fixtures/`
  **doit échouer** et échoue (42 constats fictifs, par nom de clé) — le
  détecteur détecte réellement ;
- les pièges à faux positifs (`value="1"`, `value="buyer"`, redirections,
  code `wp_nonce_field()`, prose, empreintes publiques fictives à tirets)
  restent **intégralement non expurgés** ;
- nouvelle fixture `js-affectation-egale.txt` : couvre R10 (affectations à
  clé nue + `=` + valeur guillemetée, familles nonce/token/secret/csrf/
  jeton), un cas positif R4, et les pièges `==`/`!=`/prose/référence de
  variable.

Comportement conservatoire documenté : R10 masque aussi les valeurs
guillemetées des clés à famille sensible même quand il s'agit de noms
d'action (ex. l'attribut « data-nonce-action » de la fixture, dont le nom
d'action en valeur est masqué lui aussi) — mieux vaut masquer trop que pas
assez ; aucune occurrence de ce type dans les preuves réelles.

## 13. Réconciliation des comptages (question du commanditaire)

- **47** = nombre de **valeurs masquées par la passe v2** (journal
  d'expurgation ; 34 valeurs distinctes, 9 fichiers) ;
- **72** = nombre de **marqueurs `[EXPURGE]` textuels** dans `preuves/`
  après v2 = 25 marqueurs posés par l'ancien filtre sed de la v1 (formes
  URL, déjà présents dans l'archive refusée nº 1) + 47 valeurs de la passe
  v2. Deux méthodes de comptage, deux nombres justes ;
- **74** = total v3 = 72 + 2 (les deux `compressionNonce`, règle R10).

## 14. Tests v3

`tests-expurgation/executer-tests.sh` — **19 OK / 0 FAIL** (8 corpus) :
T1 conformité 8/8, T2 idempotence 8/8, T3 attendus 0 secret, T4 contrôle
négatif (le balayage des fixtures échoue : 42 constats fictifs), T5 preuves
réelles 0 secret (311 fichiers, périmètre R1–R10). Détail et empreintes
SHA-256 des corpus dans `tests-expurgation/resultat-tests.json`.

## 15. Inventaire exact des différences v3 ↔ v2

**Modifiés (20)** :

```text
preuves/RA-1/avant/admin-ecran.html      1 valeur R10 (ligne 206)
preuves/RA-1/apres/admin-ecran.html      1 valeur R10 (ligne 394)
scripts-rejouables/expurge-preuves.py    R10 + R6/R7 élargies + bug scan
tests-expurgation/fixtures/*             7 corpus neutralisés (FICTIF-*)
tests-expurgation/attendus/*             7 sorties régénérées
tests-expurgation/resultat-tests.json    19 OK / 0 FAIL
RECTIFICATION-EXPURGATION.md             présente section v3
LISEZMOI.txt                              mention § RA-1 corrigée + section tests
```

**Ajoutés (3)** : `tests-expurgation/fixtures/js-affectation-egale.txt`,
`tests-expurgation/attendus/js-affectation-egale.txt`,
`BILAN-CONTROLE-EXPURGATION.md` (désormais inclus dans l'archive).
**Recalculé (1)** : `SHA256SUMS-REPRISE.txt` (348 entrées).
**Tous les autres fichiers inchangés octet pour octet**, en particulier les
trois correctifs applicatifs (empreintes constantes) et les 316 autres
fichiers de l'archive v2.

## 16. Statut v3

Aucun commit, aucun push, aucune branche, aucun déploiement ; aucun script
de l'archive exécuté pendant l'inspection. Laboratoires locaux détruits :
les valeurs expurgées n'étaient plus exploitables, l'exigence d'hygiène et
la cohérence des déclarations s'appliquent néanmoins.
