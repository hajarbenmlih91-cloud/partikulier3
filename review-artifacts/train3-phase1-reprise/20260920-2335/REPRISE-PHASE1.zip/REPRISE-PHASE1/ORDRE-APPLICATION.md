# ORDRE D'APPLICATION — Phase 1 (reprise du 20/09/2026)

## Base

- Dépôt : `hajarbenmlih91-cloud/partikulier3`, commit
  `4b41bd65f2414ea9ce0fd847f144c46fccbab521` (tag `v2.10.8-6.20.7`), arbre
  propre. Vérifier : `git status` vide, `git rev-parse HEAD` = le SHA ci-dessus.

## Diffs (ordre STRICT, chaque diff s'applique sur l'état produit par le précédent)

1. `PHASE1-LOT-A-SE032.diff` — lot A SE-032 (**inchangé** de la livraison
   initiale : garde 404 du fichier diagnostic + `Requires PHP` 8.1 ×2 + doc
   proxy REMOTE_ADDR).
2. `PHASE1-LOT-B-SE041-reprise.diff` — lot B SE-041 **révisé** :
   `xmlrpc_methods → __return_empty_array` (correctif inchangé) + contrat
   `se041-xmlrpc-contract.php` (inchangé) + doc (inchangée) + **workflow :
   oracle 376/376 DURCI** (schéma, cohérence arithmétique, unicité, FAIL
   caché impossible, cardinalité et ensemble exact des 39 suites, totaux
   épinglés par suite).
3. `PHASE1-LOT-C-SE027-reprise.diff` — lot C SE-027 **révisé** :
   `class-listing-urls.php` (correctif inchangé : RULES_VERSION '5' +
   conditionnement `!defined('POLYLANG_VERSION')` des cinq règles préfixées)
   + **contrat `se027-rewrite-prefix-contract.php` v2 durci** (cibles
   substituées vérifiées en processus neufs, GET réels, assertions positives
   de pagination, restauration contrôlée en processus neuf — mêmes six
   identifiants E27-001→006, total 6) + **workflow : oracle 382/382 DURCI**
   (40 suites, totaux épinglés).

```bash
git apply --check PHASE1-LOT-A-SE032.diff          # base nue
git apply PHASE1-LOT-A-SE032.diff
git apply --check PHASE1-LOT-B-SE041-reprise.diff  # APRÈS A
git apply PHASE1-LOT-B-SE041-reprise.diff
git apply --check PHASE1-LOT-C-SE027-reprise.diff  # APRÈS A+B
git apply PHASE1-LOT-C-SE027-reprise.diff
```

## Oracles attendus (workflow `contrats-recette.yml`)

| État | Suites | Assertions | Validateurs |
|---|---:|---:|---|
| base | 38 | 370/370 | oracle de référence (hors diffs, forme faible — durcissement recommandé ultérieurement) |
| base + A + B | 39 | 376/376 | **oracle B durci** (ce diff) |
| base + A + B + C | 40 | 382/382 | **oracle C durci** (ce diff) |

Le validateur durci refuse : suite manquante, suite en trop/doublon, JSON
invalide, compteurs incohérents, total ≠ total épinglé de la suite, FAIL
caché sous `status: PASS`, `test_id` dupliqué. Il accepte uniquement un jeu
complet et cohérent des 39/40 suites.

## Vérifications vivantes après application (extrait)

- Accès direct `/wp-content/themes/partikulier/pk-diagnostic.php` → **404**
  (corps vide) ; parcours signé admin (rapport complet) toujours fonctionnel.
- XML-RPC : `system.listMethods` → **exactement 3 méthodes `system.*`** ;
  `demo.sayHello` / `pingback.ping` → faultCode **-32601**.
- Rewrites avec Polylang : 0 double-préfixation, migration 4→5 par
  `maybe_flush()`, idempotence ; sans Polylang (processus neufs) : les cinq
  règles préfixées présentes **avec leurs cibles substituées conformes**.

## Interdits (inchangés)

Aucun commit/push/tag/Release, aucun déploiement, aucune requête vers le
domaine du client, aucune sonde installée, aucune lecture d'en-têtes
`X-Forwarded-For` ; la CI de référence (PHP 8.3/MySQL 8) reste l'étape de
clôture après application, sur décision du commanditaire.
