#!/bin/bash
# tests-expurgation/executer-tests.sh — Tests du script d'expurgation.
#
# Corpus : exemples FICTIFS représentatifs des encodages rencontrés dans les
# preuves réelles (champs cachés, données JS/JSON, URLs avec entités HTML
# &#038;/&amp;, percent-encoding, cookies, session sérialisée, Authorization,
# pièges à faux positifs, idempotence).
#
# Tests :
#   T1  chaque fixture expurgée == attendu (octet pour octet)
#   T2  idempotence : ré-expurger la sortie ne change rien
#   T3  balayage des attendus : 0 secret résiduel (code 0)
#   T4  contrôle négatif : le balayage des fixtures DOIT échouer (code 1)
#       — prouve que le détecteur détecte réellement
#   T5  preuves réelles de l'archive : 0 secret résiduel (code 0)
#
# Aucune valeur sensible n'est affichée (les valeurs des fixtures sont
# fictives ; les constats réels ne sortent qu'en empreintes salées).
set -uo pipefail
TD="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"          # tests-expurgation/
SD="$(cd "$TD/../scripts-rejouables" && pwd)"               # scripts-rejouables/
RACINE="$(cd "$TD/.." && pwd)"                              # racine REPRISE-PHASE1/
EXP="$SD/expurge-preuves.py"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
python3 "$EXP" --filtre < /dev/null > /dev/null || { echo "FAIL: python3/expurge-preuves.py indisponible"; exit 2; }

resultat="$TD/resultat-tests.json"
echo "=== TESTS EXPURGATION (corpus fictif) ==="
ok=0; ko=0
t1_ok=0; t1_ko=0
for f in "$TD"/fixtures/*; do
  b="$(basename "$f")"
  python3 "$EXP" --filtre < "$f" > "$TMP/$b.1" 2>/dev/null
  if cmp -s "$TMP/$b.1" "$TD/attendus/$b"; then t1_ok=$((t1_ok+1)); else
    t1_ko=$((t1_ko+1)); echo "T1 FAIL: $b != attendu"; diff "$TD/attendus/$b" "$TMP/$b.1" | head -5; fi
done
[ $t1_ko -eq 0 ] && echo "T1 expurgation conforme ................ OK ($t1_ok/$((t1_ok+t1_ko)))" || echo "T1 expurgation conforme ................ FAIL"
ok=$((ok+t1_ok)); ko=$((ko+t1_ko))

t2_ok=0; t2_ko=0
for f in "$TD"/fixtures/*; do
  b="$(basename "$f")"
  python3 "$EXP" --filtre < "$TD/attendus/$b" > "$TMP/$b.2" 2>/dev/null
  if cmp -s "$TMP/$b.2" "$TD/attendus/$b"; then t2_ok=$((t2_ok+1)); else
    t2_ko=$((t2_ko+1)); echo "T2 FAIL: $b non idempotent"; fi
done
[ $t2_ko -eq 0 ] && echo "T2 idempotence ....................... OK ($t2_ok/$((t2_ok+t2_ko)))" || echo "T2 idempotence ....................... FAIL"
ok=$((ok+t2_ok)); ko=$((ko+t2_ko))

t3=KO; python3 "$EXP" --scan "$TD/attendus" > "$TMP/t3.log" 2>&1; [ $? -eq 0 ] && t3=OK || t3=FAIL
echo "T3 scan attendus = 0 secret ........... $t3"
[ "$t3" = OK ] && ok=$((ok+1)) || ko=$((ko+1))

t4=KO; python3 "$EXP" --scan "$TD/fixtures" > "$TMP/t4.log" 2>&1; [ $? -eq 1 ] && t4=OK || t4=FAIL
echo "T4 scan fixtures DOIT echouer ......... $t4 (constats fictifs: $(grep -c 'cle=' "$TMP/t4.log" || true))"
[ "$t4" = OK ] && ok=$((ok+1)) || ko=$((ko+1))

t5=KO; python3 "$EXP" --scan "$RACINE/preuves" > "$TMP/t5.log" 2>&1; [ $? -eq 0 ] && t5=OK || t5=FAIL
echo "T5 scan preuves reelles = 0 secret .... $t5 ($(tail -1 "$TMP/t5.log"))"
[ "$t5" = OK ] && ok=$((ok+1)) || ko=$((ko+1))

python3 - "$ok" "$ko" "$t1_ok" "$t1_ko" "$t2_ok" "$t2_ko" "$t3" "$t4" "$t5" <<'PYEOF'
import sys, json, hashlib, datetime, os
ok, ko, t1_ok, t1_ko, t2_ok, t2_ko, t3, t4, t5 = sys.argv[1:10]
def fp(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()
td = os.path.dirname(os.path.abspath(__file__)) if "__file__" in dir() else "."
rep = {
  "date_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
  "corpus": "fictif (valeurs inventées, représentatives des encodages réels)",
  "T1_expurgation_conforme": f"{t1_ok} OK / {t1_ko} FAIL",
  "T2_idempotence": f"{t2_ok} OK / {t2_ko} FAIL",
  "T3_scan_attendus_zero_secret": t3,
  "T4_scan_fixtures_doit_echouer": t4,
  "T5_scan_preuves_reelles_zero_secret": t5,
  "total": f"{ok} OK / {ko} FAIL",
  "fixtures": {f: fp(os.path.join("fixtures", f)) for f in sorted(os.listdir("fixtures"))},
  "attendus": {f: fp(os.path.join("attendus", f)) for f in sorted(os.listdir("attendus"))},
}
json.dump(rep, open("resultat-tests.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
PYEOF
echo "=== BILAN: $ok OK / $ko FAIL — detail dans resultat-tests.json ==="
[ "$ko" -eq 0 ] || exit 1
exit 0
