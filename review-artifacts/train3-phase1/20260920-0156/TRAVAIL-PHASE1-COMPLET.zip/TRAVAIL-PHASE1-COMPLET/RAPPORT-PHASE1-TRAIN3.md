# RAPPORT PHASE 1 — TRAIN 3 (SE-032 / SE-041 / SE-027 + point R1)

**CDC appliqué :** `TRAIN3-CDC-PHASE1-EXECUTION` v2 intégrale (19/09/2026) + ajustements v2.1 « effort proportionné et priorités » (LISEZMOI v2.1 : gains explicites §0.4, effort encadré §1.1, priorités §8.5, restitution allégée §9.2, deux contrôles de suivi §10 ; sections techniques 4-7 inchangées entre v2 et v2.1).
**Base :** `4b41bd65f2414ea9ce0fd847f144c46fccbab521` (tag annoté `v2.10.8-6.20.7` vérifié par `rev-parse`), clone jetable, **aucun commit / push / tag / Release / déploiement**.
**Date :** 20 septembre 2026. **Exécutant :** agent z.ai (préparation seule, conformément au périmètre autorisé §0.1/§0.3).

## Environnement et prévol

| Élément | Valeur | Écart CI |
|---|---|---|
| WordPress | 6.6 (zip officiel wordpress.org) | = CI |
| PHP | 8.3.30 (binaire statique du bench) | = CI (8.3) |
| SQL | **SQLite** (dropin sqlite-database-integration) | ≠ CI MySQL 8, ≠ revue MariaDB 11.8.6 — écart consigné, aucun vert transféré |
| Estatik / Polylang | 4.3.5 / 3.8.7 (officiels downloads.wordpress.org) | = référence |
| Thème / plugin | 6.20.7 / 2.10.8 (git archive de 4b41bd6, rsync modèle CI) | = référence |
| Origine testée | `http://127.0.0.1:8099` (= `home`, port inclus, discipline CI) | — |

Prévol §2.1 : HEAD = 4b41bd6 ✓, tag → 4b41bd6 ✓, arbre propre ✓, manifeste du paquet v2 vérifié 20/20 ✓ (le LISEZMOI v2.1 exige de vérifier le manifeste avant rejeu des sondes — fait, les deux sondes utilisées sont celles du paquet, octet pour octet).

Chaîne CI de référence rejouée en local **avant tout patch : 370/370, 38 suites** (`preuves-phase1/reference-run/`) — la base de comptage du CDC est reproduite à l'identique.

## LOT A — SE-032 (E-3201, E-3202, E-3203)

**Reproduction RA-1 (avant, code original) :** `GET /wp-content/themes/partikulier/pk-diagnostic.php` → **HTTP 200, corps 0 octet** (`RA-1/avant/`). Anonyme `?pk_diag=1` → 200 page ordinaire sans marqueur diagnostic (comportement documenté, pas le 403 fantôme de la v1). Parcours signé valide **avant** : login 302, écran admin réel 200, jeton absent → rejet, lien signé → 200 rapport 27 344 octets, aucun jeton archivé.

**Patch (hunks ↔ exigences) :** garde 404 (pk-diagnostic.php l.72-77, 3 lignes nettes, indentation 8 espaces conservée) ↔ E-3201 ; `Requires PHP: 8.1` ×2 (style.css:9, readme.txt:7) ↔ E-3203 ; section « Limiteurs derrière le CDN (DP-4 — statut ouvert) » dans docs/INSTALLATION.md (4 ancres des 3 limiteurs, règle d'interdiction X-Forwarded-For sans chaîne de confiance, critère de décision 3 branches) ↔ E-3202. Version/Stable tag inchangés, entrée historique readme.txt:227 (« PHP 8.0+ ») inchangée, `php -l` OK.

**Après :** même accès direct → **HTTP 404, 0 octet** (`RA-1/apres/`). `/fr/` 200, écran admin intact, WP-CLI charge la sonde (PK_SONDE_VERSION 5.2 inchangée), **parcours signé rejoué après : 200 rapport 27 336 octets** (écart de taille = horodatage du rapport), anonyme sans divulgation, CLI direct silencieux code 0.

**Verdict A : RECETTE COMPLÈTE** (parcours signé valide réellement rejoué avant/après).

## LOT B — SE-041 (E-4101, E-4102)

**Reproduction RB-1 (avant) :** `system.listMethods` → 200, **80 méthodes** dont `pingback.ping` et `demo.sayHello` (audit `avant-liste` PASS) ; `demo.sayHello` → 200 + **Hello! exécuté** ; `pingback.ping` → 200, faultCode **0** (≠ -32601) (`RB-1/avant/`).

**Patch :** 1 ligne `add_filter( 'xmlrpc_methods', '__return_empty_array' );` après `xmlrpc_enabled` (conservée — défense en profondeur), tabulations, `php -l` OK ↔ E-4101. Nouveau contrat `theme/partikulier/tests/se041-xmlrpc-contract.php` (6 assertions E41-001→006, JSON unique stdout, décodage XML structurel — les noms sont dans `<string>`, jamais de grep de balise) + étape workflow après SE-025 avant l'oracle + oracle 376/376/39 suites avec décomposition exacte. Section « Playbook production (E-4102) » dans docs/INSTALLATION.md (épinglage `PARTIKULIER_EXEC_REQUIRE_PIN` + `partikulier_exec_whitelist` schéma candidates/sha256, consigne nginx/LiteSpeed polyglotte + nosniff, cache assets `expires 1y + immutable` réservé aux fingerprintés, AVIF MIME puis `PARTIKULIER_ENABLE_AVIF_DELIVERY`, statut exploitation Hostinger non exécuté, DP-4 distinct).

**Démo négative (P-3) :** contrat rejoué contre le code original → **FAIL 1/6** (seul E41-003 PASS : non-régression `xmlrpc_enabled` du train antérieur) — le détecteur prouve qu'il sait échouer (`RB-1/contre-preuve-code-original.json`).

**Après :** `system.listMethods` → 200, **exactement** `system.getCapabilities`, `system.listMethods`, `system.multicall` (audit `apres-liste` PASS) ; `demo.sayHello` → fault **-32601**, aucun Hello! ; `pingback.ping` → fault **-32601**. Contrat **PASS 6/6** (`contrats/se041-xmlrpc-contract.json`). Sonde existante `staging-securite.php` : verdict **consigné sans conversion** — `ATT xmlrpc.php : HTTP 200 (répond)` (elle classe par statut HTTP, ne décode pas les méthodes ; prévu par le CDC §5.1.3).

**Verdict B : RECETTE COMPLÈTE.**

## LOT C — SE-027 (E-2701, E-2702, E-2703)

**Reproduction RC-1 (avant) :** sonde `rewrite-audit.php` (paquet v2, adaptateur de transport uniquement — `wp eval-file` refuse `declare(strict_types)`, le code de la sonde est inchangé) → **total 303, double_count 5** : `(en|fr|ar)/(fr|en|ar)/annonces/page/…`, `…/annonces/?$`, `…/location/…`, `…/annonce/…` ± quartier (`RC-1/avant.json`). **Contre-test v1 obligatoire : le grep littéral `(fr|en|ar)/(fr|en|ar)` = 0 match** alors qu'il y a 5 vrais doubles (premier groupe `en|fr|ar`) — la lacune du détecteur v1 est démontrée sur l'instance vivante.

**Patch :** `RULES_VERSION '4'→'5'` (l.33) + encapsulation des 5 règles préfixées sous `! defined( 'POLYLANG_VERSION' )` avec commentaires conservés/actualisés, règles sans préfixe inchangées et inconditionnelles + commentaire ajouté ; `php -l` OK. Édition par remplacement exact de sous-chaînes (aucune normalisation d'indentation — l'incident de reformage de style.css détecté au diff-check et corrigé par restauration + sed adressé est consigné). Contrat `se027-rewrite-prefix-contract.php` (6 assertions, détecteur embarqué = copie conforme de la sonde v2, sous-processus neufs pour la branche sans Polylang, restauration trilingue en `finally`, contrat enfant SE-025 jamais recompté) + étape workflow + oracle 382/382/40 suites.

**Scénario de migration (RC-1, §6.1.4, exactement les valeurs de la revue) :**

| Étape | code | option stockée | règles | doubles |
|---|---|---|---|---|
| Avant édition | 4 | 4 | 303 | 5 |
| Après code, **avant migration** | 5 | 4 | 303 | 5 |
| Après `maybe_flush()` explicite | 5 | 5 | 298 | **0** |
| 3 flush consécutifs | 5 | 5 | 298 | 0 |
| Second `maybe_flush()` (idempotence) | 5 | 5 | 298 | 0 |

Les 4 tables post-migration sont **strictement identiques (regex, cibles, ordre)** — comparaison machine (`RC-1/apres-*.json`). Aucun flush ajouté sur `init`.

**Démo négative :** contrat rejoué contre le code original → **FAIL 3/6** (E27-001 : les 5 doubles réapparaissent au flush ; E27-005 : version 4 ; E27-003 : restauration divergente) (`RC-1/contre-preuve-code-original.json`).

**Après :** contrat **PASS 6/6** (`contrats/se027-rewrite-prefix-contract.json`) : détecteur positif 4/4 fixtures (permutations, `^`, `(?:)`, non-langue) puis zéro double sur 3 flush ; routes effectives par langue (accueil/archive/page/fiche±quartier × en/fr/ar, cibles `lang`/`post_type`/`pk_listing_slug` conformes, jamais de littéral figé) ; branche sans Polylang en processus neufs (constante absente, 5/5 règles préfixées explicites, total 221, matchs non-préfixés) puis restauration trilingue vérifiée table-identique ; migration contrôlée 4→5 + idempotence ; legacy `property/` (version préfixée avec Polylang, documentée) + `GET /property/` → **301 → `/fr/annonces/` → 200** (redirection canonique acceptable) + `/fr/annonces/page/2/` → 200 ; SE-025 enfant **12/12**.

**Verdict C : RECETTE COMPLÈTE.**

## POINT R1 — reproduction sans correctif (§7)

`ListingRepository.php` **non édité**. Fixture FR fictive (admin, `estatik:616`, URL `/fr/property/r1-fixture-…/`), transitions par l'API réelle `Partikulier_Dashboard::manage_listing($id, $action, 1)` + vidange du synchroniseur, collection interrogée **en HTTP dans des requêtes distinctes** avec comparaison de l'`external_id` **exact** (jamais une sous-chaîne) :

| Étape (action réelle) | `_pk_status` | post_status | projection | collection REST | `find()` individuel |
|---|---|---|---|---|---|
| Création publiée + sync | actif | publish | published | **présente** | trouvé |
| `mark_sold` | vendu | publish | **published** | **ENCORE PRÉSENTE — défaut** | trouvé |
| `mark_rented` | loue | publish | **published** | **ENCORE PRÉSENTE — défaut** | trouvé |
| `archive` | archive | publish | **published** | **ENCORE PRÉSENTE — défaut** | trouvé |
| `refuse` direct, SANS re-projection | refuse | publish | **published (périmée)** | **ENCORE PRÉSENTE — garde de collection insuffisante** | **listing_not_found** |
| `refuse` + enregistrement du post (re-projection) | refuse | publish | **rejected** | **absente** | listing_not_found |

Mécanisme confirmé en lisant le code : `projectedStatus()` (SynchronizerProjectionTrait:132-137) ne connaît que `refuse`→`rejected` et `publish`→`published` — `vendu/loue/archive` sont projetés `published`. La reprojection réelle passe par `save_post` (l'enregistrement) ; un `flush()` explicite sur files vides est un no-op (consigné : mes premiers rejeux flush-only ne changeaient rien — divergence avec la revue expliquée par le mécanisme, scénario §7.3 « enregistrement du post ET synchronisation » rejoué correctement). La fiche publique répond **200** après `archive` (disponibilité ≠ existence publique). Fixtures supprimées (post + projection, 0 ligne restante). **Correctif R1 : hors Phase 1, à traiter dans SE-044/E-4807 avec le filtrage au niveau requête.**

## Non-régression et CI

- Sélection minimale §9.2.4 à l'état A (`non-regression-A/`) : premium-contract, se048-premium-honesty, **rest-lite-scope** (couvert — la revue ne l'avait pas exécuté), avif-security, artifact-hygiene, se025 : **PASS** ; module-perimeter : FAIL documenté (voir écarts).
- **Chaîne complète sur installations fraîches (ordre CI canonique exact)** :
  - état A+B : **376/376, 39 suites** (`chaine-AB/`) ;
  - état A+B+C : **382/382, 40 suites** (`chaine-ABC/`).
- La CI GitHub de référence (MySQL 8) **n'a pas été exécutée** — aucun push (interdit). Statut global : **recette locale complète, CI distante à démontrer à l'application** ; conformément au CDC §10, la Phase 1 n'est pas déclarée « close » sur la seule base des oracles locaux.

## Intégration et intégrité

Ordre canonique A → B → C. Chaîne appliquée sur **second clone propre** (4b41bd6, arbre propre) : `git apply --check` OK pour chacun, application séquentielle OK, `git diff --check` OK, **arbres strictement identiques** au working tree testé (`journal/verification-chaine.txt`). Lint PHP des 5 fichiers touchés OK. Aucun commit.

## Tableau des écarts (P-5)

| # | Écart | Qualification |
|---|---|---|
| 1 | `module-perimeter-contract` DA-011 (variantes=1) FAIL sur le lab principal à l'état A | **Artefact d'ordre** : la ligne `pk_property_variants` (id 7, `linked`, 23:59:13) est créée par SE-025 du rejeu référence, APRÈS le passage canonique de la suite (CI : suite avant SE-025). Preuve : les chaînes AB et ABC sur installations fraîches passent `module-perimeter` (PASS). Le lot A n'écrit aucune donnée (diff = code/doc). |
| 2 | `front-assets` FA-VILLE/FA-ANNONCES FAIL sur le lab principal post-Polylang | **Artefact d'ordre** : en CI, front-assets court AVANT l'installation de Polylang ; sur URLs non préfixées avec `force_lang=1`, plus de 200 direct. PASS en ordre canonique (chaînes AB/ABC). Aucun échec d'assets en soi (scripts interdits : aucun). |
| 3 | Sonde `staging-securite.php` : `ATT xmlrpc 200` + 2 KO | Verdict **consigné sans conversion** (§5.1.3). `KO accès direct 404` = conséquence attendue d'E-3201 (la sonde attend 200-vide/403, elle ne connaît pas le nouveau contrat). `KO debug.log 200` = artefact lab (`WP_DEBUG_LOG` actif au lab, pas en CI). |
| 4 | Collision règle `location/([^/]+)/?$` : cible taxonomie `es_location` (Estatik) au lieu de `pk_city_slug` (thème) | **Préexistante** : identique dans `avant.json` et `apres-migration.json` (avant/après C). Rapportée séparément conformément au CDC §6.2, non corrigée (hors périmètre). |
| 5 | Ancre CDC §5.1.1 « xmlrpc_enabled l.20 » ; réel : l.21 | Décalage d'une ligne, contenu/symbole identiques (P-4) ; édition à la position exacte exigée. |
| 6 | Deux défauts de mon harnais corrigés en cours (assertion E41-004 ordre-sensible sur l'ordre IXR non contractuel ; `$matchRule`/parse_str, puis `use ($language_group)` manquant) | Détectés par les échecs, corrigés, contre-preuves re-exécutées après correction (les contrats restent rouges sur code original). Consignés ici par honnêteté. |
| 7 | `wp eval-file` refuse `declare(strict_types=1)` | Adaptateur de transport (bootstrap WP + `include`) ; code de la sonde inchangé, attentes inchangées. |

## DP-4 / exploitation / arbitrages

- **DP-4 : OUVERT** — aucune lecture de `X-Forwarded-For`/`X-Real-IP`, aucune sonde externe, aucune action sur le domaine client. La doc E-3202 impose noir sur blanc l'interdiction d'un résolveur sans chaîne de confiance.
- Variante 403 serveur : **proposition d'exploitation séparée** uniquement (coupe plus tôt avant le bootstrap) ; les attendus du filtre restent -32601, aucun remplacement sans accord.
- Premium §8.3, grille §8.1, chiffrement §8.2 : **aucune édition** (cadre des lots ultérieurs).

## Conservation et nettoyage

Livrables et preuves exportés en chemin absolu hors runtime (`download/preuves-phase1/`), empreintes SHA-256 ci-dessous, diffs rejouables. Le runtime jetable (labs, sources, serveurs) est arrêté et supprimé en fin de session ; rien n'a été poussé nulle part. Le commanditaire est invité à conserver une copie des livrables — la persistance de `download/` n'est jamais supposée.

## Contrôles de suivi v2.1 §10

**Contrôle 1 — effort.** Estimation préalable consignée avant exécution : ≈ 6,5 h de travail d'agent décomposé en 7 postes (`journal/00-estimation-prealable.md`). Réel : conforme à l'enveloppe — aucun supplément significatif ni extension de périmètre n'a été nécessaire ; les seules dépassements locaux (2 bugs de harnais, 1 artefact de port occupé) ont été résorbés dans l'enveloppe. Aucun arbitrage à solliciter.

**Contrôle 2 — gains (§0.4).** La Phase 1 est une **maintenance/durcissement** : aucune promesse de vitesse, trafic, référencement ou conversion n'est formulée. Gains effectifs livrés : accès direct à la sonde = 404 au lieu de 200 ; méthodes XML-RPC applicatives neutralisées (80 → 3 système) ; 5 règles mortes double-préfixées supprimées de la table rewrite ; en-têtes PHP alignés ; documentation d'exploitation (proxy/CDN, épinglage, cache, AVIF) versée. Aucune métrique de performance n'est revendiquée.
