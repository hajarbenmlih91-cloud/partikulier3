# TRAIN 3 — CDC D’EXÉCUTION PHASE 1 — V2 INTÉGRALE

**Révision :** v2 du 19 septembre 2026, produite à la demande du commanditaire après revue sur WordPress réel.
**Statut :** proposition documentaire corrigée, soumise à validation. **Ce document ne constitue ni une livraison de code, ni une recette terminée, ni une autorisation de commit/push/déploiement.** Il a vocation à remplacer la v1 après acceptation ; il ne prime jamais sur une instruction ultérieure du commanditaire.
**Périmètre :** préparation locale des lots A/SE-032, B/SE-041, C/SE-027 et reproduction seule de R1.
**Base logicielle :** `4b41bd65f2414ea9ce0fd847f144c46fccbab521`, release `v2.10.8-6.20.7`.
**Ordre canonique de préparation et d’application des diffs : A → B → C.** Chaque diff isole son lot, mais B est produit sur l’état A et C sur l’état A+B ; aucune indépendance d’ordre n’est promise.

## Bordereau documentaire et statut des preuves

| Pièce | Statut vérifiable et usage |
|---|---|
| V1 `TRAIN3-CDC-PHASE1-EXECUTION.md` et sa copie `(1)` | Identiques octet pour octet : 75 890 octets ; SHA-256 `75596eb7a74547fff7dcd1994a2daa3b9fc5039723d9bc4f6cec6b5893ee5e34`. Document remplacé, pas preuve d’exécution. |
| `VALIDATIONS-COMMANDITAIRE-ET-HOSTINGER.md` | Disponible ; empreinte vérifiée `3ce2927a19b0ec8838714f51638e64a0b77d74dac383439e6f9c5898056b472c`. Complément de décisions de référence. |
| `RAPPORT-REVUE-CDC-PHASE1.md` et `PREUVES-REVUE-PHASE1.zip` | Disponibles dans `partikulier-decisions/` et `revue-phase1/`. Résultats d’une vraie campagne locale, limites comprises ; pas des diffs prêts à fusionner. |
| `TRAIN3-PLAN-MISE-A-JOUR-VALIDATIONS.md` | Contenu intégral non reçu ici. Empreinte annoncée `e5d929f4999f9aba66a91bcf0d63bee0a243579403ea7acc15bbd236400648a7` ; ne pas attester sa remise ni son contenu sur cette seule base. |
| `MESSAGE-HOSTINGER-DP4-SUIVI.md` | Contenu intégral non reçu ici. Empreinte annoncée `7b79c13129b8b0b2c7cddf6fe0dc91d06ae21c4958dcf3ae6a6a2b1db20f205a` ; transmission éventuelle par le commanditaire uniquement. |
| `CDC-CORRECTION-POSTREVUE-v5.7.1.md` | Non joint ici. Les identifiants E-xxxx sont repris de la v1 pour continuité ; aucune nouvelle certification de citations verbatim de ce document absent. |
| Outils de cette v2 | `outils/rewrite-audit.php` et `outils/xmlrpc-audit.py` ; utilitaires de recette fournis séparément et reproduits en annexe B. **Ce ne sont pas les deux nouveaux contrats CI à livrer.** |

La v2 ne dépend pas du contenu supposé des pièces absentes pour exécuter A/B/C : les exigences opérationnelles figurent ci-dessous. Joindre les pièces manquantes avant toute validation globale du train ou de leurs estimations. Ne pas déclarer « documents intégralement remis » sans fichiers effectivement accessibles.

### Origine et limites des résultats utilisés

Campagne réelle déjà menée : WordPress **6.6**, PHP **8.4.24**, MariaDB **11.8.6**, Estatik **4.3.5**, Polylang **3.8.7**, plugin **2.10.8**, thème **6.20.7**. Différence avec la CI : PHP **8.3** / MySQL **8**. Aucun test sur l’hébergement du commanditaire.

Constats : diagnostic direct 200 vide → 404 vide ; XML-RPC 80 méthodes → 3 système ; règles Polylang 303 → 298 avec 5 doubles → 0 ; SE-025 12/12 avant/après ; 21/21 smoke tests sur trois moteurs. Le détecteur de la v1 donnait pourtant 0 double **avant** correction. Les versions stockées restent anciennes tant que la migration n’est pas déclenchée. Diagnostic anonyme `?pk_diag=1` : 200 ordinaire, pas le 403 affirmé par la v1.

Ces constats motivent la révision ; ils **ne valident pas d’avance les futurs patches**. Les sondes v2 sont vérifiées sur les réponses/dumps bruts conservés et des cas de contrôle, sans nouvelle installation WordPress pour cette seule rédaction. Leur branche de lecture sur une prochaine instance devra être exécutée pendant la recette. Aucun `370/370` ou `382/382` nouveau n’est revendiqué.

---

## 0. Périmètre autorisé

### 0.1 Autorisation de préparation, distincte de la publication

Le périmètre déjà autorisé est la **préparation** : reproductions locales, propositions techniques, tests et diffs séparés. La demande présente porte sur la production de cette v2, pas sur son application à l’hébergement.

**Autorisé dans la préparation :**
1. Installer un environnement de recette isolé à partir de la référence figée et de sources publiques officielles ; noter les versions et empreintes.
2. Reproduire chaque défaut avant correction et conserver les sorties brutes.
3. Essayer localement les correctifs du périmètre et écrire/exécuter les tests associés sur des données fictives.
4. Produire les trois diffs séquentiels, les modifications documentaires, les deux contrats CI et un rapport. Aucun changement permanent hors laboratoire.

**Interdit sans nouvel accord explicite :** commit, push, tag, Release, fusion distante, publication, déploiement, installation sur l’hébergement du commanditaire, requête/sonde sur le domaine client, message envoyé à Hostinger, modification des réglages distants, correctifs applicatifs hors A/B/C.

Les téléchargements officiels nécessaires au laboratoire et lectures du dépôt public sont permis : la formule v1 « aucune requête externe » était trop large. Les requêtes de **recette** doivent cibler uniquement le laboratoire ; bloquer ses intégrations sortantes, e-mails et automatisations réelles. Aucun secret de production dans les fixtures ou les preuves.

### 0.2 Décisions acquises, recommandations et arbitrages ouverts

| Sujet | Statut à respecter |
|---|---|
| Données | **Décision explicite : zéro annonce réelle, aucune donnée réelle utile à migrer ou conserver.** Tout jeu de recette est fictif et jetable. Ce n’est pas une autorisation d’effacer l’hébergement, ses secrets ou les documents durables. |
| Disponibilité DP-9 | Désactiver/Réactiver, pas de suppression dans le futur parcours propriétaire ; motifs vendu/loué, changement d’avis, autre privé ; pages conservées indexables et dans le sitemap, exclues des biens disponibles. Aucun contournement de modération. Hors Phase 1, sauf reproduction R1. |
| Responsive | Base de recette approuvée 1/2/3 colonnes et seuils 600/1200, ajustements motivés par mesures/captures ; ne pas forcer trois cartes illisibles. Solution ciblée proposée en §8.1, pas implémentée ici. |
| Chiffrement | Absence de migration historique réelle ; conserver les tests de lecture autorisée, intégrité et parcours de contact. Encadrer strictement la compatibilité CBC en §8.2. |
| Premium | Toutes les fonctions prévues, offertes manuellement par l’admin aux annonces sélectionnées au lancement ; paiement/abonnement différé. Ni badge seul, ni gratuité automatique universelle. |
| Durée et plafond premium | Durée libre par attribution = modèle existant et recommandation ; **pas de nouvel accord explicite distinct attesté ici**. Le plafond 10 est une proposition, non actée et non codée. Aucune nouvelle question bloquante pour A/B/C. |
| DP-4 | Ouvert. CDN Hostinger identifié par le retour support ; cela ne certifie pas l’identité IP reçue par PHP. Aucune résolution d’IP/proxy nouvelle dans cette phase. |
| Délais | 16–19,5 j pour le train et 15–25 j pour le futur paiement : estimations non validées, pas engagements. |

Les recommandations de l’assistant ou de l’autre agent ne sont pas des citations ni des décisions du commanditaire. Toute nouvelle règle produit est étiquetée proposition jusqu’à accord. Les exigences de recette ajoutées ici visent à produire des preuves fiables, pas à inventer des décisions produit.

### 0.3 Contenu de la Phase 1 — préparation autorisée

Trois lots, chacun avec **reproduction d’abord, diff ensuite**, préparés puis appliqués dans l’ordre A → B → C :

| Lot | Exigences CDC v5.7.1 | Fichiers touchés | Taille attendue du diff |
|---|---|---|---|
| **A — SE-032** (hygiène diverse) | E-3201, E-3202, E-3203 | `theme/partikulier/pk-diagnostic.php`, `theme/partikulier/style.css`, `theme/partikulier/readme.txt`, `docs/INSTALLATION.md` | ~5 lignes de code + 1 section de doc |
| **B — SE-041** (durcissement XML-RPC + épinglage prod) | E-4101, E-4102 | `theme/partikulier/inc/class-security.php`, `docs/INSTALLATION.md`, nouveau contrat, workflow | 1 ligne de code + doc + test + intégration CI |
| **C — SE-027** (double-préfixation rewrite) | E-2701, E-2702, E-2703 | `theme/partikulier/inc/class-listing-urls.php`, nouveau contrat, workflow | diff code ciblé + test + intégration CI |

Plus un livrable de reproduction sans correctif : le **point R1** (§7), appartenant aux lots futurs SE-044/E-4807.

---

## 1. Règles impératives de process (P-1 à P-10)

**P-1 — Référence figée et aucune écriture distante.** Travail uniquement dans un clone/laboratoire jetable à `4b41bd65f2414ea9ce0fd847f144c46fccbab521`. Aucun commit/push/tag/Release. L’index Git local peut servir à isoler les diffs successifs (§9.1), sans commit et sans effet distant.

**P-2 — Un lot = un diff = un chapitre de rapport.** Ordre obligatoire **A → B → C**. Diff A sur la référence ; B sur l’état A ; C sur l’état A+B. Les modifications partagées de `docs/INSTALLATION.md` et du workflow sont donc intégrées séquentiellement. Vérifier la chaîne complète sur un second clone propre. Ne jamais présenter ces diffs comme indépendants de l’ordre.

**P-3 — Reproduction avant correction et contrôle positif.** Le détecteur de défaut doit réagir au défaut connu sur le code original ; un zéro avant patch n’est pas une victoire. Conserver aussi les échecs, divergences de configuration et sorties inattendues. Aucun vert fabriqué en adaptant silencieusement les attentes.

**P-4 — Ancres sémantiques avant édition.** Les numéros de ligne sont des repères sur la référence, pas des adresses immuables après les lots précédents. Vérifier classe/méthode, contenu et contexte ; un simple décalage de lignes causé par un diff précédent se consigne et n’est pas une divergence fonctionnelle. Contenu différent, symbole absent, référence différente ou nouveau comportement inexpliqué → arrêt du lot et rapport d’écart. Aucun rattrapage silencieux.

**P-5 — Écart documenté.** Distinguer résultat observé, objectif demandé, hypothèse et non-testé. Cette v2 corrige les erreurs démontrées de la v1 ; toute divergence nouvelle va dans la table des écarts. Aucun changement produit hors périmètre.

**P-6 — Conservation démontrée avant nettoyage.** Écrire les livrables dans un chemin **absolu hors du runtime jetable**, par exemple `$PROOFS`, déclaré dans le journal et hors arborescence ciblée par le nettoyage. Ni `/tmp`, ni le simple nom `download/` ne prouvent la persistance. Produire SHA-256, archive exportable, test de lecture/extraction et remise effective. Demander au commanditaire d’en garder une copie ; ne jamais prétendre qu’il a téléchargé sans preuve. Le nettoyage reste obligatoire en fin de session ; si l’export échoue, signaler immédiatement le problème et préserver les artefacts utiles hors runtime avant suppression.

**P-7 — DP-4 ouvert.** Aucune nouvelle lecture de `X-Forwarded-For`/`X-Real-IP`, aucune sonde sur le domaine client, aucun correctif proxy. Documenter seulement. La possibilité d’un refus XML-RPC en PHP est un sujet distinct.

**P-8 — Validation graduée et délais non engagés.** Vert d’une sonde ≠ validation de tout un lot ; vert local ≠ CI complète ; CI ≠ exploitation Hostinger. Tout non-testé est nommé. Les estimations restent non engageantes.

**P-9 — Diff minimal.** Ne pas reformater, changer les versions applicatives, remplacer l’historique ni corriger hors lot. Conserver les commentaires encore justes ; actualiser ceux rendus faux par le changement C. Inclure les nouveaux tests et hunks de workflow expressément demandés. Les sondes de recette ne sont pas des endpoints distribués publiquement.

**P-10 — Français, lisibilité et sorties machine.** Documents/commentaires en français. stdout d’un contrat = **un objet JSON et rien d’autre**, détails structurés dans `results` ; diagnostics d’exécution sur stderr. Identifiants et noms d’API inchangés.

---

## 2. Environnement de référence et ancrage du dépôt

### 2.1 État de référence et prévol

| Élément | Valeur imposée ou statut |
|---|---|
| Dépôt | `https://github.com/hajarbenmlih91-cloud/partikulier3` ; copie jetable uniquement |
| Commit | `4b41bd65f2414ea9ce0fd847f144c46fccbab521` |
| Tag annoté | `v2.10.8-6.20.7` ; vérifier le commit pointé, pas uniquement le nom |
| Plugin / thème | 2.10.8 / 6.20.7 |
| WordPress / Estatik / Polylang de référence | 6.6 / 4.3.5 / 3.8.7 |
| Configuration Polylang | `fr` défaut, `en`, `ar` RTL ; `force_lang=1`, `hide_default=0`, `browser=0`, `redirect_lang=0` ; CPT `properties` traduisible ; autres options selon la section SE-025 de l’installation |
| Ordre des langues | **Non contractuel.** Lire les langues configurées ; `en|fr|ar` a été observé. Ne pas exiger `fr|en|ar` dans les regex générées. |
| CI annoncée par le workflow | WP 6.6, PHP 8.3, MySQL 8 ; 38 suites / 370 assertions avant B/C |
| Laboratoire déjà testé | PHP 8.4.24/MariaDB 11.8.6 ; utile pour la revue, différent de CI |

Toutes les séquences shell ci-dessous sont exécutées en mode strict (`set -euo pipefail`), avec codes de sortie archivés. Une erreur interrompt la séquence ; ne pas continuer sur des sorties vides.

Prévol sur un clone jetable :

```bash
set -euo pipefail
cd "$CLONE"
test "$(git rev-parse HEAD)" = 4b41bd65f2414ea9ce0fd847f144c46fccbab521
test "$(git rev-parse 'v2.10.8-6.20.7^{commit}')" = 4b41bd65f2414ea9ce0fd847f144c46fccbab521
test -z "$(git status --porcelain)"
git status --short
git log --oneline -1
php -v
```

Définir et journaliser `$CLONE`, `$WP_DIR`, `$TOOLS`, `$PROOFS`, `$BASE` avant les recettes. Exemple de conventions : `$BASE=http://127.0.0.1:8080`, `$TOOLS` = dossier `outils/` de cette livraison, `$PROOFS` = dossier dédié hors runtime. `wp --path="$WP_DIR"` doit fonctionner. Enregistrer aussi la version SQL réelle, la configuration Polylang, les SHA-256 des ZIP et du CDC, les mu-plugins de laboratoire et le routeur HTTP.

En environnement d’agent, utiliser un processus persistant pour le serveur, écouter sur `0.0.0.0` si une prévisualisation est nécessaire ; les sondes restent locales. L’URL `home` doit correspondre à l’origine réellement testée : pas de port différent cachant les redirections canoniques. Préférer `/fr/` comme sonde de disponibilité après Polylang ; ne pas imposer un 200 direct sur `/` dans toutes les configurations.

Le kit durable fourni dans l’espace de revue peut reconstruire le laboratoire (`WP_VERSION=6.6 wordpress.sh prepare`, puis `serve`) et installer les navigateurs (`browsers.sh install`). Il ne remplace pas la vérification des versions. Adapter les chemins au runner, **pas les résultats attendus**. Tout accès client reste interdit.

### 2.2 Arborescence utile aux trois lots

```
<clone>/
├── .github/workflows/
│   ├── ci.yml                          # matrice PHP 8.1/8.2/8.3 (l.15 et l.62)
│   └── contrats-recette.yml            # 32 suites (l.82-98), oracle 370/370 (l.349)
├── docs/
│   └── INSTALLATION.md                 # doc d'exploitation — cible E-3202 et E-4102
├── theme/partikulier/
│   ├── pk-diagnostic.php               # sonde v5 — cible E-3201
│   ├── style.css                       # en-tête thème — cible E-3203
│   ├── readme.txt                      # en-tête thème — cible E-3203
│   ├── assets/css/style.css            # CSS réel (grille, conteneur — §8.1 uniquement)
│   ├── inc/
│   │   ├── class-security.php          # cible E-4101
│   │   ├── class-listing-urls.php      # cible SE-027
│   │   └── class-premium.php           # ancrage §8.3 (hors Phase 1)
│   └── tests/
│       ├── se025-trilingual-routes-contract.php   # modèle de test pour SE-027
│       ├── staging-securite.php                   # sonde XML-RPC existante (l.179-182)
│       └── router-ci.php                          # routeur du serveur CI
└── plugin/partikulier-core/
    ├── partikulier-core.php            # Requires PHP: 8.1 (déjà aligné)
    ├── src/
    │   ├── RateLimiter.php             # ancrage E-3202 (l.19, l.64-69)
    │   └── ListingRepository.php       # ancrage R1 (§7)
    ├── src/Domain/Leads/
    │   └── LeadsEraseGuardTrait.php    # ancrage E-3202 (l.223)
    └── tests/                          # une partie des 38 suites globales ; JSON strict
```

### 2.3 Convention des contrats et oracle

Un contrat CLI charge WordPress via `PK_WP_DIR`, puis écrit **un unique objet JSON sur stdout**. Ne pas écrire un compte rendu texte avant/après ce JSON. Les détails vont dans `results` ou sur stderr. Le code de sortie doit être 0 si toutes les assertions passent, non nul sinon ; une exception, une sortie vide ou un JSON invalide ne deviennent jamais PASS.

Schéma minimal recommandé :

```json
{
  "suite": "exemple-format-non-execute",
  "status": "PASS",
  "total": 6,
  "passed": 6,
  "failed": 0,
  "results": [
    {
      "test_id": "E41-001",
      "status": "PASS",
      "detail": "Exemple de forme uniquement, remplacer par la mesure réelle"
    },
    {
      "test_id": "E41-002",
      "status": "PASS",
      "detail": "Exemple de forme uniquement, remplacer par la mesure réelle"
    },
    {
      "test_id": "E41-003",
      "status": "PASS",
      "detail": "Exemple de forme uniquement, remplacer par la mesure réelle"
    },
    {
      "test_id": "E41-004",
      "status": "PASS",
      "detail": "Exemple de forme uniquement, remplacer par la mesure réelle"
    },
    {
      "test_id": "E41-005",
      "status": "PASS",
      "detail": "Exemple de forme uniquement, remplacer par la mesure réelle"
    },
    {
      "test_id": "E41-006",
      "status": "PASS",
      "detail": "Exemple de forme uniquement, remplacer par la mesure réelle"
    }
  ]
}
```

L’exemple illustre le format, pas un résultat d’exécution : les six résultats réels doivent être distincts et correspondre aux compteurs. Ajouter commit, dates, commande et configuration sans secret. Valider le JSON entier, l’unicité des IDs, l’égalité `passed+failed=total` et la cohérence avec les statuts détaillés.

La CI agrège `preuves-run/contrats/*.json` : y placer uniquement les **rapports finaux des suites enregistrées**, jamais les dumps, résultats enfants SE-025, réponses REST ou résultats d’autotests des sondes. Ces pièces vont dans `preuves-run/details/` ou les dossiers RA/RB/RC/R1, sinon les totaux seront faussés.

| État intégré | Suites | Assertions |
|---|---:|---:|
| Référence, puis A seul | 38 | 370 |
| A+B | 39 | 376 |
| A+B+C | 40 | 382 |

Formule : **370 + 6 si B intégré + 6 si C intégré**. A n’ajoute pas de suite à l’oracle. Les comptages de smoke tests navigateur, de revue hors ligne ou les assertions enfants de SE-025 réutilisées par C ne sont pas ajoutés une seconde fois.

L’oracle doit vérifier le nombre de suites autant que les assertions, ainsi que les statuts et le JSON valide. Lire le workflow exact avant édition : les anciens intitulés « 32 suites » désignent une étape, pas le total final 38. Actualiser les intitulés concernés avec leur nombre réel, sans transformer mécaniquement chaque « 32 » en « 40 ».

**Configuration des suites :** SE-043 s’exécute sans Polylang dans le workflow de référence, SE-025 avec Polylang configuré ensuite. La revue a confirmé 5/9 pour SE-043 lancé hors de ce contexte, aussi bien avant qu’après C, et 9/9 dans son contexte. Respecter cet ordre ; les nouveaux tests B/C sont insérés après le rétablissement du contexte trilingue et avant l’oracle. Après tout scénario sans Polylang de C, réactiver/restaurer la configuration dans de nouveaux processus et régénérer les règles.

---

## 3. Protocole d’exécution vérifiable

1. **Lire avant d’agir.** Vérifier chaque symbole/ancre sur le commit figé. Les extraits du CDC sont des cibles de travail, non un substitut au code. Les extraits avec `...` ou commentaires de lignes sont abrégés, jamais annoncés comme copies intégrales littérales.
2. **Qualifier la preuve.** Toute affirmation technique du rapport cite son fichier/ligne relu ou sa commande et sortie archivée. Distinguer preuve WordPress vivante, analyse de fichier, contrôle hors ligne d’une ancienne réponse et hypothèse.
3. **Tester avant/après dans le même contexte.** Conserver la configuration et les conditions comparables. Ne pas réutiliser une sortie ancienne en la présentant comme un rejeu du nouveau patch.
4. **Respecter les numéros.** E-3201/2/3, E-4101/2, E-2701/2/3 restent inchangés. RA-1/RB-1/RC-1/R1 sont les scénarios. E41-001→006 et E27-001→006 sont les assertions des deux nouvelles suites, pas de nouvelles exigences produit.
5. **Contrôle positif des détecteurs.** Le code original doit produire le défaut prévu dans la configuration de référence. Détecteur muet, corps vide, HTTP erreur, JSON/XML invalide ou configuration absente → preuve invalide, pas succès.
6. **Diff minimal et isolé.** Revue des hunks ; pas de `--fix` ni de reformateur global. `php -l` sur les PHP concernés, `bash -n` sur les shells créés/modifiés. Python/PHP/XML/curl sont autorisés pour les sondes ; dépendances et versions consignées.
7. **Preuves brutes utiles, sans secrets.** Garder statut HTTP, headers pertinents, XML/JSON et sorties CLI. Les cookies, mots de passe, nonces valides et rapports diagnostic susceptibles de contenir des secrets restent dans le runtime ; en extraire un résultat expurgé. Ne pas joindre `wp-config.php`, dump complet de base ou logs de sessions authentifiées.
8. **Arrêt propre.** Arrêter les serveurs, vérifier les artefacts exportés, supprimer tout le runtime et les sources téléchargeables. Conserver uniquement kit durable, rapports et preuves utiles. Aucun nettoyage de l’hébergement.

---

## 4. LOT A — SE-032 : hygiène diverse (E-3201, E-3202, E-3203)

> Exigences CDC v5.7.1 §12 (Lot 9), reprises de la v1 et précisées opérationnellement par cette v2 :
> - **E-3201** — « `pk-diagnostic.php` direct → 404 (accès légitime inchangé). »
> - **E-3202** — « Doc RateLimiter derrière proxy (IP réelle) ; filtre d'IP de confiance seulement sur demande hébergement (DP-4). »
> - **E-3203** — « `Requires PHP` du thème aligné sur 8.1. »
> Estimation historique de la v1 : 2 h, non validée ni réestimée ici. Priorité P3.

### 4.1 E-3201 — `pk-diagnostic.php` accédé directement → 404

#### 4.1.1 ANCRE — code actuel (repère sur 4b41bd6, à relire avant édition)

Fichier : `theme/partikulier/pk-diagnostic.php` (2 653 lignes, sonde v5).

Lignes 72-74 (immédiatement sous le bloc de commentaire `SE-020` l.61-70 et la ligne `phpcs:ignoreFile` l.70) :

```php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}
```

Contexte immédiat (l.70-78) pour une localisation sans ambiguïté :

```php
// phpcs:ignoreFile WordPress.Security.ValidatedSanitizedInput,WordPress.Security.EscapeOutput -- outil de diagnostic gated, sortie texte (SE-020, tri documente)

if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

if ( ! defined( 'PK_SONDE_VERSION' ) ) {
        define( 'PK_SONDE_VERSION', '5.2' );
}
```

L'indentation du corps est de **8 espaces** (conservez-la dans l'édition).

#### 4.1.2 Le défaut (ce que la reproduction doit montrer)

Quand un client HTTP demande directement `https://<site>/wp-content/themes/partikulier/pk-diagnostic.php`, WordPress n'est PAS chargé (le fichier n'est pas passé par `wp-load.php`), donc `ABSPATH` n'est pas défini, donc le script exécute `exit;` **sans avoir envoyé ni corps ni code de statut**. Le serveur répond alors **HTTP 200 avec un corps vide**. Résultat : l'outil de diagnostic du thème répond « présent et disponible » à tout scanner (200 = ressource vivante), au lieu du statut **404 demandé par E-3201**. Ce changement clarifie la réponse HTTP ; le 200 vide ne démontre pas à lui seul une divulgation du diagnostic.

Les accès légitimes, eux, passent toujours par WordPress et ne doivent pas changer d'un iota :

| Accès légitime | Chemin de code | Pourquoi inchangé |
|---|---|---|
| Chargement par le thème | `theme/partikulier/functions.php:272` : `require` de `PARTIKULIER_DIR . '/pk-diagnostic.php'` | `ABSPATH` défini par WordPress → la garde ne s'applique pas |
| Page admin « Diagnostic complet » | classe `Partikulier_Pk_Sonde` (dans pk-diagnostic.php), menu admin, capability + nonce | chargée via `functions.php` → `ABSPATH` défini |
| Entrée URL `?pk_diag=1&pk_diag_jeton=…` | `boot_url_entry()` (pk-diagnostic.php:2254 ; garde 403 l.2258-2268 (`status_header(403)` l.2262), jeton nonce l.2269-2278 (libellé interne « 12 h », pas une durée garantie ici), `DONOTCACHEPAGE` l.2279) | branchée sur `template_redirect` → WordPress chargé |

#### 4.1.3 REPRODUCTION RA-1 (avant toute édition)

Installer le thème original sur WordPress local réel ; démarrer le serveur via le gestionnaire de processus du runner. Le routeur doit exécuter les fichiers PHP réellement présents, sinon une 404 émise par le routeur ne prouve pas le comportement de la garde.

```bash
mkdir -p "$PROOFS/RA-1/avant" "$PROOFS/RA-1/apres"
curl --silent --show-error --max-time 20 \
  -o "$PROOFS/RA-1/avant/body.bin" -D "$PROOFS/RA-1/avant/headers.txt" \
  -w 'CODE=%{http_code} SIZE=%{size_download}\n' \
  "$BASE/wp-content/themes/partikulier/pk-diagnostic.php" \
  > "$PROOFS/RA-1/avant/mesure.txt"
cat "$PROOFS/RA-1/avant/mesure.txt"
wc -c "$PROOFS/RA-1/avant/body.bin"
```

Attendu sur la référence servie directement : **200**, zéro octet. Sans cet avant démontré, arrêter et expliquer routeur, règle serveur ou état source divergent.

Contrôles de référence :
- accueil `/fr/` direct 200 dans le contexte SE-025 ; suivre séparément la politique éventuelle de redirection de `/`, ne pas la masquer avec `curl -L` ;
- écran `/wp-admin/admin.php?page=pk-diagnostic`, authentification admin locale : 200 et écran réel, pas simple page de login ;
- `?pk_diag=1` anonyme : absence de contenu/fonctionnalité diagnostic ; **200 ordinaire observé**, parce que `functions.php` ne charge pas le module pour l’anonyme. Un 403 interne inaccessible n’est pas le contrat effectif ;
- admin, jeton absent/invalide : rejet du jeton, pas exécution du diagnostic ;
- WP-CLI : chargement de la sonde et inventaire des 11 agents sur la référence ;
- lien signé valide : parcours légitime à tester avant/après avec la même session admin, sans archiver le jeton.

**Dernier point non couvert intégralement par la revue précédente.** Prévoir un serveur capable de traiter simultanément la requête diagnostic et ses sous-requêtes HTTP, avec timeout externe et intégrations sortantes bloquées. Un `php -S` mono-worker peut s’auto-bloquer sur ces appels. Le test ne doit pas être déclaré vert sur la seule accessibilité de l’écran admin.

#### 4.1.4 CHANGEMENT — édition exacte (E-3201)

Remplacer les lignes 72-74 de `theme/partikulier/pk-diagnostic.php` :

**AVANT (3 lignes) :**
```php
if ( ! defined( 'ABSPATH' ) ) {
        exit;
}
```

**APRÈS (6 lignes) :**
```php
if ( ! defined( 'ABSPATH' ) ) {
        if ( 'cli' !== PHP_SAPI ) {
                http_response_code( 404 ); // E-3201 : accès HTTP direct = 404, pas un 200 vide.
        }
        exit;
}
```

Justification ligne par ligne :
- `if ( 'cli' !== PHP_SAPI )` — la sonde décrit un usage en ligne de commande (copie posée à la racine WordPress, doc l.14-16 et l.2647 : « `php pk-sonde.php` en CLI »). En CLI, `ABSPATH` est également indéfini ; le comportement CLI actuel (`exit` silencieux) est donc **préservé à l'identique** — l'exigence E-3201 ne concerne que l'accès HTTP.
- `http_response_code( 404 )` — utilisable hors WordPress (les fonctions WP comme `status_header()` ne le sont PAS ici, puisque WordPress n'est pas chargé). Fixe le statut à 404 pour le SAPI web.
- `exit;` — inchangé : aucun corps, aucune fuite d'information sur l'outil.

**Interdits :** ne pas ajouter de message HTML (le 404 doit rester vide), ne pas toucher au bloc de commentaire SE-020 au-dessus, ne pas modifier `PK_SONDE_VERSION` (ce n'est pas un bump de version de sonde), ne pas « profiter » de l'édition pour réindenter le fichier.

#### 4.1.5 Vérifications post-édition

```bash
php -l theme/partikulier/pk-diagnostic.php          # → No syntax errors detected
# Rejouer RA-1 : même curl → attendu CODE=404, SIZE=0
# Rejouer le contrôle négatif : accueil 200, admin inchangée
grep -n "E-3201" theme/partikulier/pk-diagnostic.php  # → exactement 1 occurrence (le commentaire)
```

#### 4.1.6 Test et critères d’acceptation E-3201

Rejouer le même curl après édition en remplaçant `/avant/` par `/apres/`. Aucun suivi de redirection.

- [ ] Avant = 200, zéro octet ; après = **404, zéro octet** sur le même chemin et le même routeur.
- [ ] `php -l` OK ; version de sonde et autres lignes non modifiées.
- [ ] `/fr/` 200 ; écran admin réel accessible ; jetons absents/invalides rejetés ; bootstrap WP-CLI conservé.
- [ ] Anonyme `?pk_diag=1` : comportement de référence conservé et **aucun diagnostic divulgué**. Ne pas exiger un 403 nouveau dans le lot A minimal.
- [ ] Parcours via jeton signé valide exécuté avant/après ; statut, génération de rapport et absence de régression documentés sans secrets.
- [ ] PHP CLI direct hors WordPress : sortie silencieuse et code de fin inchangés.
- [ ] Diff de ce fichier : ajout de la seule garde HTTP 404, trois lignes nettes.

**Si le parcours signé valide n’a pas pu être testé : A reste « recette partielle »**, même si le correctif 404 fonctionne. Un éventuel changement visant un 403 anonyme explicite requiert un lot/arbitrage distinct : il touche le chargement/routage, pas cette garde hors WordPress.

### 4.2 E-3203 — `Requires PHP` du thème aligné sur 8.1

#### 4.2.1 ANCRE — code actuel (repère sur 4b41bd6, à relire avant édition)

Trois constats, un seul écart :

| Fichier:Ligne | Contenu actuel | Statut |
|---|---|---|
| `theme/partikulier/style.css:9` | `Requires PHP: 8.0` | **à corriger** (en-tête du thème) |
| `theme/partikulier/readme.txt:7` | `Requires PHP: 8.0` | **à corriger** (en-tête du readme) |
| `plugin/partikulier-core/partikulier-core.php:6` | `Requires PHP: 8.1` (bloc de doc) | déjà aligné — ne pas toucher |
| `.github/workflows/ci.yml:15` | `php: ['8.1', '8.2', '8.3']` (matrice lint) | déjà aligné — ne pas toucher |
| `.github/workflows/ci.yml:62` | `php: ['8.1', '8.2', '8.3']` (matrice contrats statiques) | déjà aligné — ne pas toucher |

Pour localiser sans ambiguïté — `style.css` l.1-13 :
```css
/*
Theme Name: Partikulier CDC v1.8 — final30
Theme URI: https://partikulier.com/
Author: Partikulier Team
Author URI: https://partikulier.com/
Description: Theme de portail immobilier pour Partikulier.com. [...]
Version: 6.20.7
Requires at least: 6.2
Requires PHP: 8.0
Tested up to: 7.1
```

`readme.txt` l.1-10 :
```text
=== Partikulier ===

Contributors: partikulier
Tags: real-estate, property, listings, immobilier, performance, avif
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 6.20.7
```

#### 4.2.2 CHANGEMENT — édition exacte (2 lignes)

- `theme/partikulier/style.css:9` : `Requires PHP: 8.0` → `Requires PHP: 8.1`
- `theme/partikulier/readme.txt:7` : `Requires PHP: 8.0` → `Requires PHP: 8.1`

**Interdits et pièges :**
- **Ne pas** modifier la ligne `Version: 6.20.7` de style.css ni `Stable tag: 6.20.7` de readme.txt (aucun bump de version en Phase 1 — un éventuel numéro de release futur sera proposé séparément à la clôture ; aucun numéro nouveau n’est acté par cette phase).
- **Ne pas** réécrire l'historique du changelog : `readme.txt:227` contient « Compatibilité déclarée : PHP 8.0+ et WordPress 7.1 testé. » dans une **entrée historique** (version 6.8.0) — on ne réécrit jamais une entrée de changelog passée. Seule l'en-tête (l.7) change.
- Ne rien changer d'autre dans les deux fichiers.

#### 4.2.3 Vérifications post-édition et critères d'acceptation

```bash
git diff --stat            # 2 fichiers, 2 insertions, 2 suppressions, exactement
grep -n "Requires PHP" theme/partikulier/style.css theme/partikulier/readme.txt \
     plugin/partikulier-core/partikulier-core.php   # → 8.1 / 8.1 / 8.1
```

- [ ] Les 3 déclarations `Requires PHP` (thème CSS, thème readme, plugin) affichent toutes 8.1.
- [ ] `Version`/`Stable tag` inchangés (6.20.7).
- [ ] Entrée historique readme.txt:227 inchangée (toujours « PHP 8.0+ » — c'est un fait historique).
- [ ] Diff = 2 fichiers / 2 lignes.

### 4.3 E-3202 — documentation « RateLimiter derrière proxy » (DP-4 ouvert)

#### 4.3.1 ANCRE — les trois lecteurs d'IP du projet (repères sur 4b41bd6, à relire avant édition)

Toute l'identité « par visiteur » du projet repose sur `REMOTE_ADDR` :

| Fichier:Ligne | Code (extrait littéral) | Rôle |
|---|---|---|
| `plugin/partikulier-core/src/RateLimiter.php:19` | `$identity = is_user_logged_in() ? 'user:' . (string) get_current_user_id() : 'ip:' . $this->clientIp();` | identité du quota REST |
| `plugin/partikulier-core/src/RateLimiter.php:64-69` | `private function clientIp(): string { $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash( (string) $_SERVER['REMOTE_ADDR'])) : 'unknown'; return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : 'unknown'; }` | lecture de l'IP |
| `plugin/partikulier-core/src/Domain/Leads/LeadsEraseGuardTrait.php:223` | `$ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash( (string) $_SERVER['REMOTE_ADDR'])) : 'unknown';` | garde d'effacement lead |
| `theme/partikulier/inc/class-security.php:84` | `$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) : 'unknown'; // ... haché (hash_hmac) en clef de transient` | limiteur de dépôt du thème |

Document cible : `docs/INSTALLATION.md`, section existante **« Configuration sensible »** (l.61-63). C'est la doc d'exploitation de référence du dépôt (son §« Déploiement » décrit `package.sh` et l'ordre plugin→thème ; son §« Vérifications post-déploiement » décrit la route de santé).

#### 4.3.2 CHANGEMENT — documentation uniquement, AUCUN code (E-3202 + précision n°4)

Ajouter dans `docs/INSTALLATION.md` une sous-section **« Limiteurs derrière le CDN (DP-4 — statut ouvert) »** juste après « Configuration sensible », avec ce contenu exigé (l'agent peut ajuster la forme, pas le fond) :

1. **Constat** : les trois limiteurs (RateLimiter REST, LeadsEraseGuard, limiteur de dépôt du thème) identifient le visiteur par `REMOTE_ADDR` (référencer les 4 lignes du tableau 4.3.1).
2. **Risque CDN** : le retour support identifie le CDN Hostinger (nom `*.cdn.hstgr.net`). Une observation DNS est rapportée par l’autre agent ; ne pas la présenter comme une nouvelle mesure de cette v2 ni comme une preuve de `REMOTE_ADDR`. Si `REMOTE_ADDR` est l'IP du proxy et non celle du visiteur, tous les visiteurs anonymes partagent une même identité de quota : la protection « quota par visiteur » est dégradée (la protection anti-charge globale, elle, reste).
3. **Statut DP-4 : OUVERT.** `REMOTE_ADDR` derrière ce CDN n'est pas confirmé ; aucune décision n'est prise tant que la vérification Hostinger n'est pas faite (message de suivi référencé : `MESSAGE-HOSTINGER-DP4-SUIVI.md`, à joindre intégralement puis à transmettre par le commanditaire uniquement).
4. **Règle d'ingénierie (interdiction)** : **ne jamais** lire `X-Forwarded-For` / `X-Real-IP` ni installer un résolveur d'IP de confiance sans chaîne de confiance vérifiée — un en-tête arbitraire laissé au client permettrait à n'importe quel visiteur de choisir son identité de quota (usurpation).
5. **Critère de décision** (explicité ici sans dépendre du plan non joint) : IP réelle restaurée et non usurpable → conserver `REMOTE_ADDR` et le documenter ; IP proxy commune → correction côté Hostinger en priorité, sinon résolveur commun avec chaîne de confiance documentée ; identité usurpable ou chaîne inconnue → ne pas valider la protection « quota par visiteur ».
6. **Périmètre applicatif** concerné à l'identique : `RateLimiter.php`, `LeadsEraseGuardTrait.php`, `class-security.php`.

#### 4.3.3 Critères d'acceptation E-3202

- [ ] La section existe dans `docs/INSTALLATION.md`, cite les 4 ancres fichier:ligne et le statut DP-4 ouvert.
- [ ] **Aucune ligne de code modifiée** pour E-3202 (le diff du lot A ne touche que les fichiers §4.1 et §4.2 pour le code).
- [ ] La règle « pas de X-Forwarded-For sans chaîne de confiance » est écrite noir sur blanc (c'est elle qui empêche un futur agent d'« améliorer » ça tout seul).

### 4.4 Récapitulatif du diff LOT A attendu

```text
theme/partikulier/pk-diagnostic.php | 3 lignes remplacées par 6 (garde 404)
theme/partikulier/style.css          | 1 ligne (Requires PHP)
theme/partikulier/readme.txt         | 1 ligne (Requires PHP)
docs/INSTALLATION.md                 | 1 section ajoutée (E-3202, doc seule)
```
Aucun autre fichier. Aucun test automatisé nouveau pour ce lot (les vérifications sont des commandes de recette incluses au rapport) — sauf décision contraire du commanditaire.

---

## 5. LOT B — SE-041 : durcissement XML-RPC (E-4101) + épinglage prod (E-4102)

> Exigences CDC v5.7.1 §13I (Lot 17), reprises de la v1 et précisées opérationnellement par cette v2 :
> - **E-4101** — « `add_filter('xmlrpc_methods', '__return_empty_array')` **ou** 403 HTTP brut sur toute requête `xmlrpc.php` ; contrat : `system.listMethods` ne liste aucune méthode applicative (exactement trois méthodes système avec la variante filtre), `demo.sayHello` et `pingback.ping` ne sont plus exécutables. Vérifier le comportement du paquet final installé, pas la disparition d’un nom dans les sources du cœur WordPress. »
> - **E-4102** — « Playbook production : épinglage des binaires (`partikulier_exec_whitelist` + `PARTIKULIER_EXEC_REQUIRE_PIN`) versé à la doc d'exploitation (y compris la consigne nginx du polyglotte — scoper PHP-FPM hors `/wp-content/uploads/`, `X-Content-Type-Options: nosniff` ; consignes `expires 1y + immutable` sur les assets fingerprintés, gzip/brotli sur texte, activation de `PARTIKULIER_ENABLE_AVIF_DELIVERY` après vérification du MIME `image/avif`). »
> Estimation historique de la v1 : 1 h + doc, non validée ni réestimée ici. Priorité : F-SEC-1, niveau MOYEN annoncé par la v1.

### 5.1 E-4101 — état actuel et lacune EXACTE

#### 5.1.1 ANCRE — code actuel (repère sur 4b41bd6, à relire avant édition)

Fichier : `theme/partikulier/inc/class-security.php`. Méthode `init()` (l.16-21) :

```php
        public static function init() {
                add_filter( 'rest_endpoints', array( __CLASS__, 'restrict_user_enumeration' ) );
                add_action( 'template_redirect', array( __CLASS__, 'block_public_author_enumeration' ), 0 );
                add_action( 'send_headers', array( __CLASS__, 'send_public_headers' ) );
                add_filter( 'xmlrpc_enabled', '__return_false' );
        }
```

La ligne 20 (`add_filter( 'xmlrpc_enabled', '__return_false' );`) est **déjà livrée** (train antérieur). L'indentation du fichier est en **tabulations** — la nouvelle ligne utilisera une tabulation.

#### 5.1.2 Pourquoi ce qui existe ne suffit pas (preuve dans le cœur WordPress)

Le filtre `xmlrpc_enabled` est appliqué **uniquement** dans `wp_xmlrpc_server::set_is_enabled()` (`wp-includes/class-wp-xmlrpc-server.php:189-223`), et la propriété n'est testée **que dans `login()`** (`class-wp-xmlrpc-server.php`, première ligne de `login()` : `if ( ! $this->is_enabled ) { $this->error = new IXR_Error( 405, ... ) }`). La documentation du cœur est explicite (commentaire du filtre, l.205-213) :

> « Contrary to the way it's named, this filter does not control whether XML-RPC is *fully* enabled, rather, it only controls whether XML-RPC methods requiring authentication — such as for publishing purposes — are enabled. **Further, the filter does not control whether pingbacks or other custom endpoints that don't require authentication are enabled.** »

**Conséquence mesurable avec le code actuel :**
- méthodes authentifiées (`wp.getPosts`, etc.) → refusées (fault 405) ✔ déjà couvert ;
- **`system.listMethods` répond et liste encore les méthodes applicatives** (dont `pingback.ping`, `demo.sayHello`) ✘ ;
- **`demo.sayHello` s'exécute encore** (réponse « Hello! ») ✘ ;
- **`pingback.ping` reste exposé** (vecteur d'abus classique : pingback spam / SSRF interne) ✘.

C'est exactement l'écart E-4101 : le CDC exige `xmlrpc_methods` → `__return_empty_array`, qui vide la table des méthodes applicatives du serveur (le filtre est appliqué dans le constructeur de `wp_xmlrpc_server`, avant le dispatch).

**Complément mécanique :** IXR ajoute après filtrage `system.getCapabilities`, `system.listMethods`, `system.multicall`. Avec la variante filtre, la liste correcte contient **exactement ces trois méthodes**, sans doublon. Une liste vide ou un fault sur `system.listMethods` n’est pas le résultat de cette variante. Les appels `demo.sayHello` et `pingback.ping` répondent par fault `-32601`, en HTTP 200 sur la référence.

Un refus HTTP 403 peut aussi être implémenté en PHP, par exemple dans un MU-plugin conditionné à `XMLRPC_REQUEST` ; un démonstrateur réel de revue l’a confirmé puis a été supprimé. Cela reste plus tardif qu’un blocage serveur. **Ne pas affirmer que le 403 PHP serait impossible, ni le confondre avec le problème d’identité IP DP-4.** Le lot présent choisit la variante filtre.

#### 5.1.3 REPRODUCTION RB-1 (avant toute édition)

Sur le WordPress local de référence, capturer les statuts **et** les corps, sans `-L` ni `curl -f` qui masqueraient les faults utiles.

```bash
mkdir -p "$PROOFS/RB-1/avant" "$PROOFS/RB-1/apres"
RB="$PROOFS/RB-1/avant"
curl -sS --max-time 20 -D "$RB/listmethods.headers" -o "$RB/listmethods.xml" \
  -w '%{http_code}\n' "$BASE/xmlrpc.php" -H 'Content-Type: text/xml' \
  --data '<methodCall><methodName>system.listMethods</methodName></methodCall>' \
  > "$RB/listmethods.status"
python3 "$TOOLS/xmlrpc-audit.py" avant-liste "$RB/listmethods.xml" > "$RB/analyse-liste.json"

curl -sS --max-time 20 -D "$RB/hello.headers" -o "$RB/hello.xml" \
  -w '%{http_code}\n' "$BASE/xmlrpc.php" -H 'Content-Type: text/xml' \
  --data '<methodCall><methodName>demo.sayHello</methodName></methodCall>' \
  > "$RB/hello.status"
```

Attendus avant : HTTP 200 ; liste XML valide contenant `pingback.ping` et `demo.sayHello` ; réponse `Hello!` pour la seconde. La preuve est la valeur XML, pas un mot apparaissant dans une page d’erreur HTML. Le helper de liste refuse XML invalide, fault et tableau absent.

Pour `pingback.ping`, reproduire localement une réponse distincte de `-32601`, avec deux URL de test ne ciblant **aucun tiers ni réseau interne sensible**. Le laboratoire bloque les sorties HTTP sortantes ; ne pas utiliser une vraie cible ou un domaine client. Exemple de paramètres réservés à la recette :

```bash
curl -sS --max-time 20 -D "$RB/pingback.headers" -o "$RB/pingback.xml" \
  -w '%{http_code}\n' "$BASE/xmlrpc.php" -H 'Content-Type: text/xml' \
  --data '<methodCall><methodName>pingback.ping</methodName><params><param><value><string>http://source.invalid/</string></value></param><param><value><string>http://cible.invalid/</string></value></param></params></methodCall>' \
  > "$RB/pingback.status"
```

**Important :** `system.listMethods` encode les noms dans `<string>`, pas dans `<name>`. La v1 recherchait la mauvaise balise : elle trouvait zéro alors que la méthode était présente. L’analyseur fourni compare la liste réellement décodée.

Après le correctif, rejouer les mêmes requêtes avec `RB="$PROOFS/RB-1/apres"` puis :

```bash
python3 "$TOOLS/xmlrpc-audit.py" apres-liste "$RB/listmethods.xml" > "$RB/analyse-liste.json"
python3 "$TOOLS/xmlrpc-audit.py" apres-demo "$RB/hello.xml" > "$RB/analyse-demo.json"
python3 "$TOOLS/xmlrpc-audit.py" apres-pingback "$RB/pingback.xml" > "$RB/analyse-pingback.json"
```

Vérifier **séparément** les trois statuts HTTP enregistrés ; ces helpers analysent le corps, ils ne prouvent pas l’origine ni le transport de la réponse. Une page WAF, une erreur serveur ou un fichier d’une campagne antérieure n’est pas une preuve du filtre installé.

La sonde `staging-securite.php:179-182` classe un HTTP 200 comme « répond » plutôt que « bloqué ». Ne pas promettre qu’elle atteste ce nouveau contrat : elle ne décode pas les méthodes et peut continuer à signaler cette réponse. Consigner son verdict, sans le convertir arbitrairement en PASS.

#### 5.1.4 CHANGEMENT — édition exacte (1 ligne)

Dans `theme/partikulier/inc/class-security.php`, `init()` — insérer UNE ligne après la l.20 :

**AVANT (l.16-21) :**
```php
        public static function init() {
                add_filter( 'rest_endpoints', array( __CLASS__, 'restrict_user_enumeration' ) );
                add_action( 'template_redirect', array( __CLASS__, 'block_public_author_enumeration' ), 0 );
                add_action( 'send_headers', array( __CLASS__, 'send_public_headers' ) );
                add_filter( 'xmlrpc_enabled', '__return_false' );
        }
```

**APRÈS (l.16-22) :**
```php
        public static function init() {
                add_filter( 'rest_endpoints', array( __CLASS__, 'restrict_user_enumeration' ) );
                add_action( 'template_redirect', array( __CLASS__, 'block_public_author_enumeration' ), 0 );
                add_action( 'send_headers', array( __CLASS__, 'send_public_headers' ) );
                add_filter( 'xmlrpc_enabled', '__return_false' );
                add_filter( 'xmlrpc_methods', '__return_empty_array' ); // E-4101 : vide aussi les méthodes SANS authentification (pingback, demo) que xmlrpc_enabled ne couvre pas.
        }
```

Justification : le cœur applique `xmlrpc_methods` dans le constructeur du serveur — la table des callbacks applicatifs devient vide ; `pingback.ping` et `demo.sayHello` retournent un fault `-32601` (« requested method does not exist ») ; `system.listMethods` ne liste plus que les 3 méthodes d'introspection `system.*` ajoutées par IXR.

**Interdits :** ne pas retirer la ligne `xmlrpc_enabled` (défense en profondeur : elle couvre le login des méthodes authentifiées) ; ne pas implémenter la variante « 403 brut » en PHP sans arbitrage (5.1.5) ; ne pas toucher au reste de la classe ; tabulation, pas d'espaces.

#### 5.1.5 Choix de variante et limite d’exploitation

**Variante retenue pour préparer ce lot : filtre `xmlrpc_methods`**, en conservant `xmlrpc_enabled`. Choix minimal, portable, déjà essayé localement. Il neutralise les méthodes applicatives, **pas toute réponse HTTP à `xmlrpc.php`**.

Le 403 au niveau serveur peut être proposé en complément d’exploitation : il coupe plus tôt, avant le coût du bootstrap WordPress. Sa mise en place et son efficacité sur GET/POST relèvent d’une recette Hostinger séparée. Le 403 PHP est techniquement possible mais **non ajouté à ce diff**. Ne pas combiner silencieusement les variantes : un blocage global masquerait les réponses attendues des tests du filtre.

Le rapport de lot rappelle ce choix. Si le commanditaire préfère la fermeture HTTP totale, soumettre un changement de critères et de diff ; ne pas remplacer les attendus -32601 par un 403 sans accord.

#### 5.1.6 Test — nouveau contrat `se041-xmlrpc-contract.php`

Créer `theme/partikulier/tests/se041-xmlrpc-contract.php` sur le modèle des contrats existants (**un seul JSON stdout**, compte rendu dans `results`, stderr réservé aux diagnostics). Assertions exigées :

| # | Assertion | Méthode |
|---|---|---|
| E41-001 | Le filtre `xmlrpc_methods` est enregistré sur `__return_empty_array` | `has_filter( 'xmlrpc_methods', '__return_empty_array' ) !== false` |
| E41-002 | `apply_filters( 'xmlrpc_methods', array( 'pingback.ping' => 'x', 'demo.sayHello' => 'y' ) )` renvoie `array()` | filtre appliqué directement (WordPress chargé) |
| E41-003 | `apply_filters( 'xmlrpc_enabled', true )` renvoie `false` (non-régression de la ligne existante) | filtre appliqué |
| E41-004 | HTTP réel : POST `system.listMethods` → 200 et tableau XML valide contenant exactement `system.getCapabilities`, `system.listMethods`, `system.multicall`, sans doublon ni autre méthode | batterie HTTP sur serveur de test (pattern `se022-http-battery.php` : serveur `php -S` + `router-ci.php`) |
| E41-005 | HTTP réel : POST `demo.sayHello` → fault `-32601` (et aucun `Hello!` dans le corps) | idem |
| E41-006 | HTTP réel : POST `pingback.ping` (2 paramètres URL) → fault `-32601` | idem |

**Enregistrement en CI :** B est préparé **après A**. Ajouter une étape HTTP sur le modèle SE-025, à origine de test cohérente, après la configuration trilingue et avant l’oracle. Conserver l’ordre des anciennes suites. Ajouter exactement un JSON final `se041-xmlrpc-contract.json` à l’agrégateur, six assertions uniques, et passer **370/370, 38 suites → 376/376, 39 suites**. Mettre à jour intitulé, contrôle numérique et commentaire de décomposition. Pas de texte avant le JSON ; statut HTTP et XML tous deux contrôlés.

Tester le nouveau contrat contre le **code original** : il doit échouer sur l’absence du filtre et l’exposition applicative, pas sur une erreur de bootstrap. Puis six assertions PASS après B. Une absence de `pingback` due à une autre version/configuration WordPress doit être documentée, pas contournée silencieusement. La référence WP6.6 de revue contenait bien cette méthode.

#### 5.1.7 Critères d'acceptation E-4101

- [ ] RB-1 avant : 3 preuves brutes (listMethods liste pingback+demo ; Hello! exécuté ; pingback inscrit).
- [ ] Après : rejeu RB-1 → listMethods ne contient plus `pingback.`/`demo.`/`wp.` ; `demo.sayHello` → fault -32601 ; `pingback.ping` → fault -32601.
- [ ] `php -l class-security.php` OK ; le contrat `se041-xmlrpc-contract.php` passe 6/6 en local.
- [ ] CI : oracle mis à jour 376/376 avec commentaire de décomposition exact.
- [ ] Diff lot B = 1 ligne de code + 1 nouveau fichier de test + 1 édition de workflow + doc E-4102 (ci-dessous). Rien d'autre.

### 5.2 E-4102 — playbook production versé à la doc d'exploitation

#### 5.2.1 ANCRE — mécanismes existants à documenter (repères sur 4b41bd6, à relire avant édition)

| Mécanisme | Ancrage | Rôle |
|---|---|---|
| Liste blanche d'exécution | `theme/partikulier/inc/class-exec-whitelist.php:93` — `apply_filters( 'partikulier_exec_whitelist', $entries )` ; doc l.38 : « 'partikulier_exec_whitelist', et la constante PARTIKULIER_EXEC_REQUIRE_PIN » | passerelle unique des appels système du thème |
| Épinglage des binaires | `class-exec-whitelist.php:149` — `return defined( 'PARTIKULIER_EXEC_REQUIRE_PIN' ) && PARTIKULIER_EXEC_REQUIRE_PIN;` | en production, exiger l'épingle (hash) des binaires listés |
| Livraison AVIF | `theme/partikulier/inc/class-avif.php:347` — `if ( ! defined( 'PARTIKULIER_ENABLE_AVIF_DELIVERY' ) || ! PARTIKULIER_ENABLE_AVIF_DELIVERY ) {` | la conversion existe ; la **livraison** est gardée par cette constante, éteinte par défaut |
| En-tête nosniff | déjà envoyé par le thème : `class-security.php` `send_public_headers()` → `header( 'X-Content-Type-Options: nosniff' );` | complément de la consigne nginx |

Cible documentaire : `docs/INSTALLATION.md` (même section « Configuration sensible » que E-3202 — deux sous-sections distinctes, ou une section « Playbook production (E-4102) » regroupant les consignes ci-dessous).

#### 5.2.2 Contenu exigé de la section (doc seule, aucun code)

1. **Épinglage des exécutables** : en production, définir la constante PHP `PARTIKULIER_EXEC_REQUIRE_PIN` dans `wp-config.php` (une variable d’environnement seule ne suffit pas sans code explicite qui la transforme en constante) et fournir la liste épinglée via le filtre `partikulier_exec_whitelist` — chaque entrée conserve le schéma réel `candidates` (chemins absolus) et `sha256` (empreinte attendue de 64 caractères hexadécimaux), à relire dans la classe ; tout écart (binaire remplacé, absent) est refusé et journalisé. Expliquer le « pourquoi » : un chemin exécutable autorisé n’atteste pas le contenu du binaire. L’épingle permet de refuser un binaire modifié. Documenter la mise à jour contrôlée des empreintes après maintenance ; ne pas confondre épinglage, validation d’images et configuration HTTP. Toute mesure S20 non jointe est une observation historique annoncée, pas une nouvelle preuve de cette v2.
2. **Consigne nginx/LiteSpeed « polyglotte »** : scoper PHP-FPM hors `/wp-content/uploads/` (un fichier `.php` déguisé en image ne doit jamais être interprété) et s'assurer que `X-Content-Type-Options: nosniff` est bien actif au niveau serveur (le thème l'envoie déjà côté PHP ; la consigne serveur couvre les fichiers statiques servis directement).
3. **Cache assets** : `expires 1y + immutable` sur les assets fingerprintés (réserver cette règle aux URL dont l’invalidation par contenu est effectivement vérifiée : un fichier modifié doit obtenir une URL distincte, que le cache/CDN distingue réellement. Ne pas déduire cette propriété de la seule mention E-3102) ; gzip/brotli actif sur les réponses texte, à mesurer sur l’hébergement ; l’ancienne mesure S20 annoncée ne remplace pas cette recette. Ne pas appliquer un an/immutable aux pages HTML, REST, diagnostic ou espaces privés.
4. **AVIF** : après déploiement, vérifier le MIME `image/avif` réellement servi par l'hébergeur, PUIS définir `PARTIKULIER_ENABLE_AVIF_DELIVERY` ; si le serveur sert un mauvais MIME, laisser la constante éteinte et le consigner. Vérifier aussi le décodage réel dans les navigateurs et le repli ; MIME, décodage et autorisation d’exécution sont des contrôles différents.
5. **Statut** : ces consignes relèvent de l'exploitation Hostinger ; elles seront vérifiées dans la recette d’exploitation Hostinger, distincte du contrôle d’identité IP DP-4 qui reste ouvert.

#### 5.2.3 Critères d'acceptation E-4102

- [ ] Section présente dans `docs/INSTALLATION.md` avec les 5 points, chacune des constantes/filtres citée par son nom exact (`PARTIKULIER_EXEC_REQUIRE_PIN`, `partikulier_exec_whitelist`, `PARTIKULIER_ENABLE_AVIF_DELIVERY`).
- [ ] Aucune constante ajoutée/modifiée dans le code pour ce point (doc seule).
- [ ] La recette d’exploitation Hostinger est indiquée non exécutée ; le contrôle d’identité IP DP-4 reste ouvert et distinct.

### 5.3 Récapitulatif du diff LOT B attendu

```text
theme/partikulier/inc/class-security.php   | +1 ligne (filtre xmlrpc_methods)
theme/partikulier/tests/se041-xmlrpc-contract.php | nouveau fichier (6 assertions)
.github/workflows/contrats-recette.yml     | étape + décompte + oracle 370→376
docs/INSTALLATION.md                       | section E-4102 (doc seule)
```

---

## 6. LOT C — SE-027 : double-préfixation rewrite avec Polylang

> Exigences CDC v5.7.1 §7 (Lot 4), reprises de la v1 et précisées opérationnellement par cette v2 :
> - **E-2701** — « Diagnostic versionné (dump `rewrite_rules` avant/après, motifs `(fr|en|ar)/(fr|en|ar)`). »
> - **E-2702** — « Avec `POLYLANG_VERSION` : règles sans préfixe (Polylang préfixe) ; sans Polylang : règles préfixées conservées. »
> - **E-2703** — « Contrat : 3 flush consécutifs → zéro motif double-préfixé ; URLs 3 langues 200. »
> Estimation historique de la v1 : ½ j, non validée ni réestimée ici. Priorité P2 (référence A-4 de la v1).

### 6.1 Anatomie du défaut (à comprendre avant d'éditer)

#### 6.1.1 ANCRE — code actuel (repère sur 4b41bd6, à relire avant édition)

Fichier : `theme/partikulier/inc/class-listing-urls.php`.

**Constantes et branchements (l.28-60) :**
```php
        const BASE = 'annonce';                  // l.28
        const RULES_VERSION = '4';               // l.33
        ...
        add_action( 'init', array( __CLASS__, 'add_rules' ), 20 );        // l.39
        ...
        add_action( 'admin_init', array( __CLASS__, 'maybe_flush' ) );    // l.60
```

**Méthode `add_rules()` (repère l.442-487), extrait structurel annoté :**
```php
        public static function add_rules() {
                $base = self::BASE;
                $cpt  = PARTIKULIER_ESTATIK_POST_TYPE;

                // L'archive publique est francisée ; les anciennes URLs restent récupérables.
                add_rewrite_rule( '^property/page/([0-9]+)/?$', 'index.php?post_type=' . $cpt . '&paged=$matches[1]', 'top' );   // l.447
                add_rewrite_rule( '^property/?$', 'index.php?post_type=' . $cpt, 'top' );                                          // l.448

                add_rewrite_rule( '^(fr|en|ar)/annonces/page/([0-9]+)/?$', 'index.php?post_type=' . $cpt . '&paged=$matches[2]&lang=$matches[1]', 'top' );  // l.453
                add_rewrite_rule( '^(fr|en|ar)/annonces/?$', 'index.php?post_type=' . $cpt . '&lang=$matches[1]', 'top' );                                   // l.454
                add_rewrite_rule( '^annonces/page/([0-9]+)/?$', 'index.php?post_type=' . $cpt . '&paged=$matches[1]', 'top' );                               // l.455
                add_rewrite_rule( '^annonces/?$', 'index.php?post_type=' . $cpt, 'top' );                                                                    // l.456
                add_rewrite_rule( '^(fr|en|ar)/location/([^/]+)/?$', 'index.php?post_type=' . $cpt . '&pk_city_slug=$matches[2]&lang=$matches[1]', 'top' );  // l.457
                        add_rewrite_rule( '^location/([^/]+)/?$', 'index.php?post_type=' . $cpt . '&pk_city_slug=$matches[1]', 'top' );                          // l.458

                add_rewrite_rule(                                                                                                                            // l.463-467
                        '^(fr|en|ar)/' . $base . '/[^/]+/[^/]+/([^/]+)/?$',
                        'index.php?post_type=' . $cpt . '&pk_listing_slug=$matches[2]&lang=$matches[1]',
                        'top'
                );
                add_rewrite_rule(                                                                                                                            // l.468-472
                        '^(fr|en|ar)/' . $base . '/[^/]+/([^/]+)/?$',
                        'index.php?post_type=' . $cpt . '&pk_listing_slug=$matches[2]&lang=$matches[1]',
                        'top'
                );

                add_rewrite_rule(                                                                                                                            // l.475-479
                        '^' . $base . '/[^/]+/[^/]+/([^/]+)/?$',
                        'index.php?post_type=' . $cpt . '&pk_listing_slug=$matches[1]',
                        'top'
                );
                add_rewrite_rule(                                                                                                                            // l.482-486
                        '^' . $base . '/[^/]+/([^/]+)/?$',
                        'index.php?post_type=' . $cpt . '&pk_listing_slug=$matches[1]',
                        'top'
                );
        }
```

(Extrait de structure, pas copie intégrale : des commentaires et annotations de lignes sont omis/ajoutés ici. Dans le diff final, conserver les commentaires encore exacts et adapter uniquement ceux qui seraient rendus faux par le conditionnement Polylang.)

**Mécanisme observé :** dans la configuration de référence Polylang 3.8.7, les cinq règles déjà préfixées sont préfixées une seconde fois. Exemples bruts :

```text
(en|fr|ar)/(fr|en|ar)/annonces/?$
(en|fr|ar)/(fr|en|ar)/annonce/[^/]+/([^/]+)/?$
```

Le préfixage dépend de la configuration et des types traduisibles ; **ne pas affirmer universellement que Polylang préfixe toute règle personnalisée**. La suppression conditionnelle de ces cinq déclarations a été essayée avec succès dans la configuration de référence, ce qui motive le diff demandé. L’existence de ces règles supplémentaires ne suffit pas à attribuer tous les anciens problèmes de navigation à ce seul défaut.

Sans Polylang, les cinq règles préfixées doivent rester déclarées. La présence de regex seule ne prouve ni la bonne cible ni la priorité des règles : contrôler les cibles et les requêtes réelles.

#### 6.1.2 REPRODUCTION RC-1 et détecteur indépendant de l’ordre

Le script fourni `outils/rewrite-audit.php` est une sonde WP-CLI **en lecture seule** : il lit `get_option('rewrite_rules')` et n’appelle pas de flush, même implicite. Une table absente ou vide entraîne un échec et une préparation explicite, pas une régénération cachée. Il lit les langues réellement configurées, sauvegarde toutes les règles dans leur ordre et détecte deux groupes de langues consécutifs, indépendamment de l’ordre des alternatives et avec ou sans `^` initial.

```bash
mkdir -p "$PROOFS/RC-1"
wp --path="$WP_DIR" eval-file "$TOOLS/rewrite-audit.php" \
  > "$PROOFS/RC-1/avant.json" 2> "$PROOFS/RC-1/avant.err"
```

Contenu obligatoire du JSON : versions WP/PHP/Polylang, `RULES_VERSION`, option `pk_url_rules_version`, langues, total, doubles avec leurs cibles, **toutes les règles→cibles**. La sonde refuse un dump vide ou invalide. Son code 0 signifie « collecte réussie », **pas « aucun défaut »** : le contrat doit contrôler `double_count`.

**Contrôle positif avant patch :** dans l’installation de référence de revue, `total=303`, `double_count=5`. Les cinq règles concernent annonces/page, annonces, location, fiche avec quartier, fiche sans quartier. Exiger qu’elles soient réellement détectées ; le total 303 est une observation, pas un invariant universel si d’autres plugins/configurations sont présents. Tout écart est expliqué avant correction.

**Limite explicite du détecteur fourni :** il couvre les formes à groupes de langues produites dans la configuration figée, pas un parseur universel de toute regex imaginable. Si la version/configuration génère d’autres formes, arrêter et étendre les contrôles avec un cas positif démontré, sans traiter la forme inconnue comme un succès. Les contrôles unitaires de recette doivent inclure permutations, `^` présent/absent, groupes non capturants, une règle simple et un groupe qui n’est pas une langue.

**Contre-test v1 obligatoire :** démontrer dans le rapport que la recherche figée `(fr|en|ar)/(fr|en|ar)` manquerait les règles dont le premier groupe est `(en|fr|ar)`. La revue l’a mesuré : zéro selon la v1, cinq réels.

**Branche sans Polylang :** avant toute modification C, capturer aussi les règles et les URL de contrôle sur une copie locale ou lors d’une désactivation encadrée, toujours avec **nouveau processus PHP après désactivation**. Restaurer la configuration trilingue et régénérer avant de poursuivre. Un `POLYLANG_VERSION` déjà défini ne disparaît pas pendant le processus qui désactive le plugin.

Les scripts et leurs formes exactes figurent en annexe B. Les tests de ces sondes sur preuves conservées ne dispensent pas de les exécuter sur l’instance vivante du futur patch.

#### 6.1.3 CHANGEMENT — édition exacte (E-2702)

Deux modifications dans `theme/partikulier/inc/class-listing-urls.php`, RIEN d'autre.

**Modification 1 — bump de version des règles (l.33) :**
```php
        const RULES_VERSION = '5';   // était '4' — déclenche maybe_flush() → flush unique à la première visite admin
```
`maybe_flush()` (repère l.492-497 de la référence) compare `get_option('pk_url_rules_version')` à `RULES_VERSION`. Le bump permet la migration lors de son prochain déclenchement admin ; il ne l’exécute pas à l’édition du fichier. `flush()` (l.500-503) ajoute les règles, appelle `flush_rewrite_rules(false)` puis met à jour l’option. La recette déclenche explicitement ce mécanisme au §6.1.4, sans ajouter de flush sur `init`.

**Modification 2 — conditionner les règles préfixées à l'absence de Polylang.** Dans `add_rules()`, encapsuler les 5 appels préfixés (l.453-454, l.457, l.463-467, l.468-472) :

**AVANT (l.449-472, structure) :** tous les `add_rewrite_rule` sont appelés inconditionnellement (extraits 6.1.1).

**APRÈS (même plage, structure) :**
```php
                // Dans la configuration Polylang de référence, les cinq règles
                // déjà préfixées recevraient un second groupe de langue (SE-027).
                // Conserver leurs déclarations explicites seulement sans Polylang.
                // Les règles sans préfixe restent déclarées ci-dessous.
                $prefix_langue = ! defined( 'POLYLANG_VERSION' );

                if ( $prefix_langue ) {
                        add_rewrite_rule( '^(fr|en|ar)/annonces/page/([0-9]+)/?$', 'index.php?post_type=' . $cpt . '&paged=$matches[2]&lang=$matches[1]', 'top' );
                        add_rewrite_rule( '^(fr|en|ar)/annonces/?$', 'index.php?post_type=' . $cpt . '&lang=$matches[1]', 'top' );
                        add_rewrite_rule( '^(fr|en|ar)/location/([^/]+)/?$', 'index.php?post_type=' . $cpt . '&pk_city_slug=$matches[2]&lang=$matches[1]', 'top' );
                        add_rewrite_rule(
                                '^(fr|en|ar)/' . $base . '/[^/]+/[^/]+/([^/]+)/?$',
                                'index.php?post_type=' . $cpt . '&pk_listing_slug=$matches[2]&lang=$matches[1]',
                                'top'
                        );
                        add_rewrite_rule(
                                '^(fr|en|ar)/' . $base . '/[^/]+/([^/]+)/?$',
                                'index.php?post_type=' . $cpt . '&pk_listing_slug=$matches[2]&lang=$matches[1]',
                                'top'
                        );
                }
```

Et **immédiatement en dessous, inchangées dans leur texte**, les règles sans préfixe (l.455-456, 458, 475-486 de l'état actuel) restent appelées **inconditionnellement** — avec un commentaire ajouté :
```php
                // Règles sans préfixe : toujours déclarées. Avec Polylang, c'est lui qui
                // les décline dans la configuration validée ; sans Polylang, repli sans langue.
```

**Interdits :**
- Ne pas supprimer les règles préfixées — elles sont **déplacées sous condition**, pas retirées (E-2702 : « sans Polylang : règles préfixées conservées »).
- Ne pas toucher aux l.447-448 (`^property/…` legacy), ni à `redirect_legacy_early` (l.371-375), ni aux regex de repli `#^(?:(fr|en|ar)/)?annonce/…#` (l.371, 375) qui, elles, tolèrent le préfixe **simple** et restent correctes.
- Ne pas changer l'ordre `'top'`, ni la signature des `add_rewrite_rule`, ni `maybe_flush`/`flush`.
- Ne pas ajouter de flush supplémentaire ailleurs (le bump de RULES_VERSION suffit ; un `flush_rewrite_rules` en plus sur `init` serait une régression de performance connue de WordPress).

#### 6.1.4 Migration explicite, puis trois flush et dump après

Sur une installation ayant la version stockée 4, après édition du code en version 5 mais **avant visite admin** :

```bash
wp --path="$WP_DIR" eval-file "$TOOLS/rewrite-audit.php" \
  > "$PROOFS/RC-1/apres-code-avant-migration.json"
wp --path="$WP_DIR" eval 'Partikulier_Listing_Urls::maybe_flush();'
wp --path="$WP_DIR" eval-file "$TOOLS/rewrite-audit.php" \
  > "$PROOFS/RC-1/apres-migration.json"
for i in 1 2 3; do
  wp --path="$WP_DIR" eval 'Partikulier_Listing_Urls::flush();'
  wp --path="$WP_DIR" eval-file "$TOOLS/rewrite-audit.php" \
    > "$PROOFS/RC-1/apres-flush-$i.json"
done
```

Attendus observés dans la revue : avant migration **code 5 / option 4 / 303 règles / 5 doubles** ; après migration **code 5 / option 5 / 298 règles / zéro double**. Les trois jeux de règles après flush doivent être stables, **ordre et cibles compris**, pas seulement un même total. Archiver les erreurs et codes de sortie aussi ; une commande échouée ne laisse pas passer le scénario.

La vérification avant migration doit être organisée avant tout accès admin qui pourrait déclencher le hook. Si une migration s’est déjà produite, le consigner ; reconstituer uniquement un scénario isolé en base jetable si nécessaire. Ne pas remettre une installation utilisateur en arrière pour obtenir une preuve.

Vérifier l’idempotence de `maybe_flush()` lorsque l’option vaut déjà 5 : la table/option restent stables. Instrumenter le déclenchement uniquement dans le harnais si l’on veut prouver l’absence de nouveau flush ; ne pas déduire cette absence du seul fait que la table finale est identique. Aucun hook de flush supplémentaire dans le produit.

### 6.2 Nouveau contrat `se027-rewrite-prefix-contract.php`

Six assertions finales, avec sous-résultats détaillés dans un seul JSON. Adapter le harnais aux processus distincts ; ne pas tenter d’« effacer » une constante PHP en cours de processus.

| # | Assertion | Preuve attendue |
|---|---|---|
| E27-001 | Détecteur positif sur le défaut de référence, puis zéro double après chacun des trois flush ; tables après flush identiques | Comparer les regex **et cibles**, ordre conservé, versions/configuration enregistrées. Les fixtures positives servent le détecteur sans remplacer le test vivant après patch. |
| E27-002 | Avec Polylang configuré, les routes simples archives/fiches/langues existent avec les bonnes cibles | Ne pas exiger la chaîne littérale `^(fr|en|ar)`. Tester les correspondances effectives FR/EN/AR, indices `$matches`, `lang`, `post_type=properties`, `pk_listing_slug` sur les fiches ; rechercher la règle effectivement prioritaire. |
| E27-003 | Sans Polylang dans un processus neuf, les cinq règles explicites préfixées et les routes non préfixées restent fonctionnelles | Vérifier `!defined('POLYLANG_VERSION')`, les cinq déclarations/cibles attendues et comparer aux preuves avant C ; tester archives, pagination valide, fiches avec/sans quartier et route ville sur fixtures. Restaurer ensuite Polylang/options/règles dans d’autres processus. |
| E27-004 | Les neuf URL SE-025 passent après flush ; identité/langue, RTL et hreflang restent conformes | Réutiliser ou appeler le contrat SE-025 en processus enfant : archiver son JSON **hors dossier agrégé** ; ses 12 résultats doivent passer. Ne pas compter de nouveau ses 12 assertions dans l’oracle C. |
| E27-005 | Code version 5, migration de l’option 4 vers 5 par `maybe_flush()`, stabilité au second appel | Captures avant/après migration sur installation locale existante, puis option/table stables ; consigner tout déclenchement admin anticipé. |
| E27-006 | Routes legacy propriété et pagination conservées, sans boucle ou mauvais contenu | Vérifier les règles effectives avec préfixage variable et les anciennes URL par HTTP ; une redirection canonique documentée vers une cible finale correcte est acceptable, pas une exigence arbitraire de 200 direct legacy. |

**Couverture complémentaire nécessaire :** les neuf URL SE-025 couvrent accueil/archive/fiche, pas toute la pagination ni toute la géographie. Créer suffisamment de fixtures pour une page 2 valide, une fiche avec quartier, une sans quartier et une ville réelle du jeu de test ; vérifier langue, bonne annonce, bonne cible, absence de boucle et statut attendu. Ne pas inventer un défaut nouveau en exigeant une page 2 sur une archive trop courte. Tout problème déjà présent avant C (ex. collision d’une règle taxonomie/ville) se rapporte séparément ; ne pas modifier la regex hors périmètre pour le cacher. Un problème empêchant la recette bloque la validation concernée jusqu’à arbitrage explicite.

Un scénario obligatoire non exécuté entraîne **FAIL/incomplet**, jamais une assertion artificiellement PASS. « Non testé » reste une information honnête, mais ne satisfait pas les six assertions ni la clôture du lot C.

### 6.3 Critères d’acceptation SE-027

- [ ] Défaut avant C réellement détecté, avec cinq règles identifiées dans la configuration de référence.
- [ ] Dumps complets regex→cibles, versions/options/langues conservés avant édition, avant migration, après migration et après chaque flush.
- [ ] Version 5 et migration effective ; aucun flush permanent ajouté.
- [ ] Zéro double après chacun des trois flush ; mêmes règles/cibles/ordre.
- [ ] Six assertions C vertes, y compris processus séparés sans Polylang et restauration finale.
- [ ] Neuf URL SE-025 : 200 direct et contenu/langue attendus ; pagination/géographie et legacy contrôlés en complément.
- [ ] Aucun correctif hors `class-listing-urls.php`, nouveau contrat, harnais strictement nécessaire et hunks de workflow associés.
- [ ] Lint PHP et non-régression globale dans les contextes corrects.

### 6.4 Intégration CI séquentielle et comptage sans ambiguïté

**Ordre canonique A → B → C.** Avant C, le workflow de l’état A+B attend déjà **376/376, 39 suites**. C ajoute exactement une suite/six assertions : **382/382, 40 suites**. Modifier une seule fois chaque nombre, intitulé et commentaire concerné, sans calcul « base 376 + B + C » qui recompterait B.

Exiger à la fois : 40 rapports de suites finales, 382 assertions, 382 PASS, zéro échec, JSON valides et compteurs cohérents. Les noms attendus des suites viennent du workflow ; vérifier qu’aucune suite n’a disparu ni été remplacée par un doublon. Une sortie enfant SE-025 n’est pas une 41e suite.

B et C sont placés après SE-025 et avant l’oracle ; C restaure l’état trilingue même en cas d’échec dans le harnais (nettoyage `finally` ou équivalent). Un serveur supplémentaire éventuel doit garder l’origine du site cohérente ou être configuré explicitement avec un WordPress séparé. Ne pas copier des ports CI au hasard.

Les patches finaux B/C doivent être rejoués dans cette chaîne ; une variante « C seul sur la référence = 376 » n’est **pas** livrée implicitement. Si elle est demandée ultérieurement, produire une variante nommée et testée distincte.

---

## 7. POINT R1 — reproduction documentée, SANS correctif ( appartient aux lots futurs )

**Nature :** livrable de reproduction uniquement. Le correctif de R1 appartient au lot SE-044 (DP-9, phase 2) et à l'exigence E-4807 (SE-048-R, phase 4). **Aucune édition de `ListingRepository.php` en Phase 1.**

### 7.1 ANCRE — code actuel (repère sur 4b41bd6, à relire avant édition)

Fichier : `plugin/partikulier-core/src/ListingRepository.php`.

La garde individuelle `postIsAlive()` (l.46-62) exclut bien un état métier — **mais un seul** :
```php
                if ( $post->post_status !== 'publish' || get_post_meta($postId, '_pk_status', true) === 'refuse' ) {
                        return false;
                }
```
(l.57 : seul `_pk_status === 'refuse'` est écarté.)

En revanche, la requête SQL de la recherche publique (méthode `search()`, l.67-108 ; SQL construit l.93-99) filtre sur :
```php
                $sql  = 'SELECT l.id, ... '
                        . ' FROM ' . $wpdb->prefix . 'pk_listings l'
                        . " WHERE l.status = 'published' AND l.locale = %s"
                        . " AND (l.external_id NOT LIKE 'estatik:%'"
                        . ' OR EXISTS (SELECT 1 FROM ' . $wpdb->posts . " p WHERE p.post_type = 'properties' AND p.post_status = 'publish' AND CONCAT('estatik:', p.ID) = l.external_id))"
```
(l.95 : `WHERE l.status = 'published'` ; la sous-requête INTEG-1 ne teste que `post_status = 'publish'`, **jamais `_pk_status`**.)

### 7.2 Reproduction avec des états métier EXISTANTS, pas `desactive` inventé

Données fictives uniquement. Créer une annonce publiée appartenant à un administrateur/propriétaire de recette ; conserver son ID, sa langue, son URL et sa ligne de projection. Le `post_status=publish` doit rester inchangé pour les états fermés examinés : c’est justement ce qui permet de conserver la fiche publique.

| Étape | Action réelle de la référence | `_pk_status` attendu | Projection observée en revue | Lecture REST observée |
|---|---|---|---|---|
| 1 | Création publiée puis synchronisation | actif | published | Présente, normal |
| 2 | `Partikulier_Dashboard::manage_listing($id, 'mark_sold', $user_id)` | vendu | published | **Encore présente**, défaut |
| 3 | Même API, action `mark_rented` | loue | published | **Encore présente**, défaut |
| 4 | Même API, action `archive` | archive | published | **Encore présente**, défaut |

Appeler la vidange du synchroniseur réel après chaque transition, puis interroger la collection par **HTTP dans une requête distincte**, même langue et pagination contenant la fixture. Comparer l’ID externe `estatik:<ID>` exact dans les objets JSON, pas une simple sous-chaîne pouvant aussi désigner un autre ID. Archiver réponses et statuts ; ne pas « prouver l’absence » par une mauvaise langue ou une page de résultats différente.

Observer aussi la fiche publique : elle peut rester indexable et dans le sitemap selon le futur DP-9 tout en devant sortir de la collection des biens disponibles. **Disponibilité ≠ existence publique de la fiche.** Aucun correctif de ce filtrage pendant Phase 1.

### 7.3 Cas refusé : distinguer état périmé et parcours normal

Le filet individuel refuse `_pk_status=refuse`. Pour reproduire l’asymétrie de la liste, sur la seule fixture :
1. Changer directement la métadonnée en `refuse`, sans enregistrement de post déclenchant sa reprojection ; relever la projection réellement obtenue, ne pas supposer qu’elle est à jour.
2. Si elle reste `published`, constater la collection HTTP et `ListingRepository::find()` : dans la revue, la collection contient encore la ligne et `find()` renvoie `listing_not_found`.
3. Effectuer ensuite l’enregistrement du post et la synchronisation ; dans la revue, projection `rejected`, ligne absente de la collection et lecture individuelle toujours refusée.

La première situation démontre une garde de collection insuffisante **en cas de projection périmée**. Elle ne démontre pas que le parcours normal de modération expose systématiquement les annonces refusées. Ne pas confondre ces affirmations.

### 7.4 Livrable R1 et nettoyage des fixtures

Livrer commandes, code de fixture, utilisateur de recette sans secret, états/projections successifs, réponses REST avant/après, résultats individuels, comportement HTTP des fiches et ancres SQL. Réserver tout identifiant unique à la campagne, nettoyer uniquement les fixtures ainsi identifiées ou supprimer le laboratoire entier après conservation des preuves.

**Conclusion attendue :** défaut de disponibilité confirmé avec vendu/loué/archive existants ; correctif à traiter dans **SE-044/E-4807**, avec cohérence recherche, listes, REST, alertes et premium. Le statut `desactive` et la table future DP-9 seront définis dans le lot produit, pas inventés pour rendre cette reproduction positive.

---

## 8. Cadre des lots ULTÉRIEURS — décisions conservées et propositions distinguées

Ces sections ne déclenchent **aucune** édition en Phase 1. Elles conservent les décisions explicites recensées au §0.2 et formulent les recommandations de conception/recette pour les lots futurs. Elles ne constituent pas une citation du commanditaire ni une approbation implicite d’un nouveau détail produit.

### 8.1 Précision n°1 — grille SE-042 : le conteneur 1 180 px fait partie du problème

**ANCRAGE (repère à relire sur 4b41bd6, `theme/partikulier/assets/css/style.css`) :**
- l.75 : `--pk-container: 1180px;` — plafond de largeur du conteneur global ;
- l.365-366 : `.pk-archive-layout { display: grid; grid-template-columns: 260px 1fr; gap: 2rem; align-items: start; }` — barre latérale 260 px + gouttière 2 rem ;
- l.994-995 : `.pk-grid { display: grid; gap: 1.25rem; } .pk-grid.pk-grid-cards { grid-template-columns: repeat(3, minmax(0, 1fr)); }` — **règle inconditionnelle** (spécificité 0,2,0) qui écrase les paliers ;
- la v1 rapporte un inventaire **14 règles `.pk-grid-cards` dans au moins 6 blocs concurrents** provenant d’un plan non joint ; inventaire à refaire au futur lot avant édition : l.335 (double déclaration contradictoire `repeat(4,1fr)` puis `repeat(3,1fr)` dans le même bloc), l.559-599 (paliers 1180/900/560), l.846-857 (doublons 900/640), l.994-995 (inconditionnelle), l.2343-2371 (paliers 1024/767), l.2699-2816 (contexte archive) — pièce annoncée mais non reçue ici : `preuves-train3-002/verifications-code-grille-premium.txt`.

**Cadre de proposition et de recette du futur diff SE-042 :**
1. Traiter la **contrainte du conteneur**, pas seulement le seuil de 3 colonnes : avec un conteneur plafonné à 1 180 px, passer le seuil de 1 200 à 1 400 px ne donne **aucun** pixel de plus aux cartes — c’est une contrainte technique documentée par la revue, à traiter dans la proposition visuelle.
2. Proposer une solution **ciblée sur la page d'annonces** (éventuel élargissement conditionnel du conteneur pour la seule zone de grille au-delà d'un point de rupture, réorganisation des filtres, ou maintien en 2 colonnes quand la place est insuffisante pour des cartes ≥ 300 px) — **sans élargir tout le site par défaut**.
3. Unifier la cascade existante (suppression/reciblage de la règle inconditionnelle l.994-995 et des doublons) au lieu d'empiler un palier de plus ; pas de `!important` en cascade.
4. Justifier par **mesures et captures** sur navigateur réel (le calcul de la v1 était faux : `(1180 − 260 − 32) / 3 = 296 px`. En retirant aussi deux gouttières internes de 20 px (si 1 rem = 16 px), `(1180 − 260 − 32 − 40) / 3 ≈ 282,7 px`, avant d’autres marges/bordures éventuelles. C’est un diagnostic structurel, **pas une mesure navigateur** : largeur utile et style calculé réels font foi).
5. Soumettre le choix (a) élargissement conditionnel ciblé / (b) réorganisation filtres / (c) 2 colonnes sous plancher 300 px avec preuve de lisibilité — au commanditaire, dans le diff et le rapport de recette. Base de recette approuvée : 1 col < 600 px, 2 cols 600-1 199 px, 3 cols ≥ 1 200 px « sous réserve de lisibilité avec la barre latérale » ; frontières 599/600/1199/1200 et contrôle d’un grand desktop, dans les trois moteurs Chromium/Firefox/WebKit × FR/EN/AR ; fournir captures et mesures, pas seulement une déclaration CSS.

### 8.2 Précision n°2 — chiffrement SE-028 : migration retirée, tests INTÉGRALEMENT conservés

**ANCRAGE (repère sur 4b41bd6, à relire avant édition) :**
- `plugin/partikulier-core/src/Domain/Leads/LeadsPrivacyTrait.php:170-179` — chiffrement actuel AES-256-**CBC sans MAC** :
```php
        private static function encrypt_phone( string $phone ): string
        {
                if ( ! function_exists('openssl_encrypt') ) { return ''; }
                $key        = hash('sha256', wp_salt('secure_auth'), true);
                $iv         = random_bytes(16);
                $ciphertext = openssl_encrypt($phone, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
                return base64_encode($iv . $ciphertext);
        }
```
- `theme/partikulier/inc/class-form.php:432` — `_pk_owner_phone` stocké en clair (cartographie DP-2).

**Cadre de recette du futur lot SE-028 :**
1. **Retiré du périmètre :** E-2803 (outillage de migration par lots CBC → GCM) et la répétition de migration « ≥ 100 lignes » — zéro donnée réelle à convertir (écart CDC n°3 déjà consigné). E-2805 réduit à une capacité de lecture.
2. **Maintenus intégralement :** E-2801 (écritures AES-256-GCM), E-2802 (lecture versionnée GCM et, si maintenue pour compatibilité, lecture CBC strictement identifiée comme legacy), E-2804 (contrat round-trip + rejet d'altération), et **le seed fictif GCM ≥ 100 lignes** qui sert DÉSORMAIS le contrat E-2804 — plus aucune migration.
3. **Trois familles de tests de recette à conserver :**
   - un numéro chiffré peut être **relu par une personne autorisée** (round-trip complet, y compris les parcours de contact : affichage masqué, appel/WhatsApp) ;
   - une **donnée GCM altérée est refusée** (modifier chiffré, nonce, tag ou données associées → échec authentifié, pas de restitution). Ne pas promettre cette garantie pour une valeur legacy CBC sans MAC ;
   - les **parcours de contact fonctionnent** de bout en bout (lead, propriétaire, restitution).
4. **Pas de downgrade silencieux :** l’enveloppe porte une version/identification de format non ambiguë. Une donnée déclarée GCM dont l’authentification échoue est refusée ; elle ne passe JAMAIS ensuite dans le lecteur CBC. Format inconnu, tronqué ou incohérent : échec explicite. Le lecteur legacy, si retenu, traite seulement des entrées identifiées legacy et ses limites sont documentées. Avec zéro stock réel, l’utilité de cette compatibilité peut être arbitrée sans recréer un chantier de migration.
5. La cartographie DP-2 reste nécessaire : le numéro lead chiffré et `_pk_owner_phone` en clair sont des données distinctes. Ne pas annoncer que le passage CBC→GCM sécurise automatiquement le champ propriétaire, les exports et les logs.
6. Toute suppression de test existant devra être justifiée ligne par ligne dans le diff : « ce test servait uniquement la migration abandonnée » est un motif recevable ; « ce test gêne » ne l'est pas.

### 8.3 Premium SE-048-R : fonctions complètes offertes, durée recommandée, plafond ouvert

**ANCRAGE (repère sur 4b41bd6, à relire avant édition) :**
- `plugin/partikulier-core/src/Domain/Premium/PremiumService.php` — `is_public_enabled()` l.43 (drapeau `pk_premium_public_enabled`, défaut `'0'`) ; `grant()` l.58 ; permission `user_can($granted_by,'manage_options')` l.69 ; expiration paresseuse `is_active()`/`expire()` l.126-144 ; événements d'audit `premium_granted`/`premium_expired`/`premium_revoked` l.111/143/159 ;
- `theme/partikulier/inc/class-premium.php` — menu admin l.41-54 (`admin.php?page=pk-premium`) ; `require_admin()` l.105 ; **bandeau l.187** : « Octroi manuel : l'administration attribue le statut premium **après réception du règlement par virement bancaire ou transfert d'argent**. Le paiement en ligne n'est pas activé… » ; formulaire l.190-196 (`property_id`, `starts_at`, `ends_at`, `selection_reason` — tous requis) ; bouton « Retirer » avec motif l.204 ;
- tests existants : `plugin/partikulier-core/tests/premium-contract.php` et `se048-premium-honesty-contract.php`.

**Cadre du futur lot SE-048-R — estimation ~2 j non validée :**
1. **Durée par attribution recommandée (option A)** : début/fin choisis par l’admin, modèle déjà codé. Maintenir ce comportement tant qu’aucun changement n’est demandé ; ne pas attribuer au commanditaire un accord distinct non documenté. La validation détaillée du lot premium confirmera le choix. Aucune durée fixe ni suppression d’échéance décidée par l’agent.
2. **Aucun paiement** : aucune passerelle, aucun checkout, aucun libellé « payé/abonnement ». Le bandeau l.187 est **remplacé** (E-4806) : il décrit un modèle de règlement hors ligne qui n'est PAS le modèle du lancement ; le remplacement dira l'octroi gratuit par l'administration (« Premium offert par Partikulier »), dans les trois langues, libellés exacts soumis au diff.
3. **Plafond : proposition à acter, PAS codé.** La valeur 10 a été suggérée par l’autre agent, pas approuvée. Présenter son intérêt et ses inconvénients face à l’absence de quota automatique au lancement, puis attendre l’arbitrage. Ne pas coder de plafond avant accord et ne pas bloquer A/B/C sur ce sujet hors Phase 1.
4. **Trois axes de recette à imposer au futur lot, sans les présenter comme des citations du commanditaire :**
   - **expiration + cache (E-4809)** : un premium expiré doit **réellement disparaître des pages servies en cache** — purge des caches de listes à chaque transition grant/revoke, bornage documenté de l’effet de l’expiration paresseuse, caches WordPress et CDN compris ; proposer un délai maximal chiffré puis le faire approuver. Ne pas déclarer « disparaît réellement à expiration » tout en choisissant silencieusement une tolérance TTL non décidée ;
   - **annonce désactivée (E-4807, invariants 1 à 5)** : une annonce désactivée ne réapparaît JAMAIS dans les biens disponibles grâce à son premium (raccord R1 §7) ; le tri premium-first ne s'applique qu'aux biens disponibles ; pas de badge sur une fiche désactivée ; expiration/retrait du premium ne désactive jamais l'annonce ; réactivation ne prolonge pas le premium ;
   - **inventaire exhaustif** : les **12 fonctions** énumérées ici pour rendre le périmètre lisible même sans le plan joint (attribution, permission, retrait, expiration, audit, écran admin, drapeau public, badge fiche, badge cartes, tri premium-first, champ REST lite, fondation paiements confinée) sont **toutes vérifiées par des tests** — pas seulement le badge. Les fonctions « à livrer » (E-4804 : badges, tri, champ REST) et la propagation aux variantes i18n (E-4808, premium par `property_id` vs 3 posts Polylang liés) font partie du lot.
5. Le drapeau `pk_premium_public_enabled` reste à `'0'` jusqu'à recette complète ; son passage à `'1'` est une action d'exploitation documentée, jamais un changement de code.

### 8.4 DP-4, remise des pièces, conservation et estimations

1. **DP-4 ouvert.** Critère : IP réelle restaurée et non usurpable → conserver/documenter ; IP de proxy commune → correction hébergeur en priorité, sinon conception d’un résolveur de confiance commun ; chaîne inconnue/usurpable → ne pas valider le quota par visiteur. Le message de suivi doit être joint avant transmission par le commanditaire. Aucune sonde publique, `phpinfo` ou endpoint anonyme.
2. **Bordereau sincère.** Le contenu intégral des fichiers cités n’est pas remplacé par son SHA-256. Voir le statut de chaque pièce en tête de ce CDC ; ne déclarer remis que ce qui l’est.
3. **Sauvegarde testée avant nettoyage.** Chemin hors runtime, manifeste vérifié, archive lisible, export accessible, puis suppression du runtime. La persistance de `download/` n’est jamais supposée. La conservation côté commanditaire est recommandée et proposée, pas annoncée comme accomplie à sa place.
4. **Estimations non approuvées.** Les fourchettes 16–19,5 j et 15–25 j restent à justifier. Le paiement fera l’objet d’un cahier séparé lorsqu’il sera ouvert ; cette v2 ne prétend pas valider des critères détaillés d’un plan absent.

---

## 9. Format des livrables de Phase 1

### 9.1 Inventaire, dépendances et génération des trois diffs sans commit

| Livrable | Nom | Contenu / dépendance |
|---|---|---|
| Diff A | `PHASE1-LOT-A-SE032.diff` | Référence → A ; garde, deux en-têtes, documentation proxy |
| Diff B | `PHASE1-LOT-B-SE041.diff` | **A → A+B** ; filtre XML-RPC, contrat six assertions, workflow 376/39, documentation exploitation |
| Diff C | `PHASE1-LOT-C-SE027.diff` | **A+B → A+B+C** ; règles/version, contrat six assertions, workflow 382/40, harnais minimal nécessaire |
| Rapport | `RAPPORT-PHASE1-TRAIN3.md` | Chapitres A/B/C + R1 + écarts + limites + décision |
| Preuves brutes | `preuves-phase1/RA-1/`, `RB-1/`, `RC-1/`, `R1/` | Commandes, statuts, sorties, dumps complets et contrôles positifs |
| Contrats finaux | `preuves-phase1/contrats/*.json` | Rapports de suites enregistrées uniquement |
| Détails | `preuves-phase1/details/` | Sorties enfants, fixtures, config expurgée, smoke navigateur, stdout/stderr auxiliaires |
| Intégration | `ORDRE-APPLICATION.md` | A puis B puis C, base et SHA des diffs, vérification d’application et oracle final |
| Empreintes / archive | `SHA256SUMS.txt`, `.sha256`, archive exportable | Tous les livrables et vérification d’intégrité |

**Séparation des diffs sans commit.** Dans un clone dédié propre, l’index Git local peut représenter l’état précédent :

```bash
# Début : index et working tree identiques au commit de référence, prévol §2.1 passé.
# Appliquer le travail A, puis :
git diff --check
git diff --binary > "$PROOFS/PHASE1-LOT-A-SE032.diff"
# Relire A, puis placer EXPLICITEMENT seulement ses fichiers dans l’index local :
git add -- theme/partikulier/pk-diagnostic.php theme/partikulier/style.css \
  theme/partikulier/readme.txt docs/INSTALLATION.md
# Aucun commit. L’index représente maintenant A.

# Appliquer B, dont le nouveau test doit apparaître dans le diff :
git add -N -- theme/partikulier/tests/se041-xmlrpc-contract.php
git diff --check
git diff --binary > "$PROOFS/PHASE1-LOT-B-SE041.diff"
git add -- theme/partikulier/inc/class-security.php docs/INSTALLATION.md \
  theme/partikulier/tests/se041-xmlrpc-contract.php .github/workflows/contrats-recette.yml
# Aucun commit. L’index représente A+B.

# Appliquer C ; inclure par intent-to-add tout nouveau fichier autorisé :
git add -N -- theme/partikulier/tests/se027-rewrite-prefix-contract.php
git diff --check
git diff --binary > "$PROOFS/PHASE1-LOT-C-SE027.diff"
```

Les commentaires « appliquer le travail » sont des étapes d’édition contrôlée, pas du code automatisant les correctifs. Si un helper supplémentaire de test est réellement nécessaire, l’identifier dans le rapport et l’ajouter explicitement à `git add -N` ; aucun `git add -A` aveugle. Garder les preuves hors clone pour ne pas les embarquer. Contrôler fichiers non suivis et `git diff --name-status` à chaque étape ; les fichiers ajoutés ne doivent pas manquer au patch.

**Deuxième clone propre pour vérifier la chaîne :**

```bash
cd "$CLONE_VERIFICATION"
test "$(git rev-parse HEAD)" = 4b41bd65f2414ea9ce0fd847f144c46fccbab521
test -z "$(git status --porcelain)"
for lot in A-SE032 B-SE041 C-SE027; do
  git apply --check "$PROOFS/PHASE1-LOT-$lot.diff"
  git apply "$PROOFS/PHASE1-LOT-$lot.diff"
done
git diff --check
```

Archiver les sorties et codes de fin. Comparer le résultat obtenu au working tree final ayant passé les tests (contenu des fichiers modifiés et ajoutés). Pas de `--reject`, pas d’application partielle ou de correction manuelle non reflétée dans les patches. Cette opération reste locale et sans commit ; elle n’autorise pas une fusion distante.

### 9.2 Structure du rapport de livraison

1. **En-tête** : date réelle, base SHA complète, CDC v2 + SHA, environnement exact, versions, arbre propre au départ et distinctions avec la CI.
2. **Par lot A/B/C** : reproduction brute avant ; patch et correspondance hunks↔E-xxxx ; assertions après ; tests négatifs ; écarts ; périmètre non testé ; verdict du lot.
3. **R1** : états existants, synchronisation, HTTP REST, cas de projection refusée périmée puis actualisée, distinction fiche publique/disponibilité. Aucune modification repository.
4. **Non-régression** : au minimum `premium-contract`, `se048-premium-honesty-contract`, `se025-trilingual-routes-contract`, **`rest-lite-scope`**, plus les suites touchées ; SE-043 dans son contexte et contrôles géographiques C. Le test `rest-lite-scope` et le parcours signé valide n’ont pas été entièrement couverts dans la revue préalable : ils restent à exécuter, pas à déclarer acquis.
5. **CI complète** : nombre de suites, assertions, tous JSON valides, versions et sortie de l’oracle. Si seulement une sélection a été exécutée, annoncer « partiel », jamais 382/382. Une CI différente de PHP8.3/MySQL8 n’est pas implicitement équivalente.
6. **Intégration** : ordre A→B→C, hashes, vérifications `git apply --check`, résultat identique au code testé, aucune mise en production.
7. **DP-4/exploitation** : ouvert/non validé sur Hostinger, aucune action sur le domaine client.
8. **Arbitrages** : tout écart nouveau réellement bloquant ; variante 403 serveur seulement proposée ; durée/plafond premium hors Phase 1, sans fausse validation.
9. **Conservation/nettoyage** : manifeste vérifié, archive testée, export rendu accessible, runtime/base/identifiants/caches/sources/browsers supprimés, port fermé. Les fichiers utilisateurs et le kit durable sont conservés.

### 9.3 Usage des livrables par le commanditaire

Revue des diffs, du rapport et des preuves → validation explicite par lot → éventuelle autorisation d’application **distincte**. Cette v2 et le kit de sondes ne livrent pas encore les vrais patches A/B/C, les deux nouveaux contrats PHP CI ni un logiciel recetté. L’exécutant ne peut pas annoncer « Phase 1 terminée » au seul motif que le document existe.

---

## 10. Definition of Done — Phase 1

La clôture nécessite **tous** les points applicables, sans transformer « non testé » en PASS.

### Général
- [ ] Base/tag/archives vérifiés ; config/version du laboratoire et écarts CI enregistrés.
- [ ] Aucun commit/push/tag/Release/déploiement ou requête de recette vers le domaine client ; téléchargements officiels de préparation tracés.
- [ ] Avant/après vivants sur le code effectivement livré ; contrôle positif des détecteurs.
- [ ] Diff A sur référence, B sur A, C sur A+B ; chaîne entière appliquée proprement dans un second clone.
- [ ] JSON finaux stricts, stdout sans texte parasite, suites attendues présentes, compteurs et statuts cohérents.
- [ ] Recette complète **382/382, 40 suites** démontrée dans l’environnement CI de référence ; sinon statut global partiel/non clos explicitement indiqué.
- [ ] Livrables exportés hors runtime, empreintes vérifiées, copie accessible avant nettoyage ; pas de déclaration de téléchargement du commanditaire sans preuve.

### Lot A — SE-032
- [ ] RA-1 : 200 vide avant → 404 vide après, même accès direct et routeur.
- [ ] Accueil/admin/CLI conservés ; anonyme sans diagnostic ; jetons absents/invalides refusés ; **parcours signé valide réellement rejoué avant/après**.
- [ ] PHP8.1 dans les deux en-têtes ; versions et historique inchangés ; lint OK.
- [ ] Doc E-3202 complète, trois limiteurs et quatre ancres, DP-4 ouvert, pas de confiance dans un en-tête arbitraire.

### Lot B — SE-041
- [ ] RB-1 avant détecte réellement les méthodes applicatives ; pas de grep sur la mauvaise balise.
- [ ] Après : liste exacte des trois `system.*`, HTTP et XML valides ; demo/pingback faults -32601.
- [ ] Filtre ajouté et `xmlrpc_enabled` conservé ; nouveau contrat six assertions avec démo négative, lint OK.
- [ ] Workflow intermédiaire 376/376, 39 suites ; doc E-4102 sans affirmation Hostinger non testée.

### Lot C — SE-027
- [ ] Les cinq doubles du cas de référence sont détectés avant patch indépendamment de l’ordre des langues.
- [ ] Dumps complets avec cibles/ordre/langues/versions avant et après, pas seulement des compteurs.
- [ ] Migration explicitement déclenchée : option 4→5 ; idempotence vérifiée ; pas de flush récurrent.
- [ ] Trois flush : zéro double à chaque fois, tables stables.
- [ ] Six assertions C vertes, dont branche sans Polylang en processus neufs et restauration finale.
- [ ] Neuf URL trilingues, contenu/langue/RTL/hreflang conformes ; pagination, géographie et legacy contrôlés.
- [ ] Workflow final 382/382, 40 suites ; aucune sortie enfant comptée en double.

### R1, rapport et fin de session
- [ ] États vendu/loué/archive reproduits via actions existantes ; métadonnée future non inventée ; sorties REST et projection conservées.
- [ ] Cas refusé périmé vs reprojeté expliqué ; aucune édition de `ListingRepository.php`.
- [ ] `rest-lite-scope` et autres suites minimales réellement exécutés, résultats et limites complets.
- [ ] Table des écarts honnête, statut DP-4 ouvert, pas d’estimation présentée comme engagement.
- [ ] Environnement jetable arrêté et entièrement supprimé ; preuves, scripts utiles et documents conservés.

**Si un critère obligatoire reste non testé, rouge ou empêché par un défaut préexistant, ne pas clore la Phase 1.** Livrer le travail partiel et la cause, puis demander un arbitrage limité au point concerné. Cela n’autorise pas à étendre le code hors périmètre.

---

## Annexe A — repères de code sur `4b41bd6`, à relire avant édition

| Ancre | Contenu | Exigence |
|---|---|---|
| `theme/partikulier/pk-diagnostic.php:72-74` | garde `ABSPATH` → `exit;` (200 vide en accès direct) | E-3201 |
| `theme/partikulier/functions.php:272` | chargement de `pk-diagnostic.php` par le thème | E-3201 (accès légitime) |
| `theme/partikulier/pk-diagnostic.php:2254` (garde 403 l.2258-2268, jeton l.2269-2278) | `boot_url_entry()` : garde interne non-admin + nonce ; en anonyme le module n’est pas chargé, donc ne pas promettre 403 | E-3201 (accès légitime) |
| `theme/partikulier/style.css:9` / `readme.txt:7` | `Requires PHP: 8.0` | E-3203 |
| `plugin/partikulier-core/partikulier-core.php:6` | `Requires PHP: 8.1` (déjà aligné) | E-3203 |
| `.github/workflows/ci.yml:15,62` | matrice `['8.1','8.2','8.3']` (déjà alignée) | E-3203 |
| `plugin/.../src/RateLimiter.php:19,64-69` | identité quota + `clientIp()` sur `REMOTE_ADDR` | E-3202 |
| `plugin/.../src/Domain/Leads/LeadsEraseGuardTrait.php:223` | `REMOTE_ADDR` | E-3202 |
| `theme/partikulier/inc/class-security.php:84` | `REMOTE_ADDR` (limiteur dépôt) | E-3202 |
| `theme/partikulier/inc/class-security.php:16-21` (filtre l.20) | `xmlrpc_enabled → false` seul | E-4101 |
| cœur WP `class-wp-xmlrpc-server.php:189-223` + `login()` | `xmlrpc_enabled` ne couvre que le login | E-4101 (preuve de lacune) |
| cœur WP `class-IXR-server.php:183-188` | 3 méthodes `system.*` ajoutées après filtre | E-4101 (contrat de test) |
| `theme/partikulier/tests/staging-securite.php:179-182` | sonde xmlrpc.php existante | E-4101 (non-régression) |
| `theme/partikulier/inc/class-exec-whitelist.php:93,149` | `partikulier_exec_whitelist` / `PARTIKULIER_EXEC_REQUIRE_PIN` | E-4102 |
| `theme/partikulier/inc/class-avif.php:347` | `PARTIKULIER_ENABLE_AVIF_DELIVERY` | E-4102 |
| `theme/partikulier/inc/class-listing-urls.php:33` | `RULES_VERSION = '4'` | E-2702 |
| `theme/partikulier/inc/class-listing-urls.php:39,60` | hooks `init:20` (add_rules) / `admin_init` (maybe_flush) | E-2702 |
| `theme/partikulier/inc/class-listing-urls.php:442-487` | `add_rules()` : 5 règles préfixées + 5 sans préfixe + 2 legacy | E-2701/E-2702/E-2703 |
| `.github/workflows/contrats-recette.yml:71,82-98,349` | étape de 32 suites, total global 38 / oracle 370/370 | tests (lots B/C) |
| `plugin/.../src/ListingRepository.php:46-62 (l.57)` / `:75-108 (SQL l.93-99)` | `_pk_status` absent de la recherche publique (seul `refuse` l.57) | R1 |
| `theme/partikulier/assets/css/style.css:75,365-366,994-995` (+ blocs 335/559-599/846-857/2343-2371/2699-2816) | conteneur 1 180 px, sidebar 260 px, règle inconditionnelle 3 colonnes | §8.1 (SE-042 futur) |
| `plugin/.../LeadsPrivacyTrait.php:170-179` / `class-form.php:432` | CBC sans MAC / `_pk_owner_phone` clair | §8.2 (SE-028 futur) |
| `plugin/.../PremiumService.php:43,58,69,126-144,111/143/159` + `class-premium.php:41-54,105,187,190-196,204` | service premium + écran admin + bandeau « virement » | §8.3 (SE-048-R futur) |

**Fin du corps principal de la v2 — proposition documentaire du 19 septembre 2026. Les annexes suivantes font partie de la livraison. Aucun accord de publication ni résultat de CI complète n’est implicite.**


## Annexe B — sondes de recette fournies, code intégral

Ces fichiers vivent **hors du répertoire public WordPress** et ne sont pas intégrés aux ZIP produit. Ils ne modifient ni le thème ni la base. La branche WordPress du premier script exige WP-CLI et `WP_ENVIRONMENT_TYPE=local` ; sa branche hors ligne relit un dump JSON. Le second analyse un XML déjà capturé et ne réalise aucun appel réseau.

**Attention au sens des codes de sortie :** `rewrite-audit.php` réussit s’il collecte/analyse un dump valide, même s’il détecte des doubles. Il faut donc contrôler son champ `double_count` dans le contrat. `xmlrpc-audit.py` réussit seulement si la réponse satisfait l’attendu choisi ; un échec attendu lors d’un contrôle négatif confirme que le détecteur fonctionne, pas que le logiciel est corrigé.

### B.1 `outils/rewrite-audit.php`

```php
<?php
/** Sonde de recette, jamais un endpoint HTTP. stdout = un objet JSON. */
declare(strict_types=1);
function v2_language_group(string $group, array $languages): bool {
    $parts = explode('|', $group);
    return $parts !== [] && count(array_unique($parts)) === count($parts)
        && array_diff($parts, $languages) === [];
}
function v2_double_rules(array $rules, array $languages): array {
    $found = [];
    foreach ($rules as $regex => $target) {
        if (preg_match('~^\^?\((?:\?:)?([^()]+)\)/\((?:\?:)?([^()]+)\)/~', (string) $regex, $m)
            && v2_language_group($m[1], $languages)
            && v2_language_group($m[2], $languages)) {
            $found[$regex] = $target;
        }
    }
    return $found;
}
try {
    if (defined('ABSPATH')) {
        if (!defined('WP_CLI') || !WP_CLI || wp_get_environment_type() !== 'local') {
            throw new RuntimeException('Réservé à WP-CLI sur un laboratoire déclaré local.');
        }
        // Lire la table stockée, sans déclencher une régénération implicite.
        $rules = get_option('rewrite_rules', null);
        $languages = function_exists('pll_languages_list')
            ? pll_languages_list(['fields' => 'slug']) : ['fr', 'en', 'ar'];
        $meta = [
            'source' => 'WordPress local vivant', 'wp' => get_bloginfo('version'),
            'php' => PHP_VERSION,
            'polylang' => defined('POLYLANG_VERSION') ? POLYLANG_VERSION : null,
            'RULES_VERSION' => Partikulier_Listing_Urls::RULES_VERSION,
            'stored_rules_version' => get_option('pk_url_rules_version'),
        ];
    } else {
        if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
        $path = $argv[1] ?? '';
        if (!is_file($path)) { throw new RuntimeException('Usage : php rewrite-audit.php dump.json [fr,en,ar]'); }
        $input = json_decode(file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        $rules = $input['all_rules'] ?? null;
        $languages = explode(',', $argv[2] ?? 'fr,en,ar');
        $meta = ['source' => 'Relecture hors ligne, PAS une nouvelle exécution WordPress', 'input' => basename($path)];
    }
    if (!is_array($rules) || $rules === [] || !is_array($languages) || $languages === []) {
        throw new RuntimeException('Règles ou langues absentes : résultat non interprétable.');
    }
    foreach ($rules as $regex => $target) {
        if (!is_string($regex) || !is_string($target)) { throw new RuntimeException('Dump regex→cible invalide.'); }
    }
    $double = v2_double_rules($rules, $languages);
    echo json_encode($meta + ['languages' => array_values($languages), 'total' => count($rules),
        'double_count' => count($double), 'double_rules' => (object) $double,
        'all_rules' => (object) $rules], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR) . "\n";
} catch (Throwable $e) {
    fwrite(STDERR, $e->getMessage() . "\n"); exit(1);
}
```

### B.2 `outils/xmlrpc-audit.py`

```python
#!/usr/bin/env python3
"""Analyse XML locale : ne réalise aucune requête. Échec si forme/résultat inattendu."""
import argparse,json,sys,xml.etree.ElementTree as ET
p=argparse.ArgumentParser()
p.add_argument('mode',choices=['avant-liste','apres-liste','apres-demo','apres-pingback'])
p.add_argument('fichier')
a=p.parse_args()
try:
    raw=open(a.fichier,'rb').read()
    if len(raw)>2_000_000 or b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():
        raise ValueError('Document trop grand ou DTD/entité interdite')
    root=ET.fromstring(raw)
    if root.tag!='methodResponse': raise ValueError('Racine XML-RPC absente')
    result={'mode':a.mode,'fichier':a.fichier}
    if a.mode.endswith('liste'):
        if root.find('fault') is not None: raise ValueError('Fault à la place de la liste')
        data=root.find('./params/param/value/array/data')
        if data is None: raise ValueError('Tableau des méthodes absent')
        methods=[]
        for value in data:
            if value.tag!='value': raise ValueError('Valeur XML inattendue')
            string=value.find('string')
            if string is None or not string.text: raise ValueError('Nom de méthode manquant')
            methods.append(string.text)
        if a.mode=='avant-liste': ok={'pingback.ping','demo.sayHello'}<=set(methods)
        else:
            expected={'system.getCapabilities','system.listMethods','system.multicall'}
            ok=len(methods)==3 and set(methods)==expected
        result.update(methodes=methods,ok=ok)
    else:
        members=root.findall('./fault/value/struct/member'); values={}
        for member in members:
            name=member.findtext('name');value=member.find('value')
            if name in values: raise ValueError('Membre de fault dupliqué')
            values[name]=''.join(value.itertext()).strip() if value is not None else ''
        code=int(values.get('faultCode',''))
        result.update(faultCode=code,faultString=values.get('faultString',''),
                      ok=code==-32601 and b'Hello!' not in raw)
    result['status']='PASS' if result['ok'] else 'FAIL'
    print(json.dumps(result,ensure_ascii=False))
    sys.exit(0 if result['ok'] else 1)
except (OSError,ValueError,ET.ParseError) as e:
    print(str(e),file=sys.stderr);sys.exit(1)
```

### B.3 Rejouer la vérification documentaire et les sondes hors ligne

Le paquet de cette v2 contient `verification/tester-v2.py` et une sélection des **dumps/réponses bruts de la campagne WordPress précédente**, dans `verification/fixtures/`. Les empreintes de ces entrées figurent dans le résultat. Leur relecture n’est pas une nouvelle requête au site et n’est jamais datée comme une nouvelle recette du logiciel.

Depuis le dossier de la v2, avec Python 3, PHP CLI et Git installés :

```bash
php -l outils/rewrite-audit.php
python3 verification/tester-v2.py
```

Le vérificateur n’accède pas au réseau. Il vérifie les anciens dumps réels (dont les cinq doubles manqués par la v1), les réponses XML avant/après, les cas négatifs, 144 combinaisons d’ordre/ancrage/type de groupe des langues, la syntaxe des blocs shell et une chaîne de diffs A/B/C sur **fichiers synthétiques**. Aucun commit n’est créé ; les dossiers temporaires sont supprimés. Le résultat est `verification/resultats-v2.json`.

**Ce résultat ne vaut ni `382/382`, ni conformité de la branche WP-CLI sur un nouveau laboratoire, ni validation du parcours diagnostic signé ou de Hostinger.** La nouvelle exécution vivante relève de la livraison Phase 1 à produire selon ce CDC. Les empreintes de livraison devront être régénérées si l’on relance le vérificateur, puisqu’il réécrit son horodatage/résultat.

## Annexe C — journal de révision v1 → v2

| Sujet | Erreur/ambiguïté de la v1 | Correction v2 |
|---|---|---|
| Autorité du document | « applicable immédiatement », priorité sur formulations futures, accord attribué indistinctement | Proposition à valider ; aucune priorité sur une nouvelle instruction utilisateur ; décisions/recommandations distinguées |
| Pièces annoncées | Documents complets déclarés remis sans être joints | Bordereau disponible/non reçu, empreinte ≠ contenu |
| Date et résultats | Mentions 20/09 et vérification intégrale auto-attestée | Date réelle de cette révision, provenance et limites des mesures explicites |
| Détecteur de doubles | Ordre fixe `fr|en|ar`, faux zéro avant patch | Langues configurées, ordre variable, contrôle positif et fixtures négatives |
| Dumps | Total + motifs trouvés seulement | Toutes les regex/cibles dans leur ordre, options et versions |
| Migration | Édition du code assimilée à mise à jour des règles | Capture pré-migration, déclenchement `maybe_flush()`, trois flush et stabilité |
| Branches Polylang | Désactivation ambiguë dans un même processus | Processus neufs, preuve de constante absente, restauration obligatoire |
| Routes | Chaînes littérales figées et neuf URL utilisées comme couverture générale | Cibles/indices/langues effectifs, pagination/géographie/legacy complémentaires |
| XML-RPC | `<name>` recherché dans une liste de `<string>` | Analyse XML structurée, liste exacte, faults et transport vérifiés |
| Variante 403 | PHP décrit comme impossible et dépendant de l’identité IP | Possible techniquement, non retenu ici ; règle serveur proposée séparément |
| Diagnostic anonyme | 403 annoncé malgré module non chargé | Comportement de référence sans divulgation ; pas de 403 nouveau dans A |
| Diagnostic légitime | Écran admin utilisé comme substitut possible au parcours signé | Parcours signé valide explicitement obligatoire pour clore A |
| JSON | Texte ligne à ligne puis JSON sur stdout | Un objet JSON unique, résultats structurés, stderr séparé |
| Oracle/diffs | B/C annoncés indépendants malgré fichier/compteur partagés | A→B→C ; 370/38 → 376/39 → 382/40 ; vérification de chaîne sans commit |
| Contexte des suites | Risque de jouer SE-043 avec Polylang installé | Ordre/contextes CI explicités ; rouges conservés, pas masqués |
| R1 | Valeur future `desactive` utilisée pour provoquer le défaut | Actions métier `mark_sold`, `mark_rented`, `archive` et cas refusé périmé/actualisé |
| Sauvegarde | `download/` supposé persistant | Chemin hors runtime, archive testée, export effectif, SHA vérifiés |
| Grille | Calcul 272 faux et gouttières oubliées | 296 brut / ~282,7 avec gouttières sous hypothèse rem ; navigateur arbitre |
| Chiffrement | « GCM puis repli CBC » ambigu face au rejet d’altération | Format explicite ; aucun repli après échec GCM ; limites CBC exposées |
| Premium | Durée recommandée présentée comme accord distinct, plafond suggéré | Maintien du modèle existant recommandé ; plafond ouvert ; TTL à approuver |
| Exploitation | Cache/hash/AVIF/épinglage mêlés à des mesures non jointes | Contrôles séparés, constantes explicites, pas de conformité Hostinger supposée |
| Clôture | Non-testé parfois compatible avec vert | Critères obligatoires non satisfaits = lot/phase partiel, arbitrage explicite |

**Fin de la v2 intégrale.** La livraison du présent CDC est terminée ; l’exécution et la recette du futur logiciel restent à accomplir.
