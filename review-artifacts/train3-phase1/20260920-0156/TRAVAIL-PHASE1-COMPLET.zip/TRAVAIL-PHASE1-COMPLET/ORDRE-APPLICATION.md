# ORDRE D'APPLICATION — Phase 1 Train 3 (A → B → C)

**Base imposée :** `4b41bd65f2414ea9ce0fd847f144c46fccbab521` (tag `v2.10.8-6.20.7`), arbre propre.
**Pré-requis :** vérifier `git rev-parse HEAD` et que `git status --porcelain` est vide AVANT chaque application.

## Les trois diffs (ordre obligatoire)

| # | Fichier | Base d'application | Contenu | SHA-256 |
|---|---|---|---|---|
| 1 | `PHASE1-LOT-A-SE032.diff` | référence 4b41bd6 | garde 404 pk-diagnostic (E-3201), Requires PHP 8.1 ×2 (E-3203), doc limiteurs/CDN DP-4 (E-3202) | voir SHA256SUMS.txt |
| 2 | `PHASE1-LOT-B-SE041.diff` | **état A** (référence + diff 1) | filtre `xmlrpc_methods` (E-4101), contrat se041 (6 assertions), workflow 376/376·39, doc playbook production (E-4102) | idem |
| 3 | `PHASE1-LOT-C-SE027.diff` | **état A+B** | `RULES_VERSION '5'` + conditionnement Polylang des 5 règles préfixées (E-2702), contrat se027 (6 assertions), workflow 382/382·40 | idem |

Les diffs sont **séquentiels, pas indépendants** : B est produit sur l'état A et C sur l'état A+B (fichiers partagés : `docs/INSTALLATION.md`, `.github/workflows/contrats-recette.yml`). Ne jamais présenter B ou C comme applicables sur la référence seule.

## Procédure (sans commit, sans push — la publication reste à autoriser séparément)

```bash
cd <clone-à-4b41bd6>
test "$(git rev-parse HEAD)" = 4b41bd65f2414ea9ce0fd847f144c46fccbab521
test -z "$(git status --porcelain)"
for lot in A-SE032 B-SE041 C-SE027; do
  git apply --check "PHASE1-LOT-$lot.diff"   # doit passer avant chaque application
  git apply "PHASE1-LOT-$lot.diff"
done
git diff --check
php -l theme/partikulier/pk-diagnostic.php
php -l theme/partikulier/inc/class-security.php
php -l theme/partikulier/inc/class-listing-urls.php
php -l theme/partikulier/tests/se041-xmlrpc-contract.php
php -l theme/partikulier/tests/se027-rewrite-prefix-contract.php
```

Cette chaîne a été vérifiée telle quelle sur un second clone propre : application sans rejet, `git diff --check` vide, arbre final strictement identique à l'arbre ayant passé les tests (`preuves-phase1/journal/verification-chaine.txt`).

## Comptages d'oracle attendus après application

| État | Suites | Assertions | Notes |
|---|---:|---:|---|
| Référence (avant A) | 38 | 370 | base actuelle du dépôt |
| Après A seul | 38 | 370 | A n'ajoute aucune suite |
| Après A+B | 39 | 376 | + se041-xmlrpc-contract (6) |
| Après A+B+C | 40 | 382 | + se027-rewrite-prefix-contract (6) — la sortie enfant SE-025 (12) n'est JAMAIS recomptée |

Les oracles 376/39 et 382/40 ont été démontrés localement sur installations fraîches (`preuves-phase1/chaine-AB/`, `chaine-ABC/`) ; l'oracle de référence 370/38 a été rejoué avant tout patch (`preuves-phase1/reference-run/`). La CI GitHub (MySQL 8) reste à exécuter après application réelle.

## Après application — vérifications minimales vivantes (extraits du rapport)

1. `curl -o /dev/null -w '%{http_code}' <base>/wp-content/themes/partikulier/pk-diagnostic.php` → **404** (et non 200 vide).
2. `POST <base>/xmlrpc.php` `system.listMethods` → exactement les 3 `system.*` ; `demo.sayHello`/`pingback.ping` → fault `-32601`.
3. Déclencher `Partikulier_Listing_Urls::maybe_flush()` (première visite admin) : option `pk_url_rules_version` 4 → 5 ; la table passe de 303 règles/5 doubles à 298/0 ; trois flush consécutifs stables.
4. Rejouer SE-025 (9 URLs trilingues) : 12/12.

## Interdits toujours en vigueur

Aucun commit/push/tag/Release/déploiement sans autorisation explicite distincte ; aucune requête vers le domaine client ; aucune modification hors A/B/C (R1 = reproduction uniquement, correctif dans SE-044/E-4807) ; la variante 403 serveur sur xmlrpc.php est une proposition d'exploitation à part, ne pas remplacer les attendus -32601 sans accord.
