#!/usr/bin/env bash
# Phase 1 — RC-1 : migration explicite + 3 flush + stabilité (CDC §6.1.4).
# Le lab doit être à l'état A+B+C (rsync fait avant), option stockée = 4.
set -euo pipefail
BENCH=/home/z/my-project/bench
LAB="$BENCH/lab-phase1"
D="$BENCH/depot-phase1"
PHP="$BENCH/php"
WPCLI="$BENCH/wp-cli.phar"
WP() { "$PHP" "$WPCLI" --path="$LAB/htdocs" "$@"; }
P=/home/z/my-project/download/preuves-phase1
AUDIT="$LAB/tools/run-rewrite-audit.php"

echo "== 0. synchronisation thème état C (aucun accès admin ensuite avant capture) =="
rsync -a --delete --exclude='.git' --exclude='.github' "$D/theme/partikulier/" "$LAB/htdocs/wp-content/themes/partikulier/"

echo "== 1. après-code-avant-migration (attendu : code 5 / option 4 / 303 / 5 doubles) =="
cd "$LAB"
"$PHP" "$AUDIT" > "$P/RC-1/apres-code-avant-migration.json" 2> "$P/RC-1/apres-code-avant-migration.err"
python3 - "$P/RC-1/apres-code-avant-migration.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
print("  RULES_VERSION(code)=%s stored=%s total=%s doubles=%s" % (d.get('RULES_VERSION'), d.get('stored_rules_version'), d.get('total'), d.get('double_count')))
PY

echo "== 2. déclenchement explicite maybe_flush() (nouveau processus) =="
"$PHP" "$WPCLI" --path="$LAB/htdocs" eval 'Partikulier_Listing_Urls::maybe_flush(); echo "maybe_flush execute\n";' 2>&1 | tee "$P/RC-1/migration.txt"

echo "== 3. dump après migration (attendu : option 5 / 298 / 0 doubles) =="
"$PHP" "$AUDIT" > "$P/RC-1/apres-migration.json" 2> "$P/RC-1/apres-migration.err"
python3 - "$P/RC-1/apres-migration.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
print("  RULES_VERSION(code)=%s stored=%s total=%s doubles=%s" % (d.get('RULES_VERSION'), d.get('stored_rules_version'), d.get('total'), d.get('double_count')))
PY

echo "== 4. trois flush consécutifs + dumps (stabilité règles/cibles/ordre) =="
for i in 1 2 3; do
  "$PHP" "$WPCLI" --path="$LAB/htdocs" eval 'Partikulier_Listing_Urls::flush();' >> "$P/RC-1/migration.txt" 2>&1
  "$PHP" "$AUDIT" > "$P/RC-1/apres-flush-$i.json" 2> "$P/RC-1/apres-flush-$i.err"
  python3 - "$P/RC-1/apres-flush-$i.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
print("  flush: RULES_VERSION=%s stored=%s total=%s doubles=%s" % (d.get('RULES_VERSION'), d.get('stored_rules_version'), d.get('total'), d.get('double_count')))
PY
done

echo "== 5. idempotence : second maybe_flush() sur option=5 (table stable) =="
"$PHP" "$WPCLI" --path="$LAB/htdocs" eval 'Partikulier_Listing_Urls::maybe_flush(); echo "second maybe_flush execute\n";' 2>&1 | tee -a "$P/RC-1/migration.txt"
"$PHP" "$AUDIT" > "$P/RC-1/apres-idempotence.json" 2> "$P/RC-1/apres-idempotence.err"

echo "== 6. comparaison machine : stabilité stricte des 3 flush (regex + cibles + ordre) =="
python3 - "$P/RC-1" <<'PY'
import json, sys
base = sys.argv[1]
dumps = []
for name in ['apres-migration', 'apres-flush-1', 'apres-flush-2', 'apres-flush-3', 'apres-idempotence']:
    d = json.load(open(f"{base}/{name}.json"))
    dumps.append((name, d))
ref_name, ref = dumps[0]
stable = True
for name, d in dumps[1:]:
    same = list(d['all_rules'].items()) == list(ref['all_rules'].items())
    if not same:
        stable = False
        print(f"  ECART {name} vs {ref_name} !")
    else:
        print(f"  {name} : identique à {ref_name} ({d['total']} règles, ordre et cibles compris)")
print("STABILITÉ 3 FLUSH + IDEMPOTENCE :", "OK" if stable else "ÉCHEC")
import sys
sys.exit(0 if stable else 1)
PY
echo "RC-1-TERMINÉ"
