#!/usr/bin/env bash
# Point R1 — orchestrateur : transitions PHP + requêtes HTTP DISTINCTES (CDC §7).
set -euo pipefail
BENCH=/home/z/my-project/bench
PHP="$BENCH/php"
L="$BENCH/lab-phase1"
P=/home/z/my-project/download/preuves-phase1/R1
R1PHP=/home/z/my-project/scripts/phase1-r1.php
B=http://127.0.0.1:8099
mkdir -p "$P"

# Serveur persistant requis (requêtes HTTP distinctes des transitions CLI).
if ! curl -s -o /dev/null --max-time 3 "$B/fr/"; then bash /home/z/my-project/scripts/phase1-serveur.sh; fi

# Présence dans la collection : comparer l'external_id EXACT de chaque objet,
# jamais une sous-chaîne. $1=fichier-sortie $2=external_id
collection_http() {
  local out="$1" ext="$2" page=1 presente=absente
  : > "$out.raw"
  while :; do
    curl -sS --max-time 30 "$B/wp-json/partikulier/v1/listings?locale=fr&page=$page" >> "$out.raw" || break
    if python3 - "$out.raw" "$ext" <<'PY'
import json, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception:
    sys.exit(2)
items = d.get('data') if isinstance(d, dict) else d
sys.exit(0 if isinstance(items, list) and any(str(i.get('external_id', '')) == sys.argv[2] for i in items) else 1)
PY
    then presente=presente; break; fi
    # page suivante seulement si la réponse contient des items
    n=$(python3 -c "import json,sys; d=json.load(open('$out.raw')); items=d.get('data') if isinstance(d,dict) else d; print(len(items) if isinstance(items,list) else 0)" 2>/dev/null || echo 0)
    [ "$n" -gt 0 ] || break
    page=$((page+1))
    [ "$page" -le 20 ] || break
  done
  echo "$presente" > "$out"
  echo "collection HTTP : $ext → $presente (pages parcourues jusqu'à $page)" | tee -a "$P/journal-r1.txt"
}

echo "== R1 étape 0 : fixture (annonce FR publiée) ==" | tee "$P/journal-r1.txt"
INIT=$($PHP "$R1PHP" init)
echo "$INIT" | tee -a "$P/journal-r1.txt" | python3 -c "import json,sys; d=json.loads(sys.stdin.read()); print('  post', d['post_id'], '| post_status', d['post_status'], '| _pk_status', d['pk_status'], '| projection', (d['projection'] or {}).get('status'))"
PID=$(echo "$INIT" | python3 -c "import json,sys; print(json.loads(sys.stdin.read())['post_id'])")
EXT="estatik:$PID"
URLF=$(echo "$INIT" | python3 -c "import json,sys; print(json.loads(sys.stdin.read())['url_fiche'])")
echo "  external_id=$EXT url_fiche=$URLF"

echo "== état initial : collection HTTP ==" | tee -a "$P/journal-r1.txt"
collection_http "$P/01-init-presente.txt" "$EXT"

for TRANS in mark_sold mark_rented archive; do
  echo "== R1 transition réelle : $TRANS ==" | tee -a "$P/journal-r1.txt"
  $PHP "$R1PHP" "$TRANS" "$PID" | tee -a "$P/journal-r1.txt" | python3 -c "import json,sys; d=json.loads(sys.stdin.read()); print('  post_status', d['post_status'], '| _pk_status', d['pk_status'], '| projection', (d['projection'] or {}).get('status'))"
  collection_http "$P/trans-$TRANS-presente.txt" "$EXT"
done

echo "== R1 cas refuse : projection PÉRIMÉE (méta directe, sans vidange) ==" | tee -a "$P/journal-r1.txt"
$PHP "$R1PHP" refuse_perimee "$PID" | tee -a "$P/journal-r1.txt" | python3 -c "import json,sys; d=json.loads(sys.stdin.read()); print('  post_status', d['post_status'], '| _pk_status', d['pk_status'], '| projection', (d['projection'] or {}).get('status'))"
collection_http "$P/refuse-perimee-presente.txt" "$EXT"
$PHP "$R1PHP" projection "$PID" | tee -a "$P/journal-r1.txt" | python3 -c "import json,sys; d=json.loads(sys.stdin.read()); print('  projection', (d['projection'] or {}).get('status'), '| find() individuel :', d['find_individuel'])"

echo "== R1 cas refuse : projection SYNCHRONISÉE (vidange) ==" | tee -a "$P/journal-r1.txt"
$PHP "$R1PHP" refuse_synchronisee "$PID" | tee -a "$P/journal-r1.txt" | python3 -c "import json,sys; d=json.loads(sys.stdin.read()); print('  post_status', d['post_status'], '| _pk_status', d['pk_status'], '| projection', (d['projection'] or {}).get('status'))"
collection_http "$P/refuse-synchronisee-presente.txt" "$EXT"
$PHP "$R1PHP" projection "$PID" | tee -a "$P/journal-r1.txt" | python3 -c "import json,sys; d=json.loads(sys.stdin.read()); print('  projection', (d['projection'] or {}).get('status'), '| find() individuel :', d['find_individuel'])"

echo "== R1 fiche publique HTTP (disponibilité ≠ existence) ==" | tee -a "$P/journal-r1.txt"
curl -sS --max-time 20 -o "$P/fiche-publique.html" -w "fiche %{http_code} (%{size_download} octets)\n" "$URLF" | tee -a "$P/journal-r1.txt"

echo "== R1 nettoyage des fixtures ==" | tee -a "$P/journal-r1.txt"
$PHP "$R1PHP" nettoyage "$PID" | tee -a "$P/journal-r1.txt"

echo "== R1 SYNTHÈSE ==" | tee -a "$P/journal-r1.txt"
python3 - "$P" "$EXT" <<'PY' | tee -a "$P/journal-r1.txt"
import sys, re
base, ext = sys.argv[1], sys.argv[2]
def lit(f):
    try: return open(f"{base}/{f}").read().strip()
    except FileNotFoundError: return "?"
def trans(f):
    txt = lit(f)
    m = re.search(r"post_status (\w+) \| _pk_status (\w+) \| projection (\w+)", open(f"{base}/journal-r1.txt").read())
    return txt
print(f"external_id fixture : {ext}")
print(f"  état initial          → collection : {lit('01-init-presente.txt')}")
print(f"  après mark_sold       → collection : {lit('trans-mark_sold-presente.txt')}")
print(f"  après mark_rented     → collection : {lit('trans-mark_rented-presente.txt')}")
print(f"  après archive         → collection : {lit('trans-archive-presente.txt')}")
print(f"  refuse PÉRIMÉE        → collection : {lit('refuse-perimee-presente.txt')}")
print(f"  refuse SYNCHRONISÉE   → collection : {lit('refuse-synchronisee-presente.txt')}")
PY
echo "R1-TERMINÉ"
