<?php
/**
 * Édition du lot C — SE-027 (E-2702) : conditionnement Polylang des 5 règles
 * préfixées + bump RULES_VERSION 4→5. Remplacements exacts de sous-chaînes,
 * aucune normalisation d'indentation (tabs conservés).
 */
$f = '/home/z/my-project/bench/depot-phase1/theme/partikulier/inc/class-listing-urls.php';
$src = file_get_contents($f);
if ($src === false) { fwrite(STDERR, "lecture impossible\n"); exit(1); }

/* ── Modification 1 : bump de version (l.33). ── */
$avant1 = "\tconst RULES_VERSION = '4';";
$apres1 = "\tconst RULES_VERSION = '5';";
if (substr_count($src, $avant1) !== 1) { fwrite(STDERR, "ANCRE 1 absente ou non unique (RULES_VERSION)\n"); exit(1); }
$src = str_replace($avant1, $apres1, $src);

/* ── Modification 2 : encapsulation des 5 règles préfixées. ── */
$avant2 = <<<'BLOC'
		// Les archives et taxonomies doivent aussi être explicites : selon la
		// version d’Estatik/Polylang, leurs règles natives ne sont pas toujours
		// préfixées ou persistées dans une installation froide.
		add_rewrite_rule( '^(fr|en|ar)/annonces/page/([0-9]+)/?$', 'index.php?post_type=' . $cpt . '&paged=$matches[2]&lang=$matches[1]', 'top' );
		add_rewrite_rule( '^(fr|en|ar)/annonces/?$', 'index.php?post_type=' . $cpt . '&lang=$matches[1]', 'top' );
		add_rewrite_rule( '^annonces/page/([0-9]+)/?$', 'index.php?post_type=' . $cpt . '&paged=$matches[1]', 'top' );
		add_rewrite_rule( '^annonces/?$', 'index.php?post_type=' . $cpt, 'top' );
		add_rewrite_rule( '^(fr|en|ar)/location/([^/]+)/?$', 'index.php?post_type=' . $cpt . '&pk_city_slug=$matches[2]&lang=$matches[1]', 'top' );
			add_rewrite_rule( '^location/([^/]+)/?$', 'index.php?post_type=' . $cpt . '&pk_city_slug=$matches[1]', 'top' );

		// Polylang ajoute le slug de langue devant les fiches non par defaut.
		// Ces regles doivent preceder les regles sans prefixe : sans elles,
		// /en/annonce/... et /ar/annonce/... tombent en 404 avant resolution.
		add_rewrite_rule(
			'^(fr|en|ar)/' . $base . '/[^/]+/[^/]+/([^/]+)/?$',
			'index.php?post_type=' . $cpt . '&pk_listing_slug=$matches[2]&lang=$matches[1]',
			'top'
		);
		add_rewrite_rule(
			'^(fr|en|ar)/' . $base . '/[^/]+/([^/]+)/?$',
			'index.php?post_type=' . $cpt . '&pk_listing_slug=$matches[2]&lang=$matches[1]',
			'top'
		);
BLOC;

$apres2 = <<<'BLOC'
		// Dans la configuration Polylang de référence, les cinq règles
		// déjà préfixées recevraient un second groupe de langue (SE-027).
		// Conserver leurs déclarations explicites seulement sans Polylang.
		// Les règles sans préfixe restent déclarées ci-dessous.
		$prefix_langue = ! defined( 'POLYLANG_VERSION' );

		if ( $prefix_langue ) {
			// Les archives et taxonomies doivent aussi être explicites : selon la
			// version d’Estatik, leurs règles natives ne sont pas toujours
			// préfixées ou persistées dans une installation froide.
			add_rewrite_rule( '^(fr|en|ar)/annonces/page/([0-9]+)/?$', 'index.php?post_type=' . $cpt . '&paged=$matches[2]&lang=$matches[1]', 'top' );
			add_rewrite_rule( '^(fr|en|ar)/annonces/?$', 'index.php?post_type=' . $cpt . '&lang=$matches[1]', 'top' );
			add_rewrite_rule( '^(fr|en|ar)/location/([^/]+)/?$', 'index.php?post_type=' . $cpt . '&pk_city_slug=$matches[2]&lang=$matches[1]', 'top' );

			// Polylang ajoute le slug de langue devant les fiches non par defaut.
			// Ces regles doivent preceder les regles sans prefixe : sans elles,
			// /en/annonce/... et /ar/annonce/... tombent en 404 avant resolution.
			add_rewrite_rule(
				'^(fr|en|ar)/' . $base . '/[^/]+/[^/]+/([^/]+)/?$',
				'index.php?post_type=' . $cpt . '&pk_listing_slug=$matches[2]&lang=$matches[1]',
				'top'
			);
			add_rewrite_rule(
				'^(fr|en|ar)/' . $base . '/[^/]+/([^/]+)/?$',
				'index.php?post_type=' . $cpt . '&pk_listing_slug=$matches[2]&lang=$matches[1]',
				'top'
			);
		}

		// Règles sans préfixe : toujours déclarées. Avec Polylang, c'est lui qui
		// les décline dans la configuration validée ; sans Polylang, repli sans langue.
		add_rewrite_rule( '^annonces/page/([0-9]+)/?$', 'index.php?post_type=' . $cpt . '&paged=$matches[1]', 'top' );
		add_rewrite_rule( '^annonces/?$', 'index.php?post_type=' . $cpt, 'top' );
			add_rewrite_rule( '^location/([^/]+)/?$', 'index.php?post_type=' . $cpt . '&pk_city_slug=$matches[1]', 'top' );
BLOC;

if (substr_count($src, $avant2) !== 1) { fwrite(STDERR, "ANCRE 2 absente ou non unique (bloc règles)\n"); exit(1); }
$src = str_replace($avant2, $apres2, $src);

if (file_put_contents($f, $src) === false) { fwrite(STDERR, "écriture impossible\n"); exit(1); }
echo "éditions C appliquées (RULES_VERSION 5 + conditionnement Polylang)\n";
