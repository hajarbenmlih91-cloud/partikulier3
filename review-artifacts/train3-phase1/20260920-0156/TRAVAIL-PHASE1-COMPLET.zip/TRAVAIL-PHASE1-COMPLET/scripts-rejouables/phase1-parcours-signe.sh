#!/usr/bin/env bash
# Phase 1 — parcours diagnostic signé valide (E-3201, exigé pour clore A).
# Usage : phase1-parcours-signe.sh <avant|apres>
# Jeton jamais archivé : masqué dans toutes les preuves.
set -euo pipefail
QUAND="${1:?usage: $0 <avant|apres>}"
P=/home/z/my-project/download/preuves-phase1
B=http://127.0.0.1:8099
D="$P/RA-1/$QUAND"
JAR="$P/RA-1/cookies-$QUAND.txt"
mkdir -p "$D"

echo "== 1. connexion admin locale =="
curl -sS -c "$JAR" -b "$JAR" -o "$D/login.html" -w 'login POST = %{http_code}\n' \
  "$B/wp-login.php" \
  --data-urlencode 'log=admin' --data-urlencode 'pwd=admin' \
  --data-urlencode 'wp-submit=Log In' --data-urlencode "redirect_to=$B/wp-admin/" \
  --data-urlencode 'testcookie=1' -H "Cookie: wordpress_test_cookie=WP%20Cookie%20check"

echo "== 2. écran admin Diagnostic complet (écran réel, pas page de login) =="
curl -sS -c "$JAR" -b "$JAR" -o "$D/admin-ecran.html" -w 'admin GET = %{http_code}\n' \
  "$B/wp-admin/admin.php?page=pk-diagnostic"
if grep -q "wp-login.php" "$D/admin-ecran.html" && ! grep -q "pk-diagnostic\|Diagnostic" "$D/admin-ecran.html"; then
  echo "ÉCHEC : page de login au lieu de l'écran"; exit 1
fi
grep -c "Transmettre le rapport" "$D/admin-ecran.html" | sed 's/^/bloc liens signés (occurrences): /'

echo "== 3. extraction du lien signé (rapport texte complet) — jeton non archivé =="
LIEN=$(grep -o 'http://127\.0\.0\.1:8099/?pk_diag=1&amp;pk_diag_jeton=[a-f0-9]*' "$D/admin-ecran.html" | head -1 | sed 's/&amp;/\&/')
if [ -z "$LIEN" ]; then echo "ÉCHEC : lien signé introuvable"; exit 1; fi
echo "lien signé extrait (jeton masqué) : $(echo "$LIEN" | sed 's/pk_diag_jeton=[a-f0-9]*/pk_diag_jeton=[MASQUE]/')"

echo "== 4. rejet : admin connecté, jeton absent =="
curl -sS -c "$JAR" -b "$JAR" -o "$D/jeton-absent.txt" -w 'pk_diag sans jeton = %{http_code}\n' "$B/?pk_diag=1"
grep -o "Jeton absent ou expire" "$D/jeton-absent.txt" | head -1 || echo "ÉCHEC : message de rejet attendu"

echo "== 5. parcours signé valide : rapport texte complet =="
curl -sS --max-time 120 -c "$JAR" -b "$JAR" -o "$D/rapport-signe.txt" -w 'lien signé = %{http_code} taille=%{size_download}\n' "$LIEN"
# preuve expurgée : premier octets du rapport (aucun jeton dans le corps)
head -c 400 "$D/rapport-signe.txt" > "$D/rapport-signe-extrait.txt"
echo "--- extrait du rapport (400 premiers octets) ---"
cat "$D/rapport-signe-extrait.txt"
echo; echo "--- fin extrait ---"
if [ -s "$D/rapport-signe.txt" ]; then echo "RAPPORT GÉNÉRÉ ($(wc -c < "$D/rapport-signe.txt") octets)"; else echo "ÉCHEC : rapport vide"; exit 1; fi

echo "== 6. anonyme ?pk_diag=1 : aucun diagnostic divulgué =="
curl -sS -o "$D/anonyme.html" -w 'anonyme pk_diag = %{http_code}\n' "$B/?pk_diag=1"
if grep -qi "pk-sonde\|point(s) bloquant\|Diagnostic terminé" "$D/anonyme.html"; then
  echo "ÉCHEC : contenu diagnostic divulgué à l'anonyme"; exit 1
fi
echo "anonyme : page ordinaire, aucun marqueur diagnostic — OK"

echo "PARCOURS-SIGNÉ-$QUAND-TERMINÉ"
