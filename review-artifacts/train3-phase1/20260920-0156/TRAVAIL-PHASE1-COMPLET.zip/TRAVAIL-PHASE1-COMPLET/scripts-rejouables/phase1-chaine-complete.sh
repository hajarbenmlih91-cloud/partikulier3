#!/usr/bin/env bash
# Phase 1 — chaîne CI complète sur installation FRAÎCHE (démonstration locale
# des oracles intermédiaire et final du CDC §6.4).
# Usage : phase1-chaine-complete.sh <AB|ABC>
#   AB  → référence + diff A + diff B  → oracle attendu 376/376, 39 suites
#   ABC → référence + A + B + C        → oracle attendu 382/382, 40 suites
set -euo pipefail
ETAT="${1:?usage: $0 <AB|ABC>}"
BENCH=/home/z/my-project/bench
P=/home/z/my-project/download/preuves-phase1
D="$BENCH/depot-phase1"
LAB="$BENCH/lab-chaine-$ETAT"
PHP="$BENCH/php"
WPCLI="$BENCH/wp-cli.phar"
SHA=4b41bd65f2414ea9ce0fd847f144c46fccbab521
B=http://127.0.0.1:8099

case "$ETAT" in
  AB)  DIFFS="A-SE032 B-SE041";       ATTENDU_TOT=376; ATTENDU_N=39 ;;
  ABC) DIFFS="A-SE032 B-SE041 C-SE027"; ATTENDU_TOT=382; ATTENDU_N=40 ;;
  *) echo "état inconnu"; exit 64 ;;
esac

# Libérer le port 8099 : tuer TOUT serveur PHP intégré résiduel du bench
# (un serveur survivant servirait un AUTRE lab — faux vert inacceptable).
pkill -f "$PHP -S 127.0.0.1" 2>/dev/null || true
sleep 1
if curl -s -o /dev/null --max-time 2 http://127.0.0.1:8099/; then
  echo "PORTE 8099 ENCORE OCCUPÉE — arrêt"; exit 1
fi

echo "== 1. source à l'état $ETAT (clone frais + diffs séquentiels) =="
SRC="$BENCH/source-$ETAT"
rm -rf "$SRC" "$LAB"
git clone --quiet --no-local "$D" "$SRC"
cd "$SRC"
git checkout --quiet "$SHA"
git checkout --quiet -b chaine-$ETAT
for lot in $DIFFS; do
  git apply --check "$P/PHASE1-LOT-$lot.diff"
  git apply "$P/PHASE1-LOT-$lot.diff"
  echo "   diff $lot appliqué"
done

echo "== 2. installation fraîche (WordPress 6.6 + plugins + état $ETAT) =="
mkdir -p "$LAB"
cd "$LAB"
unzip -q "$BENCH/lab-phase1/tools/wordpress-6.6.zip" && mv wordpress htdocs
unzip -q "$BENCH/lab-phase1/tools/estatik-4.3.5.zip" -d htdocs/wp-content/plugins/
cp -a "$BENCH/lab-phase1/htdocs/wp-content/plugins/polylang" htdocs/wp-content/plugins/
cp -a "$BENCH/lab-phase1/htdocs/wp-content/plugins/sqlite-database-integration" htdocs/wp-content/plugins/
cp -a "$BENCH/lab-phase1/htdocs/wp-content/db.php" htdocs/wp-content/db.php
mkdir -p htdocs/wp-content/database htdocs/wp-content/uploads/partikulier-cache
sed "s#lab-phase1#lab-chaine-$ETAT#g" "$BENCH/lab-phase1/htdocs/wp-config.php" > htdocs/wp-config.php
git -C "$SRC" archive HEAD theme/partikulier | tar -x -C "$LAB/htdocs/wp-content" --strip-components=1 --warning=no-timestamps 2>/dev/null || {
  # archive ne voit pas les changements non commités : copie directe de l'arbre
  mkdir -p tmp-copy && cd tmp-copy && git -C "$SRC" archive "$SHA" theme/partikulier plugin/partikulier-core | tar -x && cd ..
  cp -a "tmp-copy/theme/partikulier" htdocs/wp-content/themes/
  cp -a "tmp-copy/plugin/partikulier-core" htdocs/wp-content/plugins/
  rm -rf tmp-copy
}
# L'état du working tree (non commité) doit servir : rsync depuis $SRC.
rsync -a --delete --exclude='.git' --exclude='.github' "$SRC/theme/partikulier/" htdocs/wp-content/themes/partikulier/
rsync -a --delete --exclude='.git' --exclude='.github' --exclude='node_modules' "$SRC/plugin/partikulier-core/" htdocs/wp-content/plugins/partikulier-core/

WP() { "$PHP" "$WPCLI" --path="$LAB/htdocs" "$@"; }
WP core install --url=http://127.0.0.1:8099 --title=Partikulier \
  --admin_user=admin --admin_password=admin --admin_email=admin@example.com --skip-email >/dev/null
WP plugin activate estatik >/dev/null
WP plugin activate partikulier-core >/dev/null
WP plugin activate sqlite-database-integration >/dev/null
WP theme activate partikulier >/dev/null
echo "   installée (thème $(grep -m1 '^Version' htdocs/wp-content/themes/partikulier/style.css | tr -d ' '))"
cd "$LAB" && "$PHP" -r 'require "htdocs/wp-load.php"; $response = rest_do_request(new WP_REST_Request("GET", "/partikulier/v1/health")); $d = $response->get_data(); if (($d["status"] ?? "") !== "ok") { fwrite(STDERR, json_encode($d)."\n"); exit(1); } echo "   health ok — core ".($d["core_version"] ?? "?")." / schema ".($d["schema_version"] ?? "?")."\n";'

echo "== 3. fixtures + invariants (verbatim CI) =="
cd "$LAB" && "$PHP" -r 'require "htdocs/wp-load.php"; wp_set_current_user(1); $request = new WP_REST_Request("POST", "/partikulier/v1/listings"); $request->set_header("Content-Type", "application/json"); $request->set_body(wp_json_encode(["title" => "CI fixture", "description" => "CI contract fixture", "locale" => "fr", "price" => 100, "area" => 10])); $response = rest_do_request($request); if ($response->get_status() !== 201) { fwrite(STDERR, "fixture listing failed: ".wp_json_encode($response->get_data())."\n"); exit(1); } $id = (int) (($response->get_data()["id"] ?? 0)); global $wpdb; $row = $wpdb->get_row($wpdb->prepare("SELECT external_id FROM {$wpdb->prefix}pk_listings WHERE id = %d", $id), ARRAY_A); $post_id = $row ? (int) substr((string) $row["external_id"], strlen("estatik:")) : 0; if ($post_id < 1) { fwrite(STDERR, "fixture post missing\n"); exit(1); } wp_update_post(["ID" => $post_id, "post_status" => "publish"]); wp_insert_post(["post_type" => "properties", "post_status" => "publish", "post_title" => "CI variant fixture", "post_content" => "CI variant contract fixture", "post_author" => 1]); for ($i = 3; $i <= 30; $i++) { wp_insert_post(["post_type" => "properties", "post_status" => "publish", "post_title" => "CI i18n fixture $i", "post_content" => "CI i18n contract fixture", "post_author" => 1]); } unload_textdomain("partikulier", true); load_theme_textdomain("partikulier", get_template_directory() . "/languages"); load_textdomain("partikulier", WP_PLUGIN_DIR . "/partikulier-core/languages/en_US.mo"); (new \Partikulier\Core\Integration\ListingSynchronizer())->flush(); echo "   fixture listings ready: 30 published properties\n";' >/dev/null
cd "$LAB" && "$PHP" -r 'require "htdocs/wp-load.php"; global $wpdb; $now = gmdate("Y-m-d H:i:s"); update_option("pk_n8n_settings", ["automation_api_secret" => "ci-contract-secret", "active_key_id" => "N", "hmac_mode" => "off"], false); $leads = $wpdb->prefix . "pk_buyer_leads"; $existing = (int) $wpdb->get_var("SELECT COUNT(*) FROM $leads"); for ($i = $existing; $i < 10; $i++) { $seed = "ci-historical-lead-$i"; $wpdb->insert($leads, ["phone_hash" => hash_hmac("sha256", $seed, wp_salt("auth")), "phone_encrypted" => base64_encode($seed), "first_seen_at" => $now, "last_seen_at" => $now], ["%s", "%s", "%s", "%s"]); } $audit = new \Partikulier\Core\AuditLogger(); $adoptions = (array) $wpdb->get_results("SELECT metadata_json FROM {$wpdb->prefix}pk_audit_log"); foreach ([["B2", "leads"], ["B3", "alerts"], ["B4", "automation"], ["B5", "owner_stats"], ["B6", "translation_variants"]] as [$lot, $domain]) { $found = false; foreach ($adoptions as $row) { $meta = json_decode((string) $row->metadata_json, true); if (($meta["lot"] ?? "") === $lot && ($meta["domain"] ?? "") === $domain) { $found = true; break; } } if (!$found) { $audit->record("domain_adopted", "schema", null, ["lot" => $lot, "domain" => $domain]); } } $events = $wpdb->prefix . "pk_automation_events"; for ($i = 1; $i <= 2; $i++) { $wpdb->insert($events, ["event_id" => "ci-historical-event-$i", "event_type" => "fixture", "source" => "ci", "payload_hash" => hash("sha256", "fixture-$i"), "status" => "received", "received_at" => $now], ["%s", "%s", "%s", "%s", "%s", "%s"]); } $saves = $wpdb->prefix . "pk_property_saves"; for ($i = 1; $i <= 4; $i++) { $wpdb->insert($saves, ["property_id" => $i, "visitor_hash" => hash("sha256", "ci-visitor-$i"), "created_at" => $now, "updated_at" => $now], ["%d", "%s", "%s", "%s"]); } echo "   historical fixtures ready\n";' >/dev/null
WP rewrite structure '/%postname%/' >/dev/null 2>&1

export PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" PK_REPO_DIR="$SRC" PK_THEME_DIR="$SRC/theme/partikulier"
rm -rf preuves-run; mkdir -p preuves-run/contrats; : > preuves-run/journal.txt

echo "== 4. 32 suites dynamiques (sans Polylang, ordre CI) =="
cd "$LAB/htdocs"
for suite in core-contract services-contract load-contract rest-lite-scope \
             routes-collision sync-contract payments-contract premium-contract \
             leads-contract leads-domain-contract lead-erase-security-contract \
             alerts-domain-contract automation-domain-contract \
             owner-stats-domain-contract \
             translation-variants-domain-contract i18n-chrome-domain-contract \
             i18n-content-domain-contract i18n-unified-mechanism-contract \
             module-perimeter-contract avif-security-contract \
             vestige-extinction-contract artifact-hygiene-contract \
             options-sanitizer-contract se022-idempotence-contract \
             se026-hmac-mode-contract \
             slug-redirects-domain-contract \
             se024-i18n-dedup-contract \
             se048-premium-honesty-contract \
             se035-catalogs-contract \
             se036-places-referential-contract \
             se037-seo-multilingual-contract \
             se054-closure-contract; do
  if "$PHP" "wp-content/plugins/partikulier-core/tests/$suite.php" \
       > "../preuves-run/contrats/$suite.json" 2> "../preuves-run/contrats/$suite.err"; then
    echo "PASS  $suite" | tee -a ../preuves-run/journal.txt
  else
    echo "FAIL  $suite" | tee -a ../preuves-run/journal.txt; exit 1
  fi
done

cd "$LAB"
ln -sfn htdocs wp; ln -sfn "$SRC/theme" theme; ln -sfn "$SRC/plugin" plugin
sonde() {
  local sain=false code=""
  for i in $(seq 1 60); do
    code=$(curl -s -o /dev/null -w '%{http_code}' "$1" || true)
    [ "$code" = "200" ] && sain=true && break
    sleep 0.5
  done
  [ "$sain" = true ] || { echo "sonde HTTP KO sur $1 (code=$code)"; return 1; }
}

echo "== 5. batteries HTTP sans Polylang (front-assets, se022, se043, se034, search-arrays) =="
"$PHP" -S 127.0.0.1:8099 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/front-assets-server.log 2>&1 &
SRV=$!
sleep 1
if grep -q "Failed to listen" preuves-run/front-assets-server.log; then
  echo "le serveur front-assets n a pas pu écouter (port occupé)"; exit 1
fi
sonde "$B/"
PK_BASE="$B" PK_ESTATIK_FILE="$LAB/htdocs/wp-content/plugins/estatik/estatik.php" \
  node theme/partikulier/tests/front-assets.mjs > preuves-run/contrats/front-assets.json
echo "PASS  front-assets" | tee -a preuves-run/journal.txt
kill "$SRV" 2>/dev/null || true; sleep 1

PHP_CLI_SERVER_WORKERS=4 "$PHP" -S 127.0.0.1:8101 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/se022-server.log 2>&1 &
SRV=$!
for i in $(seq 1 60); do curl -s -o /dev/null http://127.0.0.1:8101/ && break; sleep 0.5; done
PK_BASE=http://127.0.0.1:8101 PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" \
  "$PHP" plugin/partikulier-core/tests/se022-http-battery.php > preuves-run/contrats/se022-http-battery.json
echo "PASS  se022-http-battery" | tee -a preuves-run/journal.txt
kill "$SRV" 2>/dev/null || true; sleep 1

"$PHP" -S 127.0.0.1:8099 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/se043-server.log 2>&1 &
SRV=$!; sonde "$B/"
PK_BASE="$B" PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" \
  "$PHP" plugin/partikulier-core/tests/se043-geo-routing-battery.php > preuves-run/contrats/se043-geo-routing-battery.json
echo "PASS  se043-geo-routing-battery" | tee -a preuves-run/journal.txt
kill "$SRV" 2>/dev/null || true; sleep 1

"$PHP" -S 127.0.0.1:8099 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/se034-server.log 2>&1 &
SRV=$!; sonde "$B/"
PK_BASE="$B" PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" \
  "$PHP" plugin/partikulier-core/tests/se034-form-idempotency-contract.php > preuves-run/contrats/se034-form-idempotency-contract.json
echo "PASS  se034-form-idempotency-contract" | tee -a preuves-run/journal.txt
kill "$SRV" 2>/dev/null || true; sleep 1

"$PHP" -S 127.0.0.1:8099 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/search-arrays-server.log 2>&1 &
SRV=$!; sonde "$B/"
PK_BASE="$B" PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" \
  "$PHP" theme/partikulier/tests/search-arrays-contract.php > preuves-run/contrats/search-arrays-contract.json
echo "PASS  search-arrays-contract" | tee -a preuves-run/journal.txt
kill "$SRV" 2>/dev/null || true; sleep 1

echo "== 6. Polylang + langues + assignation masse + flush (verbatim CI) =="
WP plugin activate polylang >/dev/null
sed "s#lab-phase1#lab-chaine-$ETAT#" "$BENCH/lab-phase1/pll-langues.php" > pll-langues.php 2>/dev/null || cp "$BENCH/lab-phase1/pll-langues.php" pll-langues.php
WP eval-file pll-langues.php >/dev/null
sed "s#lab-phase1#lab-chaine-$ETAT#" "$BENCH/lab-phase1/pll-masse.php" > pll-masse.php 2>/dev/null || cp "$BENCH/lab-phase1/pll-masse.php" pll-masse.php
WP eval-file pll-masse.php >/dev/null
WP rewrite flush >/dev/null

echo "== 7. SE-025 (contexte trilingue) =="
PHP_CLI_SERVER_WORKERS=4 "$PHP" -S 127.0.0.1:8099 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/se025-server.log 2>&1 &
SRV=$!; sonde "$B/fr/"
PK_BASE="$B" PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" \
  "$PHP" theme/partikulier/tests/se025-trilingual-routes-contract.php > preuves-run/contrats/se025-trilingual-routes-contract.json
echo "PASS  se025-trilingual-routes-contract" | tee -a preuves-run/journal.txt
kill "$SRV" 2>/dev/null || true; sleep 1

if [ "$ETAT" != "AB" ]; then :; fi
echo "== 8. SE-041 (lot B) =="
"$PHP" -S 127.0.0.1:8099 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/se041-server.log 2>&1 &
SRV=$!; sonde "$B/fr/"
PK_BASE="$B" PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" \
  "$PHP" theme/partikulier/tests/se041-xmlrpc-contract.php > preuves-run/contrats/se041-xmlrpc-contract.json
echo "PASS  se041-xmlrpc-contract" | tee -a preuves-run/journal.txt
kill "$SRV" 2>/dev/null || true; sleep 1

if [ "$ETAT" = "ABC" ]; then
  echo "== 9. SE-027 (lot C) =="
  "$PHP" -S 127.0.0.1:8099 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/se027-server.log 2>&1 &
  SRV=$!; sonde "$B/fr/"
  PK_BASE="$B" PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" PK_WP_CLI="$PHP $WPCLI" \
    "$PHP" theme/partikulier/tests/se027-rewrite-prefix-contract.php > preuves-run/contrats/se027-rewrite-prefix-contract.json
  echo "PASS  se027-rewrite-prefix-contract" | tee -a preuves-run/journal.txt
  kill "$SRV" 2>/dev/null || true; sleep 1
fi

echo "== 10. oracle (attendu $ATTENDU_TOT/$ATTENDU_TOT sur $ATTENDU_N suites) =="
cd "$LAB"
"$PHP" -r '$tot=0; $pas=0; $n=0; foreach (glob("preuves-run/contrats/*.json") as $f) { $d=json_decode(file_get_contents($f), true); if (($d["status"] ?? "") !== "PASS") { fwrite(STDERR, basename($f).": status != PASS\n"); exit(1); } $tot += (int) $d["total"]; $pas += (int) $d["passed"]; $n++; } echo "contrats: $pas/$tot sur $n suites\n"; if ($tot !== (int) $argv[1] || $pas !== (int) $argv[1] || $n !== (int) $argv[2]) { fwrite(STDERR, "oracle inattendu\n"); exit(1); }' "$ATTENDU_TOT" "$ATTENDU_N"

rm -rf "$P/chaine-$ETAT"; cp -a "$LAB/preuves-run" "$P/chaine-$ETAT"
echo "CHAÎNE-$ETAT : $ATTENDU_TOT/$ATTENDU_TOT sur $ATTENDU_N suites — démontrée localement"
