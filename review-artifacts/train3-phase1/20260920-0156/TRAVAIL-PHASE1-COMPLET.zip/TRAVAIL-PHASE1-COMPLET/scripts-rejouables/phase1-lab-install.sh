#!/usr/bin/env bash
# Phase 1 Train 3 — installation du laboratoire isolé (référence 4b41bd6).
# Reproduit la procédure CI canonique (.github/workflows/contrats-recette.yml)
# avec l'écart SQL documenté : SQLite (lab) au lieu de MySQL 8 (CI).
set -euo pipefail

BENCH=/home/z/my-project/bench
LAB="$BENCH/lab-phase1"
WP_DIR="$LAB/htdocs"
PHP="$BENCH/php"
WPCLI="$BENCH/wp-cli.phar"
WP() { "$PHP" "$WPCLI" --path="$WP_DIR" "$@"; }
LOG=/home/z/my-project/download/preuves-phase1/journal
mkdir -p "$LOG"

echo "== wp-config.php (SQLite, WP_ENVIRONMENT_TYPE=local) =="
mkdir -p "$WP_DIR/wp-content/database"
cat > "$WP_DIR/wp-config.php" <<'WPCONF'
<?php
define( 'DB_ENGINE', 'sqlite' );
define( 'DB_DIR', '/home/z/my-project/bench/lab-phase1/htdocs/wp-content/database/' );
define( 'DB_FILE', '.ht.sqlite' );
define( 'DB_NAME', 'sqlite' );
define( 'DB_USER', 'root' );
define( 'DB_PASSWORD', '' );
define( 'DB_HOST', 'localhost' );
define( 'DB_CHARSET', 'utf8mb4' );
define( 'DB_COLLATE', '' );
define( 'AUTH_KEY', 'lab-phase1-k1-9xQztVqKRAtEBCFf0yIlCV1JT9ayWvBJUfXxZOmST5ZmxhPPqbo1cE' );
define( 'SECURE_AUTH_KEY', 'lab-phase1-k2-hRTwRyFFVUnf2jJzHfRiNX2wcU9O2aYMHPUGZeXG1BIQ5Aq5wOaRMYVFF0y' );
define( 'LOGGED_IN_KEY', 'lab-phase1-k3-wrBFzWAvNbShXYWcdlROqKEOaF2v1IIB3XdHhBSza2vyw1M4lFrPLWCa9PUZj' );
define( 'NONCE_KEY', 'lab-phase1-k4-KyEunU0gGZg7Ew1LnstBWBCm7uLLYp994G5WVNptFL6VFRcycy7em7wE9l2J3L' );
define( 'AUTH_SALT', 'lab-phase1-k5-9qjW3DQAtRyd5UzcTZQwbPyKjmbjGZ2hnMSfCTzldN8C7GrTcUicVAzOyPD' );
define( 'SECURE_AUTH_SALT', 'lab-phase1-k6-KIuVQNMmOFZwCiksnF1sdR4072MOWbjGbrIFjPWheq4PD8uFbsntMWJwhzZAY' );
define( 'LOGGED_IN_SALT', 'lab-phase1-k7-ULvSuE7RJoD4RaEBBwyPN4HqWMiitT0YvYKdrVWRU6yF6IDLBpA5jGvShWoy' );
define( 'NONCE_SALT', 'lab-phase1-k8-KMIXcA2A1Pzgv4WfmU1BlXBOasEMV0FOwRu5IuC3LHNs2yUbc4aKshNRRfomX1' );
$table_prefix = 'wp_';
define( 'WP_HOME', 'http://127.0.0.1:8099' );
define( 'WP_SITEURL', 'http://127.0.0.1:8099' );
define( 'WP_ENVIRONMENT_TYPE', 'local' );
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );
define( 'WP_DEBUG_DISPLAY', false );
define( 'WP_CACHE', false );
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}
require_once ABSPATH . 'wp-settings.php';
WPCONF

echo "== core install =="
WP core install --url=http://127.0.0.1:8099 --title=Partikulier \
  --admin_user=admin --admin_password=admin --admin_email=admin@example.com --skip-email \
  | tee "$LOG/01-install.txt"

echo "== activation (ordre CI : estatik, partikulier-core, thème) =="
WP plugin activate estatik | tee -a "$LOG/01-install.txt"
WP plugin activate partikulier-core | tee -a "$LOG/01-install.txt"
WP plugin activate sqlite-database-integration | tee -a "$LOG/01-install.txt"
WP theme activate partikulier | tee -a "$LOG/01-install.txt"
mkdir -p "$WP_DIR/wp-content/uploads/partikulier-cache"

echo "== santé du plugin =="
cd "$LAB" && "$PHP" -r 'require "htdocs/wp-load.php"; $response = rest_do_request(new WP_REST_Request("GET", "/partikulier/v1/health")); $d = $response->get_data(); if (($d["status"] ?? "") !== "ok") { fwrite(STDERR, json_encode($d)."\n"); exit(1); } echo "health ok — core ".($d["core_version"] ?? "?")." / schema ".($d["schema_version"] ?? "?")."\n";' | tee "$LOG/02-health.txt"

echo "== fixture annonce + 30 properties (verbatim CI) =="
cd "$LAB" && "$PHP" -r 'require "htdocs/wp-load.php"; wp_set_current_user(1); $request = new WP_REST_Request("POST", "/partikulier/v1/listings"); $request->set_header("Content-Type", "application/json"); $request->set_body(wp_json_encode(["title" => "CI fixture", "description" => "CI contract fixture", "locale" => "fr", "price" => 100, "area" => 10])); $response = rest_do_request($request); if ($response->get_status() !== 201) { fwrite(STDERR, "fixture listing failed: ".wp_json_encode($response->get_data())."\n"); exit(1); } $id = (int) (($response->get_data()["id"] ?? 0)); global $wpdb; $row = $wpdb->get_row($wpdb->prepare("SELECT external_id FROM {$wpdb->prefix}pk_listings WHERE id = %d", $id), ARRAY_A); $post_id = $row ? (int) substr((string) $row["external_id"], strlen("estatik:")) : 0; if ($post_id < 1) { fwrite(STDERR, "fixture post missing\n"); exit(1); } wp_update_post(["ID" => $post_id, "post_status" => "publish"]); wp_insert_post(["post_type" => "properties", "post_status" => "publish", "post_title" => "CI variant fixture", "post_content" => "CI variant contract fixture", "post_author" => 1]); for ($i = 3; $i <= 30; $i++) { wp_insert_post(["post_type" => "properties", "post_status" => "publish", "post_title" => "CI i18n fixture $i", "post_content" => "CI i18n contract fixture", "post_author" => 1]); } unload_textdomain("partikulier", true); load_theme_textdomain("partikulier", get_template_directory() . "/languages"); load_textdomain("partikulier", WP_PLUGIN_DIR . "/partikulier-core/languages/en_US.mo"); (new \Partikulier\Core\Integration\ListingSynchronizer())->flush(); echo "fixture listings ready: 30 published properties\n";' | tee "$LOG/03-fixtures.txt"

echo "== invariants historiques B2-B5 (verbatim CI) =="
cd "$LAB" && "$PHP" -r 'require "htdocs/wp-load.php"; global $wpdb; $now = gmdate("Y-m-d H:i:s"); update_option("pk_n8n_settings", ["automation_api_secret" => "ci-contract-secret", "active_key_id" => "N", "hmac_mode" => "off"], false); $leads = $wpdb->prefix . "pk_buyer_leads"; $existing = (int) $wpdb->get_var("SELECT COUNT(*) FROM $leads"); for ($i = $existing; $i < 10; $i++) { $seed = "ci-historical-lead-$i"; $wpdb->insert($leads, ["phone_hash" => hash_hmac("sha256", $seed, wp_salt("auth")), "phone_encrypted" => base64_encode($seed), "first_seen_at" => $now, "last_seen_at" => $now], ["%s", "%s", "%s", "%s"]); } $audit = new \Partikulier\Core\AuditLogger(); $adoptions = (array) $wpdb->get_results("SELECT metadata_json FROM {$wpdb->prefix}pk_audit_log"); foreach ([["B2", "leads"], ["B3", "alerts"], ["B4", "automation"], ["B5", "owner_stats"], ["B6", "translation_variants"]] as [$lot, $domain]) { $found = false; foreach ($adoptions as $row) { $meta = json_decode((string) $row->metadata_json, true); if (($meta["lot"] ?? "") === $lot && ($meta["domain"] ?? "") === $domain) { $found = true; break; } } if (!$found) { $audit->record("domain_adopted", "schema", null, ["lot" => $lot, "domain" => $domain]); } } $events = $wpdb->prefix . "pk_automation_events"; for ($i = 1; $i <= 2; $i++) { $wpdb->insert($events, ["event_id" => "ci-historical-event-$i", "event_type" => "fixture", "source" => "ci", "payload_hash" => hash("sha256", "fixture-$i"), "status" => "received", "received_at" => $now], ["%s", "%s", "%s", "%s", "%s", "%s"]); } $saves = $wpdb->prefix . "pk_property_saves"; for ($i = 1; $i <= 4; $i++) { $wpdb->insert($saves, ["property_id" => $i, "visitor_hash" => hash("sha256", "ci-visitor-$i"), "created_at" => $now, "updated_at" => $now], ["%d", "%s", "%s", "%s"]); } echo "historical fixtures ready: leads=".(int) $wpdb->get_var("SELECT COUNT(*) FROM $leads")." events=".(int) $wpdb->get_var("SELECT COUNT(*) FROM $events")." saves=".(int) $wpdb->get_var("SELECT COUNT(*) FROM $saves")."\n";' | tee "$LOG/04-invariants.txt"

echo "== permaliens jolis (étape front-assets CI) =="
WP rewrite structure '/%postname%/' --hard | tee "$LOG/05-rewrite.txt"

echo "== versions consignées =="
{
  echo "WordPress: $(WP core version)"
  echo "PHP: $($PHP -v | head -1)"
  echo "SQL: SQLite (lab) — CI = MySQL 8, revue = MariaDB 11.8.6 (écart consigné)"
  echo "Theme: $(WP theme list --status=active --field=name) / $(grep -m1 Version $WP_DIR/wp-content/themes/partikulier/style.css | tr -d ' ')"
  echo "Plugin partikulier-core: $(grep -m1 'Version' $WP_DIR/wp-content/plugins/partikulier-core/partikulier-core.php | tr -d ' *')"
  echo "Estatik: $(grep -m1 Version $WP_DIR/wp-content/plugins/estatik/estatik.php | tr -d ' ')"
  echo "Polylang: $(grep -m1 Version $WP_DIR/wp-content/plugins/polylang/polylang.php | tr -d ' *') (non encore activé)"
  echo "Base SHA: $(git -C $BENCH/depot-phase1 rev-parse HEAD)"
} | tee "$LOG/06-versions.txt"

echo "INSTALL-TERMINEE"
