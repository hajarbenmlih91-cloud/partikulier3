#!/usr/bin/env bash
# Phase 1 — empreintes, archive exportable testée, nettoyage du runtime (P-6, §3.8).
set -euo pipefail
P=/home/z/my-project/download
cd "$P"

echo "== SHA256SUMS de tous les livrables =="
sha256sum \
  PHASE1-LOT-A-SE032.diff PHASE1-LOT-B-SE041.diff PHASE1-LOT-C-SE027.diff \
  RAPPORT-PHASE1-TRAIN3.md ORDRE-APPLICATION.md \
  $(find preuves-phase1 -type f | sort) > SHA256SUMS-PHASE1.txt
wc -l SHA256SUMS-PHASE1.txt
sha256sum -c SHA256SUMS-PHASE1.txt | grep -cv ": OK$" || echo "0 échecs — toutes les empreintes vérifiées"

echo "== archive exportable (diffs + rapport + ordre + contrats + journal) =="
rm -rf kit-phase1-archive kit-phase1.zip
mkdir -p kit-phase1-archive
cp PHASE1-LOT-A-SE032.diff PHASE1-LOT-B-SE041.diff PHASE1-LOT-C-SE027.diff \
   RAPPORT-PHASE1-TRAIN3.md ORDRE-APPLICATION.md SHA256SUMS-PHASE1.txt kit-phase1-archive/
cp -a preuves-phase1/contrats preuves-phase1/journal kit-phase1-archive/
zip -qr kit-phase1.zip kit-phase1-archive
sha256sum kit-phase1.zip | tee kit-phase1.zip.sha256

echo "== test d'extraction de l'archive =="
rm -rf /tmp/test-kit && mkdir -p /tmp/test-kit
unzip -q kit-phase1.zip -d /tmp/test-kit
diff -rq kit-phase1-archive /tmp/test-kit/kit-phase1-archive && echo "archive lisible et identique après extraction"
ls /tmp/test-kit/kit-phase1-archive/
rm -rf /tmp/test-kit

echo "== nettoyage du runtime jetable (serveurs, labs, sources, clones) =="
pkill -f "/bench/php -S 127.0.0.1" 2>/dev/null || true
sleep 1
cd /home/z/my-project/bench
rm -rf lab-phase1 lab-chaine-AB lab-chaine-ABC source-AB source-ABC depot-phase1 depot-verification
if curl -s -o /dev/null --max-time 2 http://127.0.0.1:8099/ 2>/dev/null; then
  echo "ATTENTION : quelque chose écoute encore sur 8099"
else
  echo "port 8099 fermé — aucun serveur résiduel"
fi
echo "NETTOYAGE-TERMINÉ"
