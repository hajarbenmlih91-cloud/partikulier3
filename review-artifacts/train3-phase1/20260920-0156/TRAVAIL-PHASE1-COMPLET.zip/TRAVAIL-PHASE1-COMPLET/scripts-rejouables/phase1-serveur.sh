#!/usr/bin/env bash
# Phase 1 — serveur HTTP persistant du laboratoire (origine = home :8099).
# Multi-workers : la sonde diagnostic émet des sous-requêtes HTTP (CDC §4.1.3).
set -euo pipefail
LAB=/home/z/my-project/bench/lab-phase1
PHP=/home/z/my-project/bench/php
cd "$LAB"
export PHP_CLI_SERVER_WORKERS=8
nohup "$PHP" -S 127.0.0.1:8099 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php \
  > server-phase1.log 2>&1 &
echo $! > server-phase1.pid
for i in $(seq 1 60); do
  code=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:8099/ || true)
  [ "$code" = "200" ] && break
  sleep 0.5
done
echo "SERVEUR PRET (pid $(cat server-phase1.pid), code / = $code)"
