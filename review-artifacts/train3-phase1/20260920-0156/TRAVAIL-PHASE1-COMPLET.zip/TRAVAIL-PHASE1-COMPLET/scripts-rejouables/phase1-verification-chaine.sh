#!/usr/bin/env bash
# Phase 1 — vérification de chaîne sur SECOND CLONE PROPRE (CDC §9.1).
# Applique A puis B puis C sur un checkout frais de 4b41bd6, sans commit,
# puis compare l'arbre final au working tree ayant passé les tests.
set -euo pipefail
BENCH=/home/z/my-project/bench
D="$BENCH/depot-phase1"
P=/home/z/my-project/download/preuves-phase1
V="$BENCH/depot-verification"
SHA=4b41bd65f2414ea9ce0fd847f144c46fccbab521
LOG="$P/journal/verification-chaine.txt"
{
echo "== second clone propre =="
rm -rf "$V"
git clone --quiet "$BENCH/depot-phase1" "$V" 2>/dev/null || git clone --quiet https://github.com/hajarbenmlih91-cloud/partikulier3 "$V"
cd "$V"
git checkout --quiet "$SHA"
git checkout --quiet -b verification-phase1
test "$(git rev-parse HEAD)" = "$SHA" && echo "HEAD = $SHA OK"
test -z "$(git status --porcelain)" && echo "arbre propre OK"

echo "== application séquentielle A → B → C =="
for lot in A-SE032 B-SE041 C-SE027; do
  echo "-- diff $lot : git apply --check"
  git apply --check "$P/PHASE1-LOT-$lot.diff"
  git apply "$P/PHASE1-LOT-$lot.diff"
  echo "   appliqué (exit 0)"
done
git diff --check && echo "git diff --check : aucun problème de blancs"

echo "== identité avec l'arbre testé (working tree depot-phase1) =="
if diff -rq --exclude='.git' "$V" "$D" > /tmp/divergence-verification.txt 2>&1; then
  echo "ARBRES STRICTEMENT IDENTIQUES (fichiers modifiés/ajoutés compris)"
else
  echo "DIVERGENCES DÉTECTÉES :"
  cat /tmp/divergence-verification.txt
  exit 1
fi

echo "== lint des fichiers ajoutés sur le clone vérifié =="
"$BENCH/php" -l theme/partikulier/tests/se041-xmlrpc-contract.php
"$BENCH/php" -l theme/partikulier/tests/se027-rewrite-prefix-contract.php
"$BENCH/php" -l theme/partikulier/inc/class-listing-urls.php
"$BENCH/php" -l theme/partikulier/inc/class-security.php
"$BENCH/php" -l theme/partikulier/pk-diagnostic.php
echo "VÉRIFICATION-DE-CHAÎNE : OK"
} 2>&1 | tee "$LOG"
