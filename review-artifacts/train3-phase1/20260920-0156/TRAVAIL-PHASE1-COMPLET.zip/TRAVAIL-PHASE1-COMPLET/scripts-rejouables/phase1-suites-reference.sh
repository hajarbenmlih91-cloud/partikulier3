#!/usr/bin/env bash
# Phase 1 — rejeu local de la chaîne CI de RÉFÉRENCE (avant tout patch).
# Reproduit .github/workflows/contrats-recette.yml étape par étape.
# Sorties : $LAB/preuves-run/ (contrats/*.json + journal) puis copie vers $PROOFS.
set -euo pipefail

BENCH=/home/z/my-project/bench
LAB="$BENCH/lab-phase1"
D="$BENCH/depot-phase1"
PHP="$BENCH/php"
WPCLI="$BENCH/wp-cli.phar"
WP() { "$PHP" "$WPCLI" --path="$LAB/htdocs" "$@"; }
P=/home/z/my-project/download/preuves-phase1
SHA=4b41bd65f2414ea9ce0fd847f144c46fccbab521
B=http://127.0.0.1:8099

# Libérer le port 8099 (les batteries gèrent leur propre serveur, discipline CI).
if [ -f "$LAB/server-phase1.pid" ]; then
  kill "$(cat "$LAB/server-phase1.pid")" 2>/dev/null || true
  sleep 1
fi

rm -rf "$LAB/preuves-run"; mkdir -p "$LAB/preuves-run/contrats"
: > "$LAB/preuves-run/journal.txt"
export PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" PK_REPO_DIR="$D" PK_THEME_DIR="$D/theme/partikulier"

echo "== 32 suites dynamiques (contexte SANS Polylang — ordre CI) =="
cd "$LAB/htdocs"
for suite in core-contract services-contract load-contract rest-lite-scope \
             routes-collision sync-contract payments-contract premium-contract \
             leads-contract leads-domain-contract lead-erase-security-contract \
             alerts-domain-contract automation-domain-contract \
             owner-stats-domain-contract \
             translation-variants-domain-contract i18n-chrome-domain-contract \
             i18n-content-domain-contract i18n-unified-mechanism-contract \
             module-perimeter-contract avif-security-contract \
             vestige-extinction-contract artifact-hygiene-contract \
             options-sanitizer-contract se022-idempotence-contract \
             se026-hmac-mode-contract \
             slug-redirects-domain-contract \
             se024-i18n-dedup-contract \
             se048-premium-honesty-contract \
             se035-catalogs-contract \
             se036-places-referential-contract \
             se037-seo-multilingual-contract \
             se054-closure-contract; do
  if "$PHP" "wp-content/plugins/partikulier-core/tests/$suite.php" \
       > "../preuves-run/contrats/$suite.json" \
       2> "../preuves-run/contrats/$suite.err"; then
    echo "PASS  $suite" | tee -a "$LAB/preuves-run/journal.txt"
  else
    echo "FAIL  $suite" | tee -a "$LAB/preuves-run/journal.txt"
    exit 1
  fi
done

cd "$LAB"
sonde() { # sonde <max> <chemin_sonde>
  local sain=false code=""
  for i in $(seq 1 60); do
    code=$(curl -s -o /dev/null -w '%{http_code}' "$1" || true)
    [ "$code" = "200" ] && sain=true && break
    sleep 0.5
  done
  [ "$sain" = true ] || { echo "sonde HTTP: pas de 200 sur $1 (code=$code)"; return 1; }
}

echo "== front-assets (SE-018) =="
"$PHP" -S 127.0.0.1:8099 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/front-assets-server.log 2>&1 &
SRV=$!
sonde "$B/"
PK_BASE="$B" PK_ESTATIK_FILE="$LAB/htdocs/wp-content/plugins/estatik/estatik.php" \
  node theme/partikulier/tests/front-assets.mjs > preuves-run/contrats/front-assets.json
echo "PASS  front-assets" | tee -a preuves-run/journal.txt
kill "$SRV" 2>/dev/null || true; sleep 1

echo "== se022-http-battery =="
PHP_CLI_SERVER_WORKERS=4 "$PHP" -S 127.0.0.1:8101 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/se022-server.log 2>&1 &
SRV=$!
for i in $(seq 1 60); do curl -s -o /dev/null http://127.0.0.1:8101/ && break; sleep 0.5; done
PK_BASE=http://127.0.0.1:8101 PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" \
  "$PHP" plugin/partikulier-core/tests/se022-http-battery.php > preuves-run/contrats/se022-http-battery.json
echo "PASS  se022-http-battery" | tee -a preuves-run/journal.txt
kill "$SRV" 2>/dev/null || true; sleep 1

echo "== se043-geo-routing-battery (SANS Polylang) =="
"$PHP" -S 127.0.0.1:8099 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/se043-server.log 2>&1 &
SRV=$!
sonde "$B/"
PK_BASE="$B" PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" \
  "$PHP" plugin/partikulier-core/tests/se043-geo-routing-battery.php > preuves-run/contrats/se043-geo-routing-battery.json
echo "PASS  se043-geo-routing-battery" | tee -a preuves-run/journal.txt
kill "$SRV" 2>/dev/null || true; sleep 1

echo "== se034-form-idempotency-contract =="
"$PHP" -S 127.0.0.1:8099 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/se034-server.log 2>&1 &
SRV=$!
sonde "$B/"
PK_BASE="$B" PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" \
  "$PHP" plugin/partikulier-core/tests/se034-form-idempotency-contract.php > preuves-run/contrats/se034-form-idempotency-contract.json
echo "PASS  se034-form-idempotency-contract" | tee -a preuves-run/journal.txt
kill "$SRV" 2>/dev/null || true; sleep 1

echo "== search-arrays-contract (E-5105) =="
"$PHP" -S 127.0.0.1:8099 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/search-arrays-server.log 2>&1 &
SRV=$!
sonde "$B/"
PK_BASE="$B" PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" \
  "$PHP" theme/partikulier/tests/search-arrays-contract.php > preuves-run/contrats/search-arrays-contract.json
echo "PASS  search-arrays-contract" | tee -a preuves-run/journal.txt
kill "$SRV" 2>/dev/null || true; sleep 1

echo "== Polylang : activation + langues + réglages (verbatim CI) =="
WP plugin activate polylang
cat > pll-langues.php <<'PLL_LANGUES'
<?php
if (!defined("ABSPATH")) { exit("CLI only"); }
$model = isset($GLOBALS["polylang"]) && $GLOBALS["polylang"] ? $GLOBALS["polylang"]->model : null;
if (!$model) { WP_CLI::error("Polylang n'est pas actif"); }
$langues = array(
    array("name" => "Français", "slug" => "fr", "locale" => "fr_FR", "rtl" => 0, "flag" => "fr", "term_group" => 1),
    array("name" => "English", "slug" => "en", "locale" => "en_US", "rtl" => 0, "flag" => "us", "term_group" => 0),
    array("name" => "العربية", "slug" => "ar", "locale" => "ar", "rtl" => 1, "flag" => "ma", "term_group" => 2),
);
foreach ($langues as $l) {
    if (!$model->get_language($l["slug"])) {
        $res = $model->add_language($l);
        if (is_wp_error($res)) { WP_CLI::error("langue ".$l["slug"]." : ".$res->get_error_message()); }
    }
}
$erreurs = $GLOBALS["polylang"]->options->merge(array(
    "force_lang" => 1,
    "hide_default" => 0,
    "browser" => 0,
    "redirect_lang" => 0,
    "default_lang" => "fr",
    "taxonomies" => array("es_type", "es_status", "es_location", "es_category"),
    "post_types" => array("post", "page", "properties"),
));
if (is_wp_error($erreurs) && $erreurs->has_errors()) {
    WP_CLI::error("réglages polylang : " . $erreurs->get_error_message());
}
wp_cache_flush();
WP_CLI::success("langues fr (défaut) / en / ar (rtl=1) créées, réglages de référence posés");
PLL_LANGUES
WP eval-file "$LAB/pll-langues.php"
cat > pll-masse.php <<'PLL_MASSE'
<?php
if (!defined("ABSPATH")) { exit("CLI only"); }
$model = isset($GLOBALS["polylang"]) && $GLOBALS["polylang"] ? $GLOBALS["polylang"]->model : null;
if (!$model) { WP_CLI::error("Polylang n'est pas actif"); }
$fr = $model->get_language("fr");
if (!$fr) { WP_CLI::error("langue fr introuvable"); }
$model->set_language_in_mass($fr);
flush_rewrite_rules();
$sans = 0;
foreach (get_posts(array("post_type" => "properties", "post_status" => "any", "numberposts" => 100, "fields" => "ids")) as $pid) {
    if (!pll_get_post_language($pid)) { $sans++; }
}
if ($sans > 0) { WP_CLI::error("$sans annonces properties restent sans langue"); }
WP_CLI::success("contenu existant assigné à fr, rewrites flushed");
PLL_MASSE
WP eval-file "$LAB/pll-masse.php"
WP rewrite flush

echo "== SE-025 (contexte AVEC Polylang) =="
PHP_CLI_SERVER_WORKERS=4 "$PHP" -S 127.0.0.1:8099 -t htdocs htdocs/wp-content/themes/partikulier/tests/router-ci.php > preuves-run/se025-server.log 2>&1 &
SRV=$!
sonde "$B/fr/"
PK_BASE="$B" PK_WP_DIR="$LAB/htdocs" PK_COMMIT="$SHA" \
  "$PHP" theme/partikulier/tests/se025-trilingual-routes-contract.php > preuves-run/contrats/se025-trilingual-routes-contract.json
echo "PASS  se025-trilingual-routes-contract" | tee -a preuves-run/journal.txt
kill "$SRV" 2>/dev/null || true; sleep 1

echo "== Oracle référence (attendu 370/370, 38 suites) =="
cd "$LAB"
"$PHP" <<'ORACLE'
<?php $tot=0; $pas=0; $n=0; foreach (glob("preuves-run/contrats/*.json") as $f) { $d=json_decode(file_get_contents($f), true); if (($d["status"] ?? "") !== "PASS") { fwrite(STDERR, basename($f).": status != PASS\n"); exit(1); } $tot += (int) $d["total"]; $pas += (int) $d["passed"]; $n++; } echo "contrats: $pas/$tot sur $n suites\n"; if ($tot !== 370 || $pas !== 370 || $n !== 38) { fwrite(STDERR, "oracle inattendu (attendu 370/370 sur 38 suites)\n"); exit(1); }
ORACLE

echo "== état rewrite + option règles après référence =="
WP option get pk_url_rules_version || echo "(option absente)"
WP option get rewrite_rules --format=json > "$P/RC-1/reference-apres-install-polylang.json" 2>/dev/null || true

# Copie de durabilité (P-6) — reference-run complet vers $PROOFS
rm -rf "$P/reference-run"; cp -a "$LAB/preuves-run" "$P/reference-run"
echo "REFERENCE-REJOUÉE : $(grep -c PASS "$P/reference-run/journal.txt") PASS / $(grep -c FAIL "$P/reference-run/journal.txt" || true) FAIL"
