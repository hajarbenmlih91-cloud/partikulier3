<?php
/**
 * Point R1 — reproduction du défaut de disponibilité (CDC Phase 1 §7).
 * AUCUN correctif : ListingRepository.php n'est PAS édité. Étapes pilotées
 * par phase1-r1.sh ; chaque étape imprime un JSON d'état sur stdout.
 *
 * Usage : php phase1-r1.php <etape> [post_id]
 *   init              → crée la fixture (annonce FR publiée), synchronise,
 *                       imprime l'état de départ
 *   mark_sold|mark_rented|archive <id> → transition métier RÉELLE via
 *                       Partikulier_Dashboard::manage_listing + vidange du
 *                       synchroniseur, imprime l'état résultant
 *   refuse_perimee <id> → passe _pk_status à 'refuse' SANS re-synchronisation
 *                       (projection périmée), imprime l'état
 *   refuse_synchronisee <id> → vidange du synchroniseur (projection à jour),
 *                       imprime l'état
 *   projection <id>   → imprime la ligne de projection + lecture find()
 *   nettoyage <id>    → supprime la fixture (post + projection)
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$etape = $argv[1] ?? '';
$postId = (int) ($argv[2] ?? 0);
require '/home/z/my-project/bench/lab-phase1/htdocs/wp-load.php';

$etat = static function (int $id): array {
    global $wpdb;
    $ligne = $wpdb->get_row($wpdb->prepare(
        "SELECT id, external_id, status, locale, title FROM {$wpdb->prefix}pk_listings WHERE external_id = %s",
        'estatik:' . $id
    ), ARRAY_A);
    return [
        'post_id' => $id,
        'post_status' => (string) get_post_field('post_status', $id),
        'pk_status' => (string) get_post_meta($id, '_pk_status', true),
        'projection' => $ligne,
        'find_individuel' => null,
    ];
};

$imprime = static function (array $e, string $note): void {
    $e['note'] = $note;
    echo json_encode($e, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
};

switch ($etape) {
    case 'init':
        wp_set_current_user(1);
        $run = bin2hex(random_bytes(4));
        $request = new WP_REST_Request('POST', '/partikulier/v1/listings');
        $request->set_header('Content-Type', 'application/json');
        $request->set_body(wp_json_encode([
            'title' => 'R1 fixture ' . $run,
            'description' => 'Point R1 — reproduction disponibilité (données fictives jetables)',
            'locale' => 'fr',
            'price' => 100,
            'area' => 10,
        ]));
        $response = rest_do_request($request);
        if ($response->get_status() !== 201) {
            fwrite(STDERR, 'création impossible : ' . wp_json_encode($response->get_data()) . "\n");
            exit(1);
        }
        $listingId = (int) ($response->get_data()['id'] ?? 0);
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT external_id FROM {$wpdb->prefix}pk_listings WHERE id = %d", $listingId), ARRAY_A);
        $postId = (int) substr((string) ($row['external_id'] ?? ''), strlen('estatik:'));
        wp_update_post(['ID' => $postId, 'post_status' => 'publish']);
        (new \Partikulier\Core\Integration\ListingSynchronizer())->flush();
        $e = $etat($postId);
        $e['url_fiche'] = get_permalink($postId);
        $imprime($e, 'fixture créée, publiée et synchronisée (état de départ attendu : actif/published)');
        break;

    case 'mark_sold':
    case 'mark_rented':
    case 'archive':
        wp_set_current_user(1);
        $result = Partikulier_Dashboard::manage_listing($postId, $etape, 1);
        if (is_wp_error($result)) {
            fwrite(STDERR, 'transition ' . $etape . ' refusée : ' . $result->get_error_message() . "\n");
            exit(1);
        }
        (new \Partikulier\Core\Integration\ListingSynchronizer())->flush();
        $imprime($etat($postId), 'transition réelle ' . $etape . ' + vidange du synchroniseur');
        break;

    case 'refuse_perimee':
        update_post_meta($postId, '_pk_status', 'refuse');
        $imprime($etat($postId), 'métadonnée _pk_status=refuse posée directement, SANS re-synchronisation (projection périmée attendue)');
        break;

    case 'refuse_synchronisee':
        /* Scénario §7.3 : « l'enregistrement du post et la synchronisation » —
         * la reprojection réelle passe par save_post (hook → file → vidange) ;
         * un flush() explicite sur files vides est un no-op. */
        wp_update_post(['ID' => $postId, 'post_status' => 'publish']);
        (new \Partikulier\Core\Integration\ListingSynchronizer())->flush();
        $imprime($etat($postId), 'enregistrement du post (save_post → reprojection) + vidange après refuse');
        break;

    case 'projection':
        $e = $etat($postId);
        $repo = new \Partikulier\Core\ListingRepository();
        $find = $repo->find($postId);
        $e['find_individuel'] = is_wp_error($find) ? $find->get_error_code() : 'trouvé';
        $imprime($e, 'lecture projection + find() individuel');
        break;

    case 'nettoyage':
        wp_set_current_user(1);
        wp_delete_post($postId, true);
        global $wpdb;
        $wpdb->delete($wpdb->prefix . 'pk_listings', ['external_id' => 'estatik:' . $postId]);
        $reste = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}pk_listings WHERE external_id = %s", 'estatik:' . $postId));
        $imprime(['post_id' => $postId, 'lignes_restantes' => $reste], 'fixture supprimée (post + projection)');
        break;

    default:
        fwrite(STDERR, "étape inconnue : $etape\n");
        exit(64);
}
