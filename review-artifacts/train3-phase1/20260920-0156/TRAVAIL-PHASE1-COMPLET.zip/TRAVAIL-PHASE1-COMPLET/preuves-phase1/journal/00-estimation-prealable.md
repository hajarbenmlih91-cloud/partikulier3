# Estimation préalable d'effort — Phase 1 v2.1 §1.1

Consignée AVANT exécution (2026-09-20, agent z.ai, session Phase 1).

| Poste | Estimation | Notes |
|---|---|---|
| Lab isolé (WP 6.6 + SQLite + thème/plugin 4b41bd6 + Polylang 3.8.7 trilingue + seed fictif) | ~1 h | téléchargements officiels autorisés §0.1 ; SQLite ≠ MySQL 8 CI → écart consigné |
| Lot A : RA-1 avant/après + 4 éditions + diff | 0,5 h | |
| Lot B : RB-1 avant/après + 1 ligne + contrat 6 assertions + workflow 376/39 + doc E-4102 + diff | 1 h | |
| Lot C : RC-1 avant/migration/3 flush + 2 éditions + contrat 6 assertions + workflow 382/40 + diff | 1,5 h | |
| Point R1 : fixtures + mark_sold/mark_rented/archive + cas refuse périmé + REST | 1 h | reproduction seule, aucun correctif |
| Non-régression locale (suites jouables hors CI) | 0,5 h | rest-lite-scope, premium, se048, se025 |
| Chaîne second clone + rapport + preuves + SHA256SUMS + contrôles de suivi §10 | 1 h | |
| **Total** | **≈ 6,5 h** | opérations communes comptées une fois |

Limites connues dès le départ :
- CI GitHub complète (40 suites/382) NON démontrable sans push (interdit) → statut global « partiel » annoncé.
- SQL du lab = SQLite, différent de MySQL 8 (CI) et MariaDB 11.8.6 (revue) → écarts consignés, aucun vert transféré.
- Gains v2.1 §0.4 : aucune promesse de vitesse/trafîc/référencement/conversion — maintenance/durcissement uniquement.
- Arrêt et arbitrage avant tout supplément significatif ou extension de périmètre (règle §1.1).
